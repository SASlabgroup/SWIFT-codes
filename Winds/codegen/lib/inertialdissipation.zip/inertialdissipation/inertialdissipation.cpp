//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: inertialdissipation.cpp
//
// MATLAB Coder version            : 3.2
// C/C++ source code generated on  : 10-Nov-2016 11:31:38
//

// Include Files
#include "rt_nonfinite.h"
#include "inertialdissipation.h"
#include "inertialdissipation_emxutil.h"
#include "mean.h"
#include "std.h"
#include "detrend.h"
#include "all.h"
#include "rdivide.h"
#include "power.h"
#include "sum.h"
#include "sqrt.h"
#include "var.h"
#include "abs.h"
#include "nullAssignment.h"
#include "fft.h"
#include "sin.h"

// Function Declarations
static double rt_remd_snf(double u0, double u1);
static double rt_roundd_snf(double u);

// Function Definitions

//
// Arguments    : double u0
//                double u1
// Return Type  : double
//
static double rt_remd_snf(double u0, double u1)
{
  double y;
  double b_u1;
  double tr;
  if (!((!rtIsNaN(u0)) && (!rtIsInf(u0)) && ((!rtIsNaN(u1)) && (!rtIsInf(u1)))))
  {
    y = rtNaN;
  } else {
    if (u1 < 0.0) {
      b_u1 = std::ceil(u1);
    } else {
      b_u1 = std::floor(u1);
    }

    if ((u1 != 0.0) && (u1 != b_u1)) {
      tr = u0 / u1;
      if (std::abs(tr - rt_roundd_snf(tr)) <= DBL_EPSILON * std::abs(tr)) {
        y = 0.0;
      } else {
        y = std::fmod(u0, u1);
      }
    } else {
      y = std::fmod(u0, u1);
    }
  }

  return y;
}

//
// Arguments    : double u
// Return Type  : double
//
static double rt_roundd_snf(double u)
{
  double y;
  if (std::abs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = std::floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = std::ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

//
// matlab function to process 3D sonic anemometer data
//  based on the inertial dissipation methods of Yelland et al 1994
//  inputs are turbulent components of wind u,v,w, and sonic (virtual) air temp
//    also measurement height z and sampling frequency
//  ouptuts are wind friction velocity ustar, dissipation rate epsilon
//    means of each component and air temp,
//    and an anisotropy metric for the inertial sub range of the spectrum
//    and a quality metric for the ustar estimate based on interial fitting
//    and tke frequency spectrum,
//
//    [ustar epsilon meanu meanv meanw meantemp anisotropy quality freq tkespectrum ] = inertialdissipation(u, v, w, temp, z, fs);
//
//  The intent is to run this on short bursts of data (nominally 10 to 60 minutes)
//    such that the input data have stationary statistics
//
//  J. Thomson, Aug 2016 (modified from 2010 shipboard to waveglider)
//        note that works best with WG into the wind (strong negative u component measured)
//  M. Schwendeman, Nov 2016 - modified from waveglider to SWIFT, fixed
//  output vectors to length 116 (assumes wsecs = 256, merge = 11, fs = 10)
// Arguments    : emxArray_real_T *u
//                emxArray_real_T *v
//                emxArray_real_T *w
//                emxArray_real_T *temp
//                double z
//                double fs
//                double *ustar
//                double *epsilon
//                double *meanu
//                double *meanv
//                double *meanw
//                double *meantemp
//                double *anisotropy
//                double *quality
//                double freq[116]
//                double tkespectrum[116]
// Return Type  : void
//
void inertialdissipation(emxArray_real_T *u, emxArray_real_T *v, emxArray_real_T
  *w, emxArray_real_T *temp, double z, double fs, double *ustar, double *epsilon,
  double *meanu, double *meanv, double *meanw, double *meantemp, double
  *anisotropy, double *quality, double freq[116], double tkespectrum[116])
{
  emxArray_boolean_T *bad;
  double windowlength;
  int i0;
  int loop_ub;
  emxArray_real_T *uwindow;
  emxArray_real_T *vwindow;
  emxArray_real_T *wwindow;
  emxArray_real_T *udetrend;
  emxArray_real_T *vdetrend;
  emxArray_real_T *wdetrend;
  emxArray_real_T *xwindowtaper;
  emxArray_real_T *ywindowtaper;
  emxArray_real_T *factx;
  emxArray_real_T *facty;
  emxArray_real_T *factz;
  emxArray_creal_T *Uwindow;
  emxArray_creal_T *Vwindow;
  emxArray_creal_T *Wwindow;
  emxArray_real_T *f;
  emxArray_real_T *advectionspeed;
  emxArray_real_T *epsilonwindow;
  emxArray_real_T *ustarwindow;
  emxArray_real_T *WW;
  emxArray_boolean_T *r0;
  emxArray_boolean_T *r1;
  emxArray_boolean_T *r2;
  emxArray_int32_T *r3;
  emxArray_int32_T *r4;
  emxArray_int32_T *r5;
  emxArray_real_T *a;
  emxArray_real_T *r6;
  emxArray_real_T *r7;
  emxArray_boolean_T *b_factx;
  emxArray_real_T *b_WW;
  emxArray_real_T *b_factz;
  emxArray_real_T *c_WW;
  emxArray_real_T *b_facty;
  emxArray_real_T *c_factx;
  emxArray_real_T *b_ustarwindow;
  emxArray_real_T *b_epsilonwindow;
  emxArray_boolean_T *r8;
  emxArray_real_T *b_wdetrend;
  emxArray_real_T *b_vdetrend;
  emxArray_real_T *b_udetrend;
  emxArray_real_T *c_factz;
  emxArray_real_T *r9;
  emxArray_real_T *r10;
  emxArray_real_T *r11;
  emxArray_real_T *b_a;
  emxArray_real_T *b_f;
  emxArray_real_T *c_a;
  emxArray_real_T *c_f;
  emxArray_int32_T *b_windowlength;
  emxArray_int32_T *c_windowlength;
  emxArray_int32_T *d_windowlength;
  emxArray_real_T *r12;
  emxArray_real_T *r13;
  emxArray_real_T *r14;
  emxArray_real_T *b_wwindow;
  emxArray_real_T *b_vwindow;
  emxArray_real_T *b_uwindow;
  emxArray_real_T *c_wwindow;
  emxArray_real_T *c_vwindow;
  emxArray_real_T *c_uwindow;
  emxArray_real_T *b_ywindowtaper;
  emxArray_real_T *r15;
  emxArray_real_T *b_xwindowtaper;
  emxArray_real_T *r16;
  emxArray_real_T *d_wwindow;
  emxArray_real_T *r17;
  emxArray_real_T *r18;
  emxArray_real_T *r19;
  emxArray_real_T *r20;
  emxArray_creal_T *b_Uwindow;
  emxArray_creal_T *b_Vwindow;
  emxArray_creal_T *b_Wwindow;
  emxArray_real_T *d_a;
  emxArray_real_T *e_a;
  double windows;
  boolean_T QCflag;
  int q;
  double n;
  int d_factx;
  int e_factx;
  int mi;
  int i1;
  int i2;
  double bandwidth;
  double x;
  double y;
  emxInit_boolean_T(&bad, 1);

  //  fixed parameters
  //  window length in seconds, should make 2^N samples
  //  freq bands to merge, must be odd?
  //  Kolmogorov const, where factor 4/3 is for cross-flow components... i.e., vertical) 
  //  von Karman const
  //  number of std deviations to use for simple despiking
  windowlength = rt_roundd_snf(fs * 256.0);

  //  window length in data points
  //  quality control... later require no more than 10% data loss in this screening 
  i0 = bad->size[0];
  bad->size[0] = u->size[0];
  emxEnsureCapacity((emxArray__common *)bad, i0, (int)sizeof(boolean_T));
  loop_ub = u->size[0];
  for (i0 = 0; i0 < loop_ub; i0++) {
    bad->data[i0] = ((u->data[i0] == 0.0) || (v->data[i0] == 0.0) || (w->data[i0]
      == 0.0) || (temp->data[i0] == 0.0));
  }

  nullAssignment(u, bad);
  nullAssignment(v, bad);
  nullAssignment(w, bad);
  nullAssignment(temp, bad);

  // u = u( ~bad );
  // v = v( ~bad );
  // w = w( ~bad );
  // temp = temp( ~bad );
  //  means
  *meanu = mean(u);
  *meanv = mean(v);
  *meanw = mean(w);
  *meantemp = mean(temp);

  //  begin processing, if data sufficient
  //  record length in data points
  emxInit_real_T(&uwindow, 2);
  emxInit_real_T(&vwindow, 2);
  emxInit_real_T(&wwindow, 2);
  emxInit_real_T(&udetrend, 2);
  emxInit_real_T(&vdetrend, 2);
  emxInit_real_T(&wdetrend, 2);
  emxInit_real_T(&xwindowtaper, 2);
  emxInit_real_T(&ywindowtaper, 2);
  emxInit_real_T(&factx, 2);
  emxInit_real_T(&facty, 2);
  emxInit_real_T(&factz, 2);
  emxInit_creal_T(&Uwindow, 2);
  emxInit_creal_T(&Vwindow, 2);
  emxInit_creal_T(&Wwindow, 2);
  emxInit_real_T(&f, 2);
  emxInit_real_T(&advectionspeed, 2);
  emxInit_real_T(&epsilonwindow, 2);
  emxInit_real_T(&ustarwindow, 2);
  emxInit_real_T(&WW, 2);
  emxInit_boolean_T(&r0, 1);
  emxInit_boolean_T1(&r1, 2);
  emxInit_boolean_T1(&r2, 2);
  emxInit_int32_T(&r3, 1);
  emxInit_int32_T(&r4, 1);
  emxInit_int32_T1(&r5, 2);
  emxInit_real_T1(&a, 1);
  emxInit_real_T(&r6, 2);
  emxInit_real_T(&r7, 2);
  emxInit_boolean_T1(&b_factx, 2);
  emxInit_real_T(&b_WW, 2);
  emxInit_real_T(&b_factz, 2);
  emxInit_real_T(&c_WW, 2);
  emxInit_real_T(&b_facty, 2);
  emxInit_real_T(&c_factx, 2);
  emxInit_real_T(&b_ustarwindow, 2);
  emxInit_real_T(&b_epsilonwindow, 2);
  emxInit_boolean_T1(&r8, 2);
  emxInit_real_T(&b_wdetrend, 2);
  emxInit_real_T(&b_vdetrend, 2);
  emxInit_real_T(&b_udetrend, 2);
  emxInit_real_T(&c_factz, 2);
  emxInit_real_T(&r9, 2);
  emxInit_real_T(&r10, 2);
  emxInit_real_T(&r11, 2);
  emxInit_real_T(&b_a, 2);
  emxInit_real_T1(&b_f, 1);
  emxInit_real_T(&c_a, 2);
  emxInit_real_T1(&c_f, 1);
  emxInit_int32_T1(&b_windowlength, 2);
  emxInit_int32_T1(&c_windowlength, 2);
  emxInit_int32_T1(&d_windowlength, 2);
  emxInit_real_T(&r12, 2);
  emxInit_real_T(&r13, 2);
  emxInit_real_T(&r14, 2);
  emxInit_real_T1(&b_wwindow, 1);
  emxInit_real_T1(&b_vwindow, 1);
  emxInit_real_T1(&b_uwindow, 1);
  emxInit_real_T1(&c_wwindow, 1);
  emxInit_real_T1(&c_vwindow, 1);
  emxInit_real_T1(&c_uwindow, 1);
  emxInit_real_T(&b_ywindowtaper, 2);
  emxInit_real_T(&r15, 2);
  emxInit_real_T(&b_xwindowtaper, 2);
  emxInit_real_T(&r16, 2);
  emxInit_real_T(&d_wwindow, 2);
  emxInit_real_T(&r17, 2);
  emxInit_real_T(&r18, 2);
  emxInit_real_T(&r19, 2);
  emxInit_real_T(&r20, 2);
  emxInit_creal_T(&b_Uwindow, 2);
  emxInit_creal_T(&b_Vwindow, 2);
  emxInit_creal_T(&b_Wwindow, 2);
  emxInit_real_T(&d_a, 2);
  emxInit_real_T(&e_a, 2);
  if ((u->size[0] >= 512) && (fs > 1.0) && (sum(bad) < 0.1 * (double)u->size[0]))
  {
    //  minimum length and quality for processing
    //  break into windows (use 75 percent overlap)
    if (rt_remd_snf(windowlength, 2.0) != 0.0) {
      windowlength--;
    }

    //  make w an even number
    windows = std::floor(4.0 * ((double)u->size[0] / windowlength - 1.0) + 1.0);

    //  number of windows, the 4 comes from a 75% overlap
    //  degrees of freedom
    //  loop to create a matrix of time series, where COLUMN = WINDOW
    i0 = uwindow->size[0] * uwindow->size[1];
    uwindow->size[0] = (int)windowlength;
    uwindow->size[1] = (int)windows;
    emxEnsureCapacity((emxArray__common *)uwindow, i0, (int)sizeof(double));
    i0 = vwindow->size[0] * vwindow->size[1];
    vwindow->size[0] = (int)windowlength;
    vwindow->size[1] = (int)windows;
    emxEnsureCapacity((emxArray__common *)vwindow, i0, (int)sizeof(double));
    i0 = wwindow->size[0] * wwindow->size[1];
    wwindow->size[0] = (int)windowlength;
    wwindow->size[1] = (int)windows;
    emxEnsureCapacity((emxArray__common *)wwindow, i0, (int)sizeof(double));
    for (q = 0; q < (int)windows; q++) {
      n = ((1.0 + (double)q) - 1.0) * (0.25 * windowlength);
      i0 = r6->size[0] * r6->size[1];
      r6->size[0] = 1;
      r6->size[1] = (int)std::floor(windowlength - 1.0) + 1;
      emxEnsureCapacity((emxArray__common *)r6, i0, (int)sizeof(double));
      loop_ub = (int)std::floor(windowlength - 1.0);
      for (i0 = 0; i0 <= loop_ub; i0++) {
        r6->data[r6->size[0] * i0] = n + (1.0 + (double)i0);
      }

      loop_ub = r6->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        uwindow->data[i0 + uwindow->size[0] * q] = u->data[(int)r6->data
          [r6->size[0] * i0] - 1];
      }

      n = ((1.0 + (double)q) - 1.0) * (0.25 * windowlength);
      i0 = r6->size[0] * r6->size[1];
      r6->size[0] = 1;
      r6->size[1] = (int)std::floor(windowlength - 1.0) + 1;
      emxEnsureCapacity((emxArray__common *)r6, i0, (int)sizeof(double));
      loop_ub = (int)std::floor(windowlength - 1.0);
      for (i0 = 0; i0 <= loop_ub; i0++) {
        r6->data[r6->size[0] * i0] = n + (1.0 + (double)i0);
      }

      loop_ub = r6->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        vwindow->data[i0 + vwindow->size[0] * q] = v->data[(int)r6->data
          [r6->size[0] * i0] - 1];
      }

      n = ((1.0 + (double)q) - 1.0) * (0.25 * windowlength);
      i0 = r6->size[0] * r6->size[1];
      r6->size[0] = 1;
      r6->size[1] = (int)std::floor(windowlength - 1.0) + 1;
      emxEnsureCapacity((emxArray__common *)r6, i0, (int)sizeof(double));
      loop_ub = (int)std::floor(windowlength - 1.0);
      for (i0 = 0; i0 <= loop_ub; i0++) {
        r6->data[r6->size[0] * i0] = n + (1.0 + (double)i0);
      }

      loop_ub = r6->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        wwindow->data[i0 + wwindow->size[0] * q] = w->data[(int)r6->data
          [r6->size[0] * i0] - 1];
      }
    }

    //  despike each window (use windows rather than whole set, because changes in vehicle nav might cause non-stationary statistics) 
    for (q = 0; q < (int)windows; q++) {
      loop_ub = uwindow->size[0];
      i0 = c_uwindow->size[0];
      c_uwindow->size[0] = loop_ub;
      emxEnsureCapacity((emxArray__common *)c_uwindow, i0, (int)sizeof(double));
      for (i0 = 0; i0 < loop_ub; i0++) {
        c_uwindow->data[i0] = uwindow->data[i0 + uwindow->size[0] * q];
      }

      loop_ub = uwindow->size[0];
      n = 5.0 * b_std(c_uwindow);
      i0 = bad->size[0];
      bad->size[0] = loop_ub;
      emxEnsureCapacity((emxArray__common *)bad, i0, (int)sizeof(boolean_T));
      for (i0 = 0; i0 < loop_ub; i0++) {
        bad->data[i0] = (uwindow->data[i0 + uwindow->size[0] * q] > n);
      }

      loop_ub = vwindow->size[0];
      i0 = c_vwindow->size[0];
      c_vwindow->size[0] = loop_ub;
      emxEnsureCapacity((emxArray__common *)c_vwindow, i0, (int)sizeof(double));
      for (i0 = 0; i0 < loop_ub; i0++) {
        c_vwindow->data[i0] = vwindow->data[i0 + vwindow->size[0] * q];
      }

      loop_ub = vwindow->size[0];
      n = 5.0 * b_std(c_vwindow);
      i0 = r0->size[0];
      r0->size[0] = loop_ub;
      emxEnsureCapacity((emxArray__common *)r0, i0, (int)sizeof(boolean_T));
      for (i0 = 0; i0 < loop_ub; i0++) {
        r0->data[i0] = (vwindow->data[i0 + vwindow->size[0] * q] > n);
      }

      i0 = bad->size[0];
      emxEnsureCapacity((emxArray__common *)bad, i0, (int)sizeof(boolean_T));
      loop_ub = bad->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        bad->data[i0] = (bad->data[i0] || r0->data[i0]);
      }

      loop_ub = wwindow->size[0];
      i0 = c_wwindow->size[0];
      c_wwindow->size[0] = loop_ub;
      emxEnsureCapacity((emxArray__common *)c_wwindow, i0, (int)sizeof(double));
      for (i0 = 0; i0 < loop_ub; i0++) {
        c_wwindow->data[i0] = wwindow->data[i0 + wwindow->size[0] * q];
      }

      loop_ub = wwindow->size[0];
      n = 5.0 * b_std(c_wwindow);
      i0 = r0->size[0];
      r0->size[0] = loop_ub;
      emxEnsureCapacity((emxArray__common *)r0, i0, (int)sizeof(boolean_T));
      for (i0 = 0; i0 < loop_ub; i0++) {
        r0->data[i0] = (wwindow->data[i0 + wwindow->size[0] * q] > n);
      }

      // disp('spikes'), sum(spikes) % debug
      mi = bad->size[0] - 1;
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (bad->data[e_factx] || r0->data[e_factx]) {
          d_factx++;
        }
      }

      i0 = r3->size[0];
      r3->size[0] = d_factx;
      emxEnsureCapacity((emxArray__common *)r3, i0, (int)sizeof(int));
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (bad->data[e_factx] || r0->data[e_factx]) {
          r3->data[d_factx] = e_factx + 1;
          d_factx++;
        }
      }

      mi = bad->size[0] - 1;
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (!(bad->data[e_factx] || r0->data[e_factx])) {
          d_factx++;
        }
      }

      i0 = r4->size[0];
      r4->size[0] = d_factx;
      emxEnsureCapacity((emxArray__common *)r4, i0, (int)sizeof(int));
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (!(bad->data[e_factx] || r0->data[e_factx])) {
          r4->data[d_factx] = e_factx + 1;
          d_factx++;
        }
      }

      i0 = b_uwindow->size[0];
      b_uwindow->size[0] = r4->size[0];
      emxEnsureCapacity((emxArray__common *)b_uwindow, i0, (int)sizeof(double));
      loop_ub = r4->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        b_uwindow->data[i0] = uwindow->data[(r4->data[i0] + uwindow->size[0] * q)
          - 1];
      }

      n = mean(b_uwindow);
      d_factx = r3->size[0];
      for (i0 = 0; i0 < d_factx; i0++) {
        uwindow->data[(r3->data[i0] + uwindow->size[0] * q) - 1] = n;
      }

      mi = bad->size[0] - 1;
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (bad->data[e_factx] || r0->data[e_factx]) {
          d_factx++;
        }
      }

      i0 = r3->size[0];
      r3->size[0] = d_factx;
      emxEnsureCapacity((emxArray__common *)r3, i0, (int)sizeof(int));
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (bad->data[e_factx] || r0->data[e_factx]) {
          r3->data[d_factx] = e_factx + 1;
          d_factx++;
        }
      }

      mi = bad->size[0] - 1;
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (!(bad->data[e_factx] || r0->data[e_factx])) {
          d_factx++;
        }
      }

      i0 = r4->size[0];
      r4->size[0] = d_factx;
      emxEnsureCapacity((emxArray__common *)r4, i0, (int)sizeof(int));
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (!(bad->data[e_factx] || r0->data[e_factx])) {
          r4->data[d_factx] = e_factx + 1;
          d_factx++;
        }
      }

      i0 = b_vwindow->size[0];
      b_vwindow->size[0] = r4->size[0];
      emxEnsureCapacity((emxArray__common *)b_vwindow, i0, (int)sizeof(double));
      loop_ub = r4->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        b_vwindow->data[i0] = vwindow->data[(r4->data[i0] + vwindow->size[0] * q)
          - 1];
      }

      n = mean(b_vwindow);
      d_factx = r3->size[0];
      for (i0 = 0; i0 < d_factx; i0++) {
        vwindow->data[(r3->data[i0] + vwindow->size[0] * q) - 1] = n;
      }

      mi = bad->size[0] - 1;
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (bad->data[e_factx] || r0->data[e_factx]) {
          d_factx++;
        }
      }

      i0 = r3->size[0];
      r3->size[0] = d_factx;
      emxEnsureCapacity((emxArray__common *)r3, i0, (int)sizeof(int));
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (bad->data[e_factx] || r0->data[e_factx]) {
          r3->data[d_factx] = e_factx + 1;
          d_factx++;
        }
      }

      mi = bad->size[0] - 1;
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (!(bad->data[e_factx] || r0->data[e_factx])) {
          d_factx++;
        }
      }

      i0 = r4->size[0];
      r4->size[0] = d_factx;
      emxEnsureCapacity((emxArray__common *)r4, i0, (int)sizeof(int));
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (!(bad->data[e_factx] || r0->data[e_factx])) {
          r4->data[d_factx] = e_factx + 1;
          d_factx++;
        }
      }

      i0 = b_wwindow->size[0];
      b_wwindow->size[0] = r4->size[0];
      emxEnsureCapacity((emxArray__common *)b_wwindow, i0, (int)sizeof(double));
      loop_ub = r4->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        b_wwindow->data[i0] = wwindow->data[(r4->data[i0] + wwindow->size[0] * q)
          - 1];
      }

      n = mean(b_wwindow);
      d_factx = r3->size[0];
      for (i0 = 0; i0 < d_factx; i0++) {
        wwindow->data[(r3->data[i0] + wwindow->size[0] * q) - 1] = n;
      }
    }

    //  detrend individual windows (full series already detrended)
    i0 = udetrend->size[0] * udetrend->size[1];
    udetrend->size[0] = (int)windowlength;
    udetrend->size[1] = (int)windows;
    emxEnsureCapacity((emxArray__common *)udetrend, i0, (int)sizeof(double));
    i0 = vdetrend->size[0] * vdetrend->size[1];
    vdetrend->size[0] = (int)windowlength;
    vdetrend->size[1] = (int)windows;
    emxEnsureCapacity((emxArray__common *)vdetrend, i0, (int)sizeof(double));
    i0 = wdetrend->size[0] * wdetrend->size[1];
    wdetrend->size[0] = (int)windowlength;
    wdetrend->size[1] = (int)windows;
    emxEnsureCapacity((emxArray__common *)wdetrend, i0, (int)sizeof(double));
    for (q = 0; q < (int)windows; q++) {
      loop_ub = uwindow->size[0];
      i0 = a->size[0];
      a->size[0] = loop_ub;
      emxEnsureCapacity((emxArray__common *)a, i0, (int)sizeof(double));
      for (i0 = 0; i0 < loop_ub; i0++) {
        a->data[i0] = uwindow->data[i0 + uwindow->size[0] * q];
      }

      detrend(a);
      loop_ub = a->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        udetrend->data[i0 + udetrend->size[0] * q] = a->data[i0];
      }

      loop_ub = vwindow->size[0];
      i0 = a->size[0];
      a->size[0] = loop_ub;
      emxEnsureCapacity((emxArray__common *)a, i0, (int)sizeof(double));
      for (i0 = 0; i0 < loop_ub; i0++) {
        a->data[i0] = vwindow->data[i0 + vwindow->size[0] * q];
      }

      detrend(a);
      loop_ub = a->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        vdetrend->data[i0 + vdetrend->size[0] * q] = a->data[i0];
      }

      loop_ub = wwindow->size[0];
      i0 = a->size[0];
      a->size[0] = loop_ub;
      emxEnsureCapacity((emxArray__common *)a, i0, (int)sizeof(double));
      for (i0 = 0; i0 < loop_ub; i0++) {
        a->data[i0] = wwindow->data[i0 + wwindow->size[0] * q];
      }

      detrend(a);
      loop_ub = a->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        wdetrend->data[i0 + wdetrend->size[0] * q] = a->data[i0];
      }
    }

    //  taper and rescale (to preserve variance)
    //  form taper matrix (columns of taper coef)
    if (windowlength < 1.0) {
      i0 = factx->size[0] * factx->size[1];
      factx->size[0] = 1;
      factx->size[1] = 0;
      emxEnsureCapacity((emxArray__common *)factx, i0, (int)sizeof(double));
    } else if (rtIsInf(windowlength) && (1.0 == windowlength)) {
      i0 = factx->size[0] * factx->size[1];
      factx->size[0] = 1;
      factx->size[1] = 1;
      emxEnsureCapacity((emxArray__common *)factx, i0, (int)sizeof(double));
      factx->data[0] = rtNaN;
    } else {
      i0 = factx->size[0] * factx->size[1];
      factx->size[0] = 1;
      factx->size[1] = (int)std::floor(windowlength - 1.0) + 1;
      emxEnsureCapacity((emxArray__common *)factx, i0, (int)sizeof(double));
      loop_ub = (int)std::floor(windowlength - 1.0);
      for (i0 = 0; i0 <= loop_ub; i0++) {
        factx->data[factx->size[0] * i0] = 1.0 + (double)i0;
      }
    }

    i0 = factx->size[0] * factx->size[1];
    factx->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)factx, i0, (int)sizeof(double));
    d_factx = factx->size[0];
    e_factx = factx->size[1];
    loop_ub = d_factx * e_factx;
    for (i0 = 0; i0 < loop_ub; i0++) {
      factx->data[i0] = factx->data[i0] * 3.1415926535897931 / windowlength;
    }

    b_sin(factx);
    i0 = a->size[0];
    a->size[0] = factx->size[1];
    emxEnsureCapacity((emxArray__common *)a, i0, (int)sizeof(double));
    loop_ub = factx->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      a->data[i0] = factx->data[factx->size[0] * i0];
    }

    i0 = wwindow->size[0] * wwindow->size[1];
    wwindow->size[0] = a->size[0];
    wwindow->size[1] = (int)windows;
    emxEnsureCapacity((emxArray__common *)wwindow, i0, (int)sizeof(double));
    loop_ub = a->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = (int)windows;
      for (i1 = 0; i1 < d_factx; i1++) {
        wwindow->data[i0 + wwindow->size[0] * i1] = a->data[i0];
      }
    }

    //  taper each window
    i0 = xwindowtaper->size[0] * xwindowtaper->size[1];
    xwindowtaper->size[0] = udetrend->size[0];
    xwindowtaper->size[1] = udetrend->size[1];
    emxEnsureCapacity((emxArray__common *)xwindowtaper, i0, (int)sizeof(double));
    loop_ub = udetrend->size[0] * udetrend->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      xwindowtaper->data[i0] = udetrend->data[i0] * wwindow->data[i0];
    }

    i0 = ywindowtaper->size[0] * ywindowtaper->size[1];
    ywindowtaper->size[0] = vdetrend->size[0];
    ywindowtaper->size[1] = vdetrend->size[1];
    emxEnsureCapacity((emxArray__common *)ywindowtaper, i0, (int)sizeof(double));
    loop_ub = vdetrend->size[0] * vdetrend->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      ywindowtaper->data[i0] = vdetrend->data[i0] * wwindow->data[i0];
    }

    i0 = wwindow->size[0] * wwindow->size[1];
    wwindow->size[0] = wdetrend->size[0];
    wwindow->size[1] = wdetrend->size[1];
    emxEnsureCapacity((emxArray__common *)wwindow, i0, (int)sizeof(double));
    loop_ub = wdetrend->size[0] * wdetrend->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      wwindow->data[i0] *= wdetrend->data[i0];
    }

    //  now find the correction factor (comparing old/new variance)
    var(udetrend, r6);
    var(xwindowtaper, r7);
    rdivide(r6, r7, factx);
    b_sqrt(factx);
    var(vdetrend, r6);
    var(ywindowtaper, r7);
    rdivide(r6, r7, facty);
    b_sqrt(facty);
    var(wdetrend, r6);
    var(wwindow, r7);
    rdivide(r6, r7, factz);
    b_sqrt(factz);

    //  and correct for the change in variance
    //  (mult each window by it's variance ratio factor)
    //  FFT
    //  calculate Fourier coefs
    i0 = r18->size[0] * r18->size[1];
    r18->size[0] = (int)windowlength;
    r18->size[1] = factx->size[1];
    emxEnsureCapacity((emxArray__common *)r18, i0, (int)sizeof(double));
    loop_ub = (int)windowlength;
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = factx->size[1];
      for (i1 = 0; i1 < d_factx; i1++) {
        r18->data[i0 + r18->size[0] * i1] = factx->data[factx->size[0] * i1];
      }
    }

    i0 = r14->size[0] * r14->size[1];
    r14->size[0] = r18->size[0];
    r14->size[1] = r18->size[1];
    emxEnsureCapacity((emxArray__common *)r14, i0, (int)sizeof(double));
    loop_ub = r18->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = r18->size[0];
      for (i1 = 0; i1 < d_factx; i1++) {
        r14->data[i1 + r14->size[0] * i0] = r18->data[i1 + r18->size[0] * i0] *
          xwindowtaper->data[i1 + xwindowtaper->size[0] * i0];
      }
    }

    fft(r14, Uwindow);
    i0 = r19->size[0] * r19->size[1];
    r19->size[0] = (int)windowlength;
    r19->size[1] = facty->size[1];
    emxEnsureCapacity((emxArray__common *)r19, i0, (int)sizeof(double));
    loop_ub = (int)windowlength;
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = facty->size[1];
      for (i1 = 0; i1 < d_factx; i1++) {
        r19->data[i0 + r19->size[0] * i1] = facty->data[facty->size[0] * i1];
      }
    }

    i0 = r13->size[0] * r13->size[1];
    r13->size[0] = r19->size[0];
    r13->size[1] = r19->size[1];
    emxEnsureCapacity((emxArray__common *)r13, i0, (int)sizeof(double));
    loop_ub = r19->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = r19->size[0];
      for (i1 = 0; i1 < d_factx; i1++) {
        r13->data[i1 + r13->size[0] * i0] = r19->data[i1 + r19->size[0] * i0] *
          ywindowtaper->data[i1 + ywindowtaper->size[0] * i0];
      }
    }

    fft(r13, Vwindow);
    i0 = r20->size[0] * r20->size[1];
    r20->size[0] = (int)windowlength;
    r20->size[1] = factz->size[1];
    emxEnsureCapacity((emxArray__common *)r20, i0, (int)sizeof(double));
    loop_ub = (int)windowlength;
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = factz->size[1];
      for (i1 = 0; i1 < d_factx; i1++) {
        r20->data[i0 + r20->size[0] * i1] = factz->data[factz->size[0] * i1];
      }
    }

    i0 = r12->size[0] * r12->size[1];
    r12->size[0] = r20->size[0];
    r12->size[1] = r20->size[1];
    emxEnsureCapacity((emxArray__common *)r12, i0, (int)sizeof(double));
    loop_ub = r20->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = r20->size[0];
      for (i1 = 0; i1 < d_factx; i1++) {
        r12->data[i1 + r12->size[0] * i0] = r20->data[i1 + r20->size[0] * i0] *
          wwindow->data[i1 + wwindow->size[0] * i0];
      }
    }

    fft(r12, Wwindow);

    //  second half of fft is redundant, so throw it out
    n = windowlength / 2.0 + 1.0;
    i0 = d_windowlength->size[0] * d_windowlength->size[1];
    d_windowlength->size[0] = 1;
    d_windowlength->size[1] = (int)std::floor(windowlength - n) + 1;
    emxEnsureCapacity((emxArray__common *)d_windowlength, i0, (int)sizeof(int));
    loop_ub = (int)std::floor(windowlength - n);
    for (i0 = 0; i0 <= loop_ub; i0++) {
      d_windowlength->data[d_windowlength->size[0] * i0] = (int)(n + (double)i0);
    }

    b_nullAssignment(Uwindow, d_windowlength);
    n = windowlength / 2.0 + 1.0;
    i0 = c_windowlength->size[0] * c_windowlength->size[1];
    c_windowlength->size[0] = 1;
    c_windowlength->size[1] = (int)std::floor(windowlength - n) + 1;
    emxEnsureCapacity((emxArray__common *)c_windowlength, i0, (int)sizeof(int));
    loop_ub = (int)std::floor(windowlength - n);
    for (i0 = 0; i0 <= loop_ub; i0++) {
      c_windowlength->data[c_windowlength->size[0] * i0] = (int)(n + (double)i0);
    }

    b_nullAssignment(Vwindow, c_windowlength);
    n = windowlength / 2.0 + 1.0;
    i0 = b_windowlength->size[0] * b_windowlength->size[1];
    b_windowlength->size[0] = 1;
    b_windowlength->size[1] = (int)std::floor(windowlength - n) + 1;
    emxEnsureCapacity((emxArray__common *)b_windowlength, i0, (int)sizeof(int));
    loop_ub = (int)std::floor(windowlength - n);
    for (i0 = 0; i0 <= loop_ub; i0++) {
      b_windowlength->data[b_windowlength->size[0] * i0] = (int)(n + (double)i0);
    }

    b_nullAssignment(Wwindow, b_windowlength);

    //  throw out the mean (first coef) and add a zero (to make it the right length)   
    // Uwindow(1,:)=[]; Vwindow(1,:)=[]; Wwindow(1,:)=[];
    n = windowlength / 2.0;
    if (2.0 > n) {
      i0 = 0;
      i1 = 0;
    } else {
      i0 = 1;
      i1 = (int)n;
    }

    d_factx = Uwindow->size[1];
    q = b_Uwindow->size[0] * b_Uwindow->size[1];
    b_Uwindow->size[0] = i1 - i0;
    b_Uwindow->size[1] = d_factx;
    emxEnsureCapacity((emxArray__common *)b_Uwindow, q, (int)sizeof(creal_T));
    for (q = 0; q < d_factx; q++) {
      loop_ub = i1 - i0;
      for (i2 = 0; i2 < loop_ub; i2++) {
        b_Uwindow->data[i2 + b_Uwindow->size[0] * q] = Uwindow->data[(i0 + i2) +
          Uwindow->size[0] * q];
      }
    }

    loop_ub = b_Uwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = b_Uwindow->size[0];
      for (i1 = 0; i1 < d_factx; i1++) {
        Uwindow->data[i1 + Uwindow->size[0] * i0] = b_Uwindow->data[i1 +
          b_Uwindow->size[0] * i0];
      }
    }

    n = windowlength / 2.0;
    if (2.0 > n) {
      i0 = 0;
      i1 = 0;
    } else {
      i0 = 1;
      i1 = (int)n;
    }

    d_factx = Vwindow->size[1];
    q = b_Vwindow->size[0] * b_Vwindow->size[1];
    b_Vwindow->size[0] = i1 - i0;
    b_Vwindow->size[1] = d_factx;
    emxEnsureCapacity((emxArray__common *)b_Vwindow, q, (int)sizeof(creal_T));
    for (q = 0; q < d_factx; q++) {
      loop_ub = i1 - i0;
      for (i2 = 0; i2 < loop_ub; i2++) {
        b_Vwindow->data[i2 + b_Vwindow->size[0] * q] = Vwindow->data[(i0 + i2) +
          Vwindow->size[0] * q];
      }
    }

    loop_ub = b_Vwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = b_Vwindow->size[0];
      for (i1 = 0; i1 < d_factx; i1++) {
        Vwindow->data[i1 + Vwindow->size[0] * i0] = b_Vwindow->data[i1 +
          b_Vwindow->size[0] * i0];
      }
    }

    n = windowlength / 2.0;
    if (2.0 > n) {
      i0 = 0;
      i1 = 0;
    } else {
      i0 = 1;
      i1 = (int)n;
    }

    d_factx = Wwindow->size[1];
    q = b_Wwindow->size[0] * b_Wwindow->size[1];
    b_Wwindow->size[0] = i1 - i0;
    b_Wwindow->size[1] = d_factx;
    emxEnsureCapacity((emxArray__common *)b_Wwindow, q, (int)sizeof(creal_T));
    for (q = 0; q < d_factx; q++) {
      loop_ub = i1 - i0;
      for (i2 = 0; i2 < loop_ub; i2++) {
        b_Wwindow->data[i2 + b_Wwindow->size[0] * q] = Wwindow->data[(i0 + i2) +
          Wwindow->size[0] * q];
      }
    }

    loop_ub = b_Wwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = b_Wwindow->size[0];
      for (i1 = 0; i1 < d_factx; i1++) {
        Wwindow->data[i1 + Wwindow->size[0] * i0] = b_Wwindow->data[i1 +
          b_Wwindow->size[0] * i0];
      }
    }

    loop_ub = Uwindow->size[1];
    d_factx = (int)(windowlength / 2.0);
    for (i0 = 0; i0 < loop_ub; i0++) {
      Uwindow->data[(d_factx + Uwindow->size[0] * i0) - 1].re = 0.0;
      Uwindow->data[(d_factx + Uwindow->size[0] * i0) - 1].im = 0.0;
    }

    loop_ub = Vwindow->size[1];
    d_factx = (int)(windowlength / 2.0);
    for (i0 = 0; i0 < loop_ub; i0++) {
      Vwindow->data[(d_factx + Vwindow->size[0] * i0) - 1].re = 0.0;
      Vwindow->data[(d_factx + Vwindow->size[0] * i0) - 1].im = 0.0;
    }

    loop_ub = Wwindow->size[1];
    d_factx = (int)(windowlength / 2.0);
    for (i0 = 0; i0 < loop_ub; i0++) {
      Wwindow->data[(d_factx + Wwindow->size[0] * i0) - 1].re = 0.0;
      Wwindow->data[(d_factx + Wwindow->size[0] * i0) - 1].im = 0.0;
    }

    //  POWER SPECTRA (auto-spectra)
    i0 = wwindow->size[0] * wwindow->size[1];
    wwindow->size[0] = Uwindow->size[0];
    wwindow->size[1] = Uwindow->size[1];
    emxEnsureCapacity((emxArray__common *)wwindow, i0, (int)sizeof(double));
    loop_ub = Uwindow->size[0] * Uwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      n = Uwindow->data[i0].re;
      bandwidth = -Uwindow->data[i0].im;
      n = Uwindow->data[i0].re * n - Uwindow->data[i0].im * bandwidth;
      wwindow->data[i0] = n;
    }

    i0 = xwindowtaper->size[0] * xwindowtaper->size[1];
    xwindowtaper->size[0] = Vwindow->size[0];
    xwindowtaper->size[1] = Vwindow->size[1];
    emxEnsureCapacity((emxArray__common *)xwindowtaper, i0, (int)sizeof(double));
    loop_ub = Vwindow->size[0] * Vwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      n = Vwindow->data[i0].re;
      bandwidth = -Vwindow->data[i0].im;
      n = Vwindow->data[i0].re * n - Vwindow->data[i0].im * bandwidth;
      xwindowtaper->data[i0] = n;
    }

    i0 = ywindowtaper->size[0] * ywindowtaper->size[1];
    ywindowtaper->size[0] = Wwindow->size[0];
    ywindowtaper->size[1] = Wwindow->size[1];
    emxEnsureCapacity((emxArray__common *)ywindowtaper, i0, (int)sizeof(double));
    loop_ub = Wwindow->size[0] * Wwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      n = Wwindow->data[i0].re;
      bandwidth = -Wwindow->data[i0].im;
      n = Wwindow->data[i0].re * n - Wwindow->data[i0].im * bandwidth;
      ywindowtaper->data[i0] = n;
    }

    //  CROSS-SPECTRA
    //  merge neighboring freq bands (number of bands to merge is a fixed parameter) 
    //  initialize
    x = std::floor(windowlength / 22.0);
    i0 = udetrend->size[0] * udetrend->size[1];
    udetrend->size[0] = (int)x;
    udetrend->size[1] = (int)windows;
    emxEnsureCapacity((emxArray__common *)udetrend, i0, (int)sizeof(double));
    loop_ub = (int)x * (int)windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      udetrend->data[i0] = 0.0;
    }

    x = std::floor(windowlength / 22.0);
    i0 = vdetrend->size[0] * vdetrend->size[1];
    vdetrend->size[0] = (int)x;
    vdetrend->size[1] = (int)windows;
    emxEnsureCapacity((emxArray__common *)vdetrend, i0, (int)sizeof(double));
    loop_ub = (int)x * (int)windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      vdetrend->data[i0] = 0.0;
    }

    x = std::floor(windowlength / 22.0);
    i0 = wdetrend->size[0] * wdetrend->size[1];
    wdetrend->size[0] = (int)x;
    wdetrend->size[1] = (int)windows;
    emxEnsureCapacity((emxArray__common *)wdetrend, i0, (int)sizeof(double));
    loop_ub = (int)x * (int)windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      wdetrend->data[i0] = 0.0;
    }

    i0 = (int)(windowlength / 2.0 / 11.0);
    for (mi = 0; mi < i0; mi++) {
      n = 11.0 + (double)mi * 11.0;
      if ((n - 11.0) + 1.0 > n) {
        i1 = 0;
        q = 0;
      } else {
        i1 = (int)((n - 11.0) + 1.0) - 1;
        q = (int)n;
      }

      loop_ub = wwindow->size[1];
      i2 = d_wwindow->size[0] * d_wwindow->size[1];
      d_wwindow->size[0] = q - i1;
      d_wwindow->size[1] = loop_ub;
      emxEnsureCapacity((emxArray__common *)d_wwindow, i2, (int)sizeof(double));
      for (i2 = 0; i2 < loop_ub; i2++) {
        d_factx = q - i1;
        for (e_factx = 0; e_factx < d_factx; e_factx++) {
          d_wwindow->data[e_factx + d_wwindow->size[0] * i2] = wwindow->data[(i1
            + e_factx) + wwindow->size[0] * i2];
        }
      }

      b_mean(d_wwindow, r17);
      d_factx = (int)(n / 11.0);
      loop_ub = r17->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        udetrend->data[(d_factx + udetrend->size[0] * i1) - 1] = r17->data
          [r17->size[0] * i1];
      }

      if ((n - 11.0) + 1.0 > n) {
        i1 = 0;
        q = 0;
      } else {
        i1 = (int)((n - 11.0) + 1.0) - 1;
        q = (int)n;
      }

      loop_ub = xwindowtaper->size[1];
      i2 = b_xwindowtaper->size[0] * b_xwindowtaper->size[1];
      b_xwindowtaper->size[0] = q - i1;
      b_xwindowtaper->size[1] = loop_ub;
      emxEnsureCapacity((emxArray__common *)b_xwindowtaper, i2, (int)sizeof
                        (double));
      for (i2 = 0; i2 < loop_ub; i2++) {
        d_factx = q - i1;
        for (e_factx = 0; e_factx < d_factx; e_factx++) {
          b_xwindowtaper->data[e_factx + b_xwindowtaper->size[0] * i2] =
            xwindowtaper->data[(i1 + e_factx) + xwindowtaper->size[0] * i2];
        }
      }

      b_mean(b_xwindowtaper, r16);
      d_factx = (int)(n / 11.0);
      loop_ub = r16->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        vdetrend->data[(d_factx + vdetrend->size[0] * i1) - 1] = r16->data
          [r16->size[0] * i1];
      }

      if ((n - 11.0) + 1.0 > n) {
        i1 = 0;
        q = 0;
      } else {
        i1 = (int)((n - 11.0) + 1.0) - 1;
        q = (int)n;
      }

      loop_ub = ywindowtaper->size[1];
      i2 = b_ywindowtaper->size[0] * b_ywindowtaper->size[1];
      b_ywindowtaper->size[0] = q - i1;
      b_ywindowtaper->size[1] = loop_ub;
      emxEnsureCapacity((emxArray__common *)b_ywindowtaper, i2, (int)sizeof
                        (double));
      for (i2 = 0; i2 < loop_ub; i2++) {
        d_factx = q - i1;
        for (e_factx = 0; e_factx < d_factx; e_factx++) {
          b_ywindowtaper->data[e_factx + b_ywindowtaper->size[0] * i2] =
            ywindowtaper->data[(i1 + e_factx) + ywindowtaper->size[0] * i2];
        }
      }

      b_mean(b_ywindowtaper, r15);
      d_factx = (int)(n / 11.0);
      loop_ub = r15->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        wdetrend->data[(d_factx + wdetrend->size[0] * i1) - 1] = r15->data
          [r15->size[0] * i1];
      }
    }

    //  freq range and bandwidth
    n = windowlength / 2.0 / 11.0;

    //  number of f bands
    //  highest spectral frequency
    bandwidth = 0.5 * fs / n;

    //  freq (Hz) bandwitdh
    //  find middle of each freq band, ONLY WORKS WHEN MERGING ODD NUMBER OF BANDS! 
    y = bandwidth / 2.0;
    if (n - 1.0 < 0.0) {
      i0 = f->size[0] * f->size[1];
      f->size[0] = 1;
      f->size[1] = 0;
      emxEnsureCapacity((emxArray__common *)f, i0, (int)sizeof(double));
    } else if (rtIsInf(n - 1.0) && (0.0 == n - 1.0)) {
      i0 = f->size[0] * f->size[1];
      f->size[0] = 1;
      f->size[1] = 1;
      emxEnsureCapacity((emxArray__common *)f, i0, (int)sizeof(double));
      f->data[0] = rtNaN;
    } else {
      i0 = f->size[0] * f->size[1];
      f->size[0] = 1;
      f->size[1] = (int)std::floor(n - 1.0) + 1;
      emxEnsureCapacity((emxArray__common *)f, i0, (int)sizeof(double));
      loop_ub = (int)std::floor(n - 1.0);
      for (i0 = 0; i0 <= loop_ub; i0++) {
        f->data[f->size[0] * i0] = i0;
      }
    }

    i0 = f->size[0] * f->size[1];
    f->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)f, i0, (int)sizeof(double));
    d_factx = f->size[0];
    e_factx = f->size[1];
    loop_ub = d_factx * e_factx;
    for (i0 = 0; i0 < loop_ub; i0++) {
      f->data[i0] = (0.00390625 + y) + bandwidth * f->data[i0];
    }

    //  normalize (to get spectral density)... divide by N*samplerate to get power spectral density 
    //  the two is b/c Matlab's fft output is the symmetric FFT, and we did not use the redundant half (so need to multiply the psd by 2) 
    n = windowlength / 2.0 * fs;
    i0 = udetrend->size[0] * udetrend->size[1];
    emxEnsureCapacity((emxArray__common *)udetrend, i0, (int)sizeof(double));
    d_factx = udetrend->size[0];
    e_factx = udetrend->size[1];
    loop_ub = d_factx * e_factx;
    for (i0 = 0; i0 < loop_ub; i0++) {
      udetrend->data[i0] /= n;
    }

    n = windowlength / 2.0 * fs;
    i0 = vdetrend->size[0] * vdetrend->size[1];
    emxEnsureCapacity((emxArray__common *)vdetrend, i0, (int)sizeof(double));
    d_factx = vdetrend->size[0];
    e_factx = vdetrend->size[1];
    loop_ub = d_factx * e_factx;
    for (i0 = 0; i0 < loop_ub; i0++) {
      vdetrend->data[i0] /= n;
    }

    n = windowlength / 2.0 * fs;
    i0 = wdetrend->size[0] * wdetrend->size[1];
    emxEnsureCapacity((emxArray__common *)wdetrend, i0, (int)sizeof(double));
    d_factx = wdetrend->size[0];
    e_factx = wdetrend->size[1];
    loop_ub = d_factx * e_factx;
    for (i0 = 0; i0 < loop_ub; i0++) {
      wdetrend->data[i0] /= n;
    }

    //   find interial sub range (hard wired or dynamic),
    //  then get dissipation rate and ustar using the vertical component
    //  do this for each window, rather than ensemble spectra,
    //  because the advected velocity might change between windows (if vehicle turns, etc) 
    //  inertial sub-range, min freq
    //  inertial sub-range, max freq
    i0 = r1->size[0] * r1->size[1];
    r1->size[0] = 1;
    r1->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)r1, i0, (int)sizeof(boolean_T));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r1->data[i0] = (f->data[i0] > 2.0);
    }

    i0 = r2->size[0] * r2->size[1];
    r2->size[0] = 1;
    r2->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)r2, i0, (int)sizeof(boolean_T));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r2->data[i0] = (f->data[i0] < 4.9);
    }

    mi = r1->size[1] - 1;
    d_factx = 0;
    for (e_factx = 0; e_factx <= mi; e_factx++) {
      if (r1->data[e_factx] && r2->data[e_factx]) {
        d_factx++;
      }
    }

    i0 = r5->size[0] * r5->size[1];
    r5->size[0] = 1;
    r5->size[1] = d_factx;
    emxEnsureCapacity((emxArray__common *)r5, i0, (int)sizeof(int));
    d_factx = 0;
    for (e_factx = 0; e_factx <= mi; e_factx++) {
      if (r1->data[e_factx] && r2->data[e_factx]) {
        r5->data[d_factx] = e_factx + 1;
        d_factx++;
      }
    }

    i0 = c_f->size[0];
    c_f->size[0] = r5->size[1];
    emxEnsureCapacity((emxArray__common *)c_f, i0, (int)sizeof(double));
    loop_ub = r5->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      c_f->data[i0] = f->data[r5->data[r5->size[0] * i0] - 1];
    }

    power(c_f, a);
    mi = r1->size[1] - 1;
    d_factx = 0;
    for (e_factx = 0; e_factx <= mi; e_factx++) {
      if (r1->data[e_factx] && r2->data[e_factx]) {
        d_factx++;
      }
    }

    i0 = r5->size[0] * r5->size[1];
    r5->size[0] = 1;
    r5->size[1] = d_factx;
    emxEnsureCapacity((emxArray__common *)r5, i0, (int)sizeof(int));
    d_factx = 0;
    for (e_factx = 0; e_factx <= mi; e_factx++) {
      if (r1->data[e_factx] && r2->data[e_factx]) {
        r5->data[d_factx] = e_factx + 1;
        d_factx++;
      }
    }

    i0 = d_a->size[0] * d_a->size[1];
    d_a->size[0] = a->size[0];
    d_a->size[1] = (int)windows;
    emxEnsureCapacity((emxArray__common *)d_a, i0, (int)sizeof(double));
    loop_ub = a->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = (int)windows;
      for (i1 = 0; i1 < d_factx; i1++) {
        d_a->data[i0 + d_a->size[0] * i1] = a->data[i0];
      }
    }

    i0 = c_a->size[0] * c_a->size[1];
    c_a->size[0] = d_a->size[0];
    c_a->size[1] = d_a->size[1];
    emxEnsureCapacity((emxArray__common *)c_a, i0, (int)sizeof(double));
    loop_ub = d_a->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = d_a->size[0];
      for (i1 = 0; i1 < d_factx; i1++) {
        c_a->data[i1 + c_a->size[0] * i0] = d_a->data[i1 + d_a->size[0] * i0] *
          wdetrend->data[(r5->data[r5->size[0] * i1] + wdetrend->size[0] * i0) -
          1];
      }
    }

    b_mean(c_a, factz);

    //  average value of compensated spectra
    mi = r1->size[1] - 1;
    d_factx = 0;
    for (e_factx = 0; e_factx <= mi; e_factx++) {
      if (r1->data[e_factx] && r2->data[e_factx]) {
        d_factx++;
      }
    }

    i0 = r5->size[0] * r5->size[1];
    r5->size[0] = 1;
    r5->size[1] = d_factx;
    emxEnsureCapacity((emxArray__common *)r5, i0, (int)sizeof(int));
    d_factx = 0;
    for (e_factx = 0; e_factx <= mi; e_factx++) {
      if (r1->data[e_factx] && r2->data[e_factx]) {
        r5->data[d_factx] = e_factx + 1;
        d_factx++;
      }
    }

    i0 = b_f->size[0];
    b_f->size[0] = r5->size[1];
    emxEnsureCapacity((emxArray__common *)b_f, i0, (int)sizeof(double));
    loop_ub = r5->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_f->data[i0] = f->data[r5->data[r5->size[0] * i0] - 1];
    }

    power(b_f, a);
    mi = r1->size[1] - 1;
    d_factx = 0;
    for (e_factx = 0; e_factx <= mi; e_factx++) {
      if (r1->data[e_factx] && r2->data[e_factx]) {
        d_factx++;
      }
    }

    i0 = r5->size[0] * r5->size[1];
    r5->size[0] = 1;
    r5->size[1] = d_factx;
    emxEnsureCapacity((emxArray__common *)r5, i0, (int)sizeof(int));
    d_factx = 0;
    for (e_factx = 0; e_factx <= mi; e_factx++) {
      if (r1->data[e_factx] && r2->data[e_factx]) {
        r5->data[d_factx] = e_factx + 1;
        d_factx++;
      }
    }

    i0 = e_a->size[0] * e_a->size[1];
    e_a->size[0] = a->size[0];
    e_a->size[1] = (int)windows;
    emxEnsureCapacity((emxArray__common *)e_a, i0, (int)sizeof(double));
    loop_ub = a->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = (int)windows;
      for (i1 = 0; i1 < d_factx; i1++) {
        e_a->data[i0 + e_a->size[0] * i1] = a->data[i0];
      }
    }

    i0 = b_a->size[0] * b_a->size[1];
    b_a->size[0] = e_a->size[0];
    b_a->size[1] = e_a->size[1];
    emxEnsureCapacity((emxArray__common *)b_a, i0, (int)sizeof(double));
    loop_ub = e_a->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = e_a->size[0];
      for (i1 = 0; i1 < d_factx; i1++) {
        b_a->data[i1 + b_a->size[0] * i0] = e_a->data[i1 + e_a->size[0] * i0] *
          wdetrend->data[(r5->data[r5->size[0] * i1] + wdetrend->size[0] * i0) -
          1];
      }
    }

    var(b_a, facty);
    b_sqrt(facty);

    //  average value of compensated spectra
    b_mean(uwindow, r6);
    b_power(r6, r7);
    b_mean(vwindow, r6);
    b_power(r6, factx);
    i0 = r11->size[0] * r11->size[1];
    r11->size[0] = 1;
    r11->size[1] = r7->size[1];
    emxEnsureCapacity((emxArray__common *)r11, i0, (int)sizeof(double));
    loop_ub = r7->size[0] * r7->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r11->data[i0] = r7->data[i0] + factx->data[i0];
    }

    c_power(r11, advectionspeed);

    //  speed at which frozen field turbulence is advected past sensor
    b_rdivide(advectionspeed, r6);
    d_power(r6, r7);
    i0 = r10->size[0] * r10->size[1];
    r10->size[0] = 1;
    r10->size[1] = r7->size[1];
    emxEnsureCapacity((emxArray__common *)r10, i0, (int)sizeof(double));
    loop_ub = r7->size[0] * r7->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r10->data[i0] = r7->data[i0] * 0.73333333333333339;
    }

    rdivide(factz, r10, r6);
    e_power(r6, epsilonwindow);
    i0 = r9->size[0] * r9->size[1];
    r9->size[0] = 1;
    r9->size[1] = epsilonwindow->size[1];
    emxEnsureCapacity((emxArray__common *)r9, i0, (int)sizeof(double));
    loop_ub = epsilonwindow->size[0] * epsilonwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r9->data[i0] = 0.4 * epsilonwindow->data[i0] * z;
    }

    f_power(r9, ustarwindow);

    //  assumes neutral
    //  quality metrics
    i0 = c_factz->size[0] * c_factz->size[1];
    c_factz->size[0] = 1;
    c_factz->size[1] = factz->size[1];
    emxEnsureCapacity((emxArray__common *)c_factz, i0, (int)sizeof(double));
    loop_ub = factz->size[0] * factz->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      c_factz->data[i0] = factz->data[i0] - facty->data[i0];
    }

    rdivide(c_factz, factz, factx);

    //  quality of fit in ISR
    // qualitywindow = WWwindowmerged(1,:)./WWwindowmerged(end,:); % low frequency contamination 
    // qualitywindow = ( std(uwindow) + std(vwindow) )./ advectionspeed; % advective speed variations 
    //  ensemble average windows together
    //  take the average of all windows at each freq-band
    i0 = b_udetrend->size[0] * b_udetrend->size[1];
    b_udetrend->size[0] = udetrend->size[1];
    b_udetrend->size[1] = udetrend->size[0];
    emxEnsureCapacity((emxArray__common *)b_udetrend, i0, (int)sizeof(double));
    loop_ub = udetrend->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = udetrend->size[1];
      for (i1 = 0; i1 < d_factx; i1++) {
        b_udetrend->data[i1 + b_udetrend->size[0] * i0] = udetrend->data[i0 +
          udetrend->size[0] * i1];
      }
    }

    b_mean(b_udetrend, facty);
    i0 = b_vdetrend->size[0] * b_vdetrend->size[1];
    b_vdetrend->size[0] = vdetrend->size[1];
    b_vdetrend->size[1] = vdetrend->size[0];
    emxEnsureCapacity((emxArray__common *)b_vdetrend, i0, (int)sizeof(double));
    loop_ub = vdetrend->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = vdetrend->size[1];
      for (i1 = 0; i1 < d_factx; i1++) {
        b_vdetrend->data[i1 + b_vdetrend->size[0] * i0] = vdetrend->data[i0 +
          vdetrend->size[0] * i1];
      }
    }

    b_mean(b_vdetrend, factz);
    i0 = b_wdetrend->size[0] * b_wdetrend->size[1];
    b_wdetrend->size[0] = wdetrend->size[1];
    b_wdetrend->size[1] = wdetrend->size[0];
    emxEnsureCapacity((emxArray__common *)b_wdetrend, i0, (int)sizeof(double));
    loop_ub = wdetrend->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_factx = wdetrend->size[1];
      for (i1 = 0; i1 < d_factx; i1++) {
        b_wdetrend->data[i1 + b_wdetrend->size[0] * i0] = wdetrend->data[i0 +
          wdetrend->size[0] * i1];
      }
    }

    b_mean(b_wdetrend, WW);

    //  find the windows with stable mean in the streamwise direction, use only those for ustar and epsilon ensembles 
    b_mean(uwindow, r6);
    b_abs(r6, r7);
    var(uwindow, r6);
    b_sqrt(r6);

    // disp('stable windows'), sum(good) % debug
    i0 = r8->size[0] * r8->size[1];
    r8->size[0] = 1;
    r8->size[1] = r7->size[1];
    emxEnsureCapacity((emxArray__common *)r8, i0, (int)sizeof(boolean_T));
    loop_ub = r7->size[0] * r7->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r8->data[i0] = (r7->data[i0] > r6->data[i0]);
    }

    if (b_sum(r8) >= 2.0) {
      mi = r7->size[1] - 1;
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (r7->data[e_factx] > r6->data[e_factx]) {
          d_factx++;
        }
      }

      i0 = r5->size[0] * r5->size[1];
      r5->size[0] = 1;
      r5->size[1] = d_factx;
      emxEnsureCapacity((emxArray__common *)r5, i0, (int)sizeof(int));
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (r7->data[e_factx] > r6->data[e_factx]) {
          r5->data[d_factx] = e_factx + 1;
          d_factx++;
        }
      }

      i0 = b_epsilonwindow->size[0] * b_epsilonwindow->size[1];
      b_epsilonwindow->size[0] = 1;
      b_epsilonwindow->size[1] = r5->size[1];
      emxEnsureCapacity((emxArray__common *)b_epsilonwindow, i0, (int)sizeof
                        (double));
      loop_ub = r5->size[0] * r5->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        b_epsilonwindow->data[i0] = epsilonwindow->data[r5->data[i0] - 1];
      }

      *epsilon = c_mean(b_epsilonwindow);
      mi = r7->size[1] - 1;
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (r7->data[e_factx] > r6->data[e_factx]) {
          d_factx++;
        }
      }

      i0 = r5->size[0] * r5->size[1];
      r5->size[0] = 1;
      r5->size[1] = d_factx;
      emxEnsureCapacity((emxArray__common *)r5, i0, (int)sizeof(int));
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (r7->data[e_factx] > r6->data[e_factx]) {
          r5->data[d_factx] = e_factx + 1;
          d_factx++;
        }
      }

      i0 = b_ustarwindow->size[0] * b_ustarwindow->size[1];
      b_ustarwindow->size[0] = 1;
      b_ustarwindow->size[1] = r5->size[1];
      emxEnsureCapacity((emxArray__common *)b_ustarwindow, i0, (int)sizeof
                        (double));
      loop_ub = r5->size[0] * r5->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        b_ustarwindow->data[i0] = ustarwindow->data[r5->data[i0] - 1];
      }

      *ustar = c_mean(b_ustarwindow);
      mi = r7->size[1] - 1;
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (r7->data[e_factx] > r6->data[e_factx]) {
          d_factx++;
        }
      }

      i0 = r5->size[0] * r5->size[1];
      r5->size[0] = 1;
      r5->size[1] = d_factx;
      emxEnsureCapacity((emxArray__common *)r5, i0, (int)sizeof(int));
      d_factx = 0;
      for (e_factx = 0; e_factx <= mi; e_factx++) {
        if (r7->data[e_factx] > r6->data[e_factx]) {
          r5->data[d_factx] = e_factx + 1;
          d_factx++;
        }
      }

      i0 = c_factx->size[0] * c_factx->size[1];
      c_factx->size[0] = 1;
      c_factx->size[1] = r5->size[1];
      emxEnsureCapacity((emxArray__common *)c_factx, i0, (int)sizeof(double));
      loop_ub = r5->size[0] * r5->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        c_factx->data[i0] = factx->data[r5->data[i0] - 1];
      }

      *quality = c_mean(c_factx);
    } else {
      *ustar = 9999.0;
      *epsilon = 9999.0;
      *quality = c_mean(factx);
    }

    //  sum component spectra to get proxy for TKE spectra
    i0 = factx->size[0] * factx->size[1];
    factx->size[0] = 1;
    factx->size[1] = facty->size[1];
    emxEnsureCapacity((emxArray__common *)factx, i0, (int)sizeof(double));
    loop_ub = facty->size[0] * facty->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      factx->data[i0] = (facty->data[i0] + factz->data[i0]) + WW->data[i0];
    }

    //  !!! Mike S: Fix output to exactly length 116 - Assumes: wsecs = 256,
    //  merge = 11, fs = 10 !!!
    for (i0 = 0; i0 < 116; i0++) {
      tkespectrum[i0] = factx->data[i0];
    }

    for (i0 = 0; i0 < 116; i0++) {
      freq[i0] = f->data[i0];
    }

    //  anisotropy
    mi = r1->size[1] - 1;
    d_factx = 0;
    for (e_factx = 0; e_factx <= mi; e_factx++) {
      if (r1->data[e_factx] && r2->data[e_factx]) {
        d_factx++;
      }
    }

    i0 = r5->size[0] * r5->size[1];
    r5->size[0] = 1;
    r5->size[1] = d_factx;
    emxEnsureCapacity((emxArray__common *)r5, i0, (int)sizeof(int));
    d_factx = 0;
    for (e_factx = 0; e_factx <= mi; e_factx++) {
      if (r1->data[e_factx] && r2->data[e_factx]) {
        r5->data[d_factx] = e_factx + 1;
        d_factx++;
      }
    }

    i0 = b_facty->size[0] * b_facty->size[1];
    b_facty->size[0] = 1;
    b_facty->size[1] = r5->size[1];
    emxEnsureCapacity((emxArray__common *)b_facty, i0, (int)sizeof(double));
    loop_ub = r5->size[0] * r5->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_facty->data[i0] = facty->data[r5->data[i0] - 1];
    }

    x = c_mean(b_facty);
    i0 = c_WW->size[0] * c_WW->size[1];
    c_WW->size[0] = 1;
    c_WW->size[1] = r5->size[1];
    emxEnsureCapacity((emxArray__common *)c_WW, i0, (int)sizeof(double));
    loop_ub = r5->size[0] * r5->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      c_WW->data[i0] = WW->data[r5->data[i0] - 1];
    }

    y = c_mean(c_WW);
    i0 = b_factz->size[0] * b_factz->size[1];
    b_factz->size[0] = 1;
    b_factz->size[1] = r5->size[1];
    emxEnsureCapacity((emxArray__common *)b_factz, i0, (int)sizeof(double));
    loop_ub = r5->size[0] * r5->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_factz->data[i0] = factz->data[r5->data[i0] - 1];
    }

    n = c_mean(b_factz);
    i0 = b_WW->size[0] * b_WW->size[1];
    b_WW->size[0] = 1;
    b_WW->size[1] = r5->size[1];
    emxEnsureCapacity((emxArray__common *)b_WW, i0, (int)sizeof(double));
    loop_ub = r5->size[0] * r5->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_WW->data[i0] = WW->data[r5->data[i0] - 1];
    }

    bandwidth = c_mean(b_WW);
    *anisotropy = (x / y + n / bandwidth) / 2.0;

    //  Quality control (check ustar against drag law)
    b_power(advectionspeed, r6);
    c_rdivide(*ustar * *ustar, r6, factx);
    i0 = b_factx->size[0] * b_factx->size[1];
    b_factx->size[0] = 1;
    b_factx->size[1] = factx->size[1] + factx->size[1];
    emxEnsureCapacity((emxArray__common *)b_factx, i0, (int)sizeof(boolean_T));
    loop_ub = factx->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_factx->data[b_factx->size[0] * i0] = (factx->data[factx->size[0] * i0] >
        0.01);
    }

    loop_ub = factx->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_factx->data[b_factx->size[0] * (i0 + factx->size[1])] = (factx->
        data[factx->size[0] * i0] < 1.0E-5);
    }

    QCflag = all(b_factx);

    //  housekeeping
  } else {
    //  if not enough points or sufficent sampling rate or data, give 9999
    *ustar = 9999.0;
    *epsilon = 9999.0;

    //  !!! Mike S: Fix output to exactly length 116 - Assumes: wsecs = 256,
    //  merge = 11, fs = 10 !!!
    for (i0 = 0; i0 < 116; i0++) {
      freq[i0] = 9999.0;
      tkespectrum[i0] = 9999.0;
    }

    *anisotropy = 9999.0;
    QCflag = true;
    *quality = 0.0;
  }

  emxFree_real_T(&e_a);
  emxFree_real_T(&d_a);
  emxFree_creal_T(&b_Wwindow);
  emxFree_creal_T(&b_Vwindow);
  emxFree_creal_T(&b_Uwindow);
  emxFree_real_T(&r20);
  emxFree_real_T(&r19);
  emxFree_real_T(&r18);
  emxFree_real_T(&r17);
  emxFree_real_T(&d_wwindow);
  emxFree_real_T(&r16);
  emxFree_real_T(&b_xwindowtaper);
  emxFree_real_T(&r15);
  emxFree_real_T(&b_ywindowtaper);
  emxFree_real_T(&c_uwindow);
  emxFree_real_T(&c_vwindow);
  emxFree_real_T(&c_wwindow);
  emxFree_real_T(&b_uwindow);
  emxFree_real_T(&b_vwindow);
  emxFree_real_T(&b_wwindow);
  emxFree_real_T(&r14);
  emxFree_real_T(&r13);
  emxFree_real_T(&r12);
  emxFree_int32_T(&d_windowlength);
  emxFree_int32_T(&c_windowlength);
  emxFree_int32_T(&b_windowlength);
  emxFree_real_T(&c_f);
  emxFree_real_T(&c_a);
  emxFree_real_T(&b_f);
  emxFree_real_T(&b_a);
  emxFree_real_T(&r11);
  emxFree_real_T(&r10);
  emxFree_real_T(&r9);
  emxFree_real_T(&c_factz);
  emxFree_real_T(&b_udetrend);
  emxFree_real_T(&b_vdetrend);
  emxFree_real_T(&b_wdetrend);
  emxFree_boolean_T(&r8);
  emxFree_real_T(&b_epsilonwindow);
  emxFree_real_T(&b_ustarwindow);
  emxFree_real_T(&c_factx);
  emxFree_real_T(&b_facty);
  emxFree_real_T(&c_WW);
  emxFree_real_T(&b_factz);
  emxFree_real_T(&b_WW);
  emxFree_boolean_T(&b_factx);
  emxFree_real_T(&r7);
  emxFree_real_T(&r6);
  emxFree_real_T(&a);
  emxFree_int32_T(&r5);
  emxFree_int32_T(&r4);
  emxFree_int32_T(&r3);
  emxFree_boolean_T(&r2);
  emxFree_boolean_T(&r1);
  emxFree_boolean_T(&r0);
  emxFree_real_T(&WW);
  emxFree_real_T(&ustarwindow);
  emxFree_real_T(&epsilonwindow);
  emxFree_real_T(&advectionspeed);
  emxFree_real_T(&f);
  emxFree_creal_T(&Wwindow);
  emxFree_creal_T(&Vwindow);
  emxFree_creal_T(&Uwindow);
  emxFree_real_T(&factz);
  emxFree_real_T(&facty);
  emxFree_real_T(&factx);
  emxFree_real_T(&ywindowtaper);
  emxFree_real_T(&xwindowtaper);
  emxFree_real_T(&wdetrend);
  emxFree_real_T(&vdetrend);
  emxFree_real_T(&udetrend);
  emxFree_real_T(&wwindow);
  emxFree_real_T(&vwindow);
  emxFree_real_T(&uwindow);
  emxFree_boolean_T(&bad);

  //  quality control
  if (QCflag) {
    *ustar = 9999.0;
    *epsilon = 9999.0;
  }
}

//
// File trailer for inertialdissipation.cpp
//
// [EOF]
//
