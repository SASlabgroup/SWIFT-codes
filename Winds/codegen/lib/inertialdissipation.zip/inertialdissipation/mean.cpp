//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: mean.cpp
//
// MATLAB Coder version            : 3.2
// C/C++ source code generated on  : 10-Nov-2016 11:31:38
//

// Include Files
#include "rt_nonfinite.h"
#include "inertialdissipation.h"
#include "mean.h"
#include "inertialdissipation_emxutil.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *x
//                emxArray_real_T *y
// Return Type  : void
//
void b_mean(const emxArray_real_T *x, emxArray_real_T *y)
{
  int i;
  int vlen;
  int xoffset;
  double s;
  int k;
  i = y->size[0] * y->size[1];
  y->size[0] = 1;
  y->size[1] = x->size[1];
  emxEnsureCapacity((emxArray__common *)y, i, (int)sizeof(double));
  if ((x->size[0] == 0) || (x->size[1] == 0)) {
    i = y->size[0] * y->size[1];
    y->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)y, i, (int)sizeof(double));
    vlen = y->size[1];
    for (i = 0; i < vlen; i++) {
      y->data[y->size[0] * i] = 0.0;
    }
  } else {
    vlen = x->size[0];
    for (i = 0; i + 1 <= x->size[1]; i++) {
      xoffset = i * vlen;
      s = x->data[xoffset];
      for (k = 2; k <= vlen; k++) {
        s += x->data[(xoffset + k) - 1];
      }

      y->data[i] = s;
    }
  }

  i = y->size[0] * y->size[1];
  y->size[0] = 1;
  emxEnsureCapacity((emxArray__common *)y, i, (int)sizeof(double));
  i = y->size[0];
  vlen = y->size[1];
  xoffset = x->size[0];
  vlen *= i;
  for (i = 0; i < vlen; i++) {
    y->data[i] /= (double)xoffset;
  }
}

//
// Arguments    : const emxArray_real_T *x
// Return Type  : double
//
double c_mean(const emxArray_real_T *x)
{
  double y;
  int k;
  if (x->size[1] == 0) {
    y = 0.0;
  } else {
    y = x->data[0];
    for (k = 2; k <= x->size[1]; k++) {
      y += x->data[k - 1];
    }
  }

  y /= (double)x->size[1];
  return y;
}

//
// Arguments    : const emxArray_real_T *x
// Return Type  : double
//
double mean(const emxArray_real_T *x)
{
  double y;
  int k;
  if (x->size[0] == 0) {
    y = 0.0;
  } else {
    y = x->data[0];
    for (k = 2; k <= x->size[0]; k++) {
      y += x->data[k - 1];
    }
  }

  y /= (double)x->size[0];
  return y;
}

//
// File trailer for mean.cpp
//
// [EOF]
//
