//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: inertialdissipation.h
//
// MATLAB Coder version            : 3.2
// C/C++ source code generated on  : 10-Nov-2016 11:31:38
//
#ifndef INERTIALDISSIPATION_H
#define INERTIALDISSIPATION_H

// Include Files
#include <cmath>
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "inertialdissipation_types.h"

// Function Declarations
extern void inertialdissipation(emxArray_real_T *u, emxArray_real_T *v,
  emxArray_real_T *w, emxArray_real_T *temp, double z, double fs, double *ustar,
  double *epsilon, double *meanu, double *meanv, double *meanw, double *meantemp,
  double *anisotropy, double *quality, double freq[116], double tkespectrum[116]);

#endif

//
// File trailer for inertialdissipation.h
//
// [EOF]
//
