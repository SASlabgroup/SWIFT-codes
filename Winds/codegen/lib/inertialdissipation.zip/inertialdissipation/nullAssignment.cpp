//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: nullAssignment.cpp
//
// MATLAB Coder version            : 3.2
// C/C++ source code generated on  : 10-Nov-2016 11:31:38
//

// Include Files
#include "rt_nonfinite.h"
#include "inertialdissipation.h"
#include "nullAssignment.h"
#include "inertialdissipation_emxutil.h"

// Function Definitions

//
// Arguments    : emxArray_creal_T *x
//                const emxArray_int32_T *idx
// Return Type  : void
//
void b_nullAssignment(emxArray_creal_T *x, const emxArray_int32_T *idx)
{
  int nrowx;
  int ncolx;
  emxArray_boolean_T *b;
  int nrows;
  int j;
  int i;
  int loop_ub;
  emxArray_creal_T *b_x;
  nrowx = x->size[0];
  ncolx = x->size[1];
  if (idx->size[1] == 1) {
    nrows = x->size[0] - 1;
    for (j = 0; j + 1 <= ncolx; j++) {
      for (i = idx->data[0]; i < nrowx; i++) {
        x->data[(i + x->size[0] * j) - 1] = x->data[i + x->size[0] * j];
      }
    }
  } else {
    emxInit_boolean_T1(&b, 2);
    j = b->size[0] * b->size[1];
    b->size[0] = 1;
    b->size[1] = x->size[0];
    emxEnsureCapacity((emxArray__common *)b, j, (int)sizeof(boolean_T));
    loop_ub = x->size[0];
    for (j = 0; j < loop_ub; j++) {
      b->data[j] = false;
    }

    for (loop_ub = 1; loop_ub <= idx->size[1]; loop_ub++) {
      b->data[idx->data[loop_ub - 1] - 1] = true;
    }

    nrows = 0;
    for (loop_ub = 1; loop_ub <= b->size[1]; loop_ub++) {
      nrows += b->data[loop_ub - 1];
    }

    nrows = x->size[0] - nrows;
    i = 0;
    for (loop_ub = 1; loop_ub <= nrowx; loop_ub++) {
      if ((loop_ub > b->size[1]) || (!b->data[loop_ub - 1])) {
        for (j = 0; j + 1 <= ncolx; j++) {
          x->data[i + x->size[0] * j] = x->data[(loop_ub + x->size[0] * j) - 1];
        }

        i++;
      }
    }

    emxFree_boolean_T(&b);
  }

  if (1 > nrows) {
    loop_ub = 0;
  } else {
    loop_ub = nrows;
  }

  emxInit_creal_T(&b_x, 2);
  nrows = x->size[1];
  j = b_x->size[0] * b_x->size[1];
  b_x->size[0] = loop_ub;
  b_x->size[1] = nrows;
  emxEnsureCapacity((emxArray__common *)b_x, j, (int)sizeof(creal_T));
  for (j = 0; j < nrows; j++) {
    for (i = 0; i < loop_ub; i++) {
      b_x->data[i + b_x->size[0] * j] = x->data[i + x->size[0] * j];
    }
  }

  j = x->size[0] * x->size[1];
  x->size[0] = b_x->size[0];
  x->size[1] = b_x->size[1];
  emxEnsureCapacity((emxArray__common *)x, j, (int)sizeof(creal_T));
  loop_ub = b_x->size[1];
  for (j = 0; j < loop_ub; j++) {
    nrows = b_x->size[0];
    for (i = 0; i < nrows; i++) {
      x->data[i + x->size[0] * j] = b_x->data[i + b_x->size[0] * j];
    }
  }

  emxFree_creal_T(&b_x);
}

//
// Arguments    : emxArray_real_T *x
//                const emxArray_boolean_T *idx
// Return Type  : void
//
void nullAssignment(emxArray_real_T *x, const emxArray_boolean_T *idx)
{
  int nxin;
  int k0;
  int k;
  int nxout;
  emxArray_real_T *b_x;
  nxin = x->size[0];
  k0 = 0;
  for (k = 1; k <= idx->size[0]; k++) {
    k0 += idx->data[k - 1];
  }

  nxout = x->size[0] - k0;
  k0 = -1;
  for (k = 1; k <= nxin; k++) {
    if ((k > idx->size[0]) || (!idx->data[k - 1])) {
      k0++;
      x->data[k0] = x->data[k - 1];
    }
  }

  if (1 > nxout) {
    k0 = 0;
  } else {
    k0 = nxout;
  }

  emxInit_real_T1(&b_x, 1);
  nxout = b_x->size[0];
  b_x->size[0] = k0;
  emxEnsureCapacity((emxArray__common *)b_x, nxout, (int)sizeof(double));
  for (nxout = 0; nxout < k0; nxout++) {
    b_x->data[nxout] = x->data[nxout];
  }

  nxout = x->size[0];
  x->size[0] = b_x->size[0];
  emxEnsureCapacity((emxArray__common *)x, nxout, (int)sizeof(double));
  k0 = b_x->size[0];
  for (nxout = 0; nxout < k0; nxout++) {
    x->data[nxout] = b_x->data[nxout];
  }

  emxFree_real_T(&b_x);
}

//
// File trailer for nullAssignment.cpp
//
// [EOF]
//
