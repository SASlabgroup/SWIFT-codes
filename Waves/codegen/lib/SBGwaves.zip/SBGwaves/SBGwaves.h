/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * SBGwaves.h
 *
 * Code generation for function 'SBGwaves'
 *
 */

#ifndef SBGWAVES_H
#define SBGWAVES_H

/* Include files */
#include <cmath>
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_defines.h"
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "SBGwaves_types.h"

/* Function Declarations */
extern void SBGwaves(const emxArray_real_T *u, const emxArray_real_T *v, const
                     emxArray_real_T *heave, double fs, double *Hs, double *Tp,
                     double *Dp, double E[42], double f[42], double a1[42],
                     double b1[42], double a2[42], double b2[42], double check
                     [42]);

#endif

/* End of code generation (SBGwaves.h) */
