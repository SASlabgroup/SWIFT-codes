/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * SBGwaves_terminate.cpp
 *
 * Code generation for function 'SBGwaves_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "SBGwaves.h"
#include "SBGwaves_terminate.h"

/* Function Definitions */
void SBGwaves_terminate()
{
  /* (no terminate code required) */
}

/* End of code generation (SBGwaves_terminate.cpp) */
