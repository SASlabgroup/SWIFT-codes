/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * var.cpp
 *
 * Code generation for function 'var'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "SBGwaves.h"
#include "var.h"
#include "SBGwaves_emxutil.h"

/* Function Definitions */
void var(const emxArray_real_T *x, emxArray_real_T *y)
{
  int environment_idx_0;
  int i3;
  unsigned int szy[2];
  int loop_ub;
  int nx;
  int p;
  emxArray_real_T *xv;
  int outsize_idx_0;
  int n;
  int b_environment_idx_0;
  double xbar;
  double yv;
  double t;
  environment_idx_0 = x->size[0];
  for (i3 = 0; i3 < 2; i3++) {
    szy[i3] = (unsigned int)x->size[i3];
  }

  i3 = y->size[0] * y->size[1];
  y->size[0] = 1;
  y->size[1] = (int)szy[1];
  emxEnsureCapacity_real_T(y, i3);
  loop_ub = (int)szy[1];
  for (i3 = 0; i3 < loop_ub; i3++) {
    y->data[i3] = 0.0;
  }

  nx = x->size[0];
  p = 0;
  emxInit_real_T1(&xv, 1);
  if (1 <= x->size[1]) {
    outsize_idx_0 = nx;
    n = environment_idx_0;
  }

  while (p + 1 <= x->size[1]) {
    b_environment_idx_0 = p * nx + 1;
    i3 = xv->size[0];
    xv->size[0] = outsize_idx_0;
    emxEnsureCapacity_real_T1(xv, i3);
    for (i3 = 0; i3 < outsize_idx_0; i3++) {
      xv->data[i3] = 0.0;
    }

    for (loop_ub = -1; loop_ub + 2 <= nx; loop_ub++) {
      xv->data[loop_ub + 1] = x->data[b_environment_idx_0 + loop_ub];
    }

    xbar = xv->data[0];
    for (loop_ub = 2; loop_ub <= n; loop_ub++) {
      xbar += xv->data[loop_ub - 1];
    }

    xbar /= (double)environment_idx_0;
    yv = 0.0;
    for (loop_ub = 1; loop_ub <= n; loop_ub++) {
      t = xv->data[loop_ub - 1] - xbar;
      yv += t * t;
    }

    yv /= (double)environment_idx_0 - 1.0;
    y->data[p] = yv;
    p++;
  }

  emxFree_real_T(&xv);
}

/* End of code generation (var.cpp) */
