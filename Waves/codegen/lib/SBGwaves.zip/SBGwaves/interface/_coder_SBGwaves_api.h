/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_SBGwaves_api.h
 *
 * Code generation for function '_coder_SBGwaves_api'
 *
 */

#ifndef _CODER_SBGWAVES_API_H
#define _CODER_SBGWAVES_API_H

/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include <stddef.h>
#include <stdlib.h>
#include "_coder_SBGwaves_api.h"

/* Type Definitions */
#ifndef struct_emxArray_real_T
#define struct_emxArray_real_T

struct emxArray_real_T
{
  real_T *data;
  int32_T *size;
  int32_T allocatedSize;
  int32_T numDimensions;
  boolean_T canFreeData;
};

#endif                                 /*struct_emxArray_real_T*/

#ifndef typedef_emxArray_real_T
#define typedef_emxArray_real_T

typedef struct emxArray_real_T emxArray_real_T;

#endif                                 /*typedef_emxArray_real_T*/

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

/* Function Declarations */
extern void SBGwaves(emxArray_real_T *u, emxArray_real_T *v, emxArray_real_T
                     *heave, real_T fs, real_T *Hs, real_T *Tp, real_T *Dp,
                     real_T E[42], real_T f[42], real_T a1[42], real_T b1[42],
                     real_T a2[42], real_T b2[42], real_T check[42]);
extern void SBGwaves_api(const mxArray * const prhs[4], const mxArray *plhs[10]);
extern void SBGwaves_atexit(void);
extern void SBGwaves_initialize(void);
extern void SBGwaves_terminate(void);
extern void SBGwaves_xil_terminate(void);

#endif

/* End of code generation (_coder_SBGwaves_api.h) */
