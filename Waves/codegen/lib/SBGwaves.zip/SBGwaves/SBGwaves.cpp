/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * SBGwaves.cpp
 *
 * Code generation for function 'SBGwaves'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "SBGwaves.h"
#include "SBGwaves_emxutil.h"
#include "detrend.h"
#include "mean.h"
#include "std.h"
#include "all.h"
#include "sqrt.h"
#include "sum.h"
#include "rdivide.h"
#include "atan2.h"
#include "power.h"
#include "nullAssignment.h"
#include "fft.h"
#include "var.h"
#include "sin.h"

/* Function Declarations */
static double rt_remd_snf(double u0, double u1);
static double rt_roundd_snf(double u);

/* Function Definitions */
static double rt_remd_snf(double u0, double u1)
{
  double y;
  double b_u1;
  double q;
  if (!((!rtIsNaN(u0)) && (!rtIsInf(u0)) && ((!rtIsNaN(u1)) && (!rtIsInf(u1)))))
  {
    y = rtNaN;
  } else {
    if (u1 < 0.0) {
      b_u1 = std::ceil(u1);
    } else {
      b_u1 = std::floor(u1);
    }

    if ((u1 != 0.0) && (u1 != b_u1)) {
      q = std::abs(u0 / u1);
      if (std::abs(q - std::floor(q + 0.5)) <= DBL_EPSILON * q) {
        y = 0.0 * u0;
      } else {
        y = std::fmod(u0, u1);
      }
    } else {
      y = std::fmod(u0, u1);
    }
  }

  return y;
}

static double rt_roundd_snf(double u)
{
  double y;
  if (std::abs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = std::floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = std::ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

void SBGwaves(const emxArray_real_T *u, const emxArray_real_T *v, const
              emxArray_real_T *heave, double fs, double *Hs, double *Tp, double *
              Dp, double E[42], double f[42], double a1[42], double b1[42],
              double a2[42], double b2[42], double check[42])
{
  emxArray_real_T *ufiltered;
  emxArray_real_T *vfiltered;
  emxArray_real_T *heavefiltered;
  emxArray_real_T *uwindow;
  emxArray_real_T *vwindow;
  emxArray_real_T *heavewindow;
  emxArray_real_T *taper;
  emxArray_real_T *uwindowtaper;
  emxArray_real_T *vwindowtaper;
  emxArray_real_T *factu;
  emxArray_real_T *factv;
  emxArray_real_T *factheave;
  emxArray_creal_T *Uwindow;
  emxArray_creal_T *Vwindow;
  emxArray_creal_T *Zwindow;
  emxArray_creal_T *UVwindow;
  emxArray_creal_T *UZwindowmerged;
  emxArray_creal_T *VZwindowmerged;
  emxArray_real_T *ZZ;
  emxArray_creal_T *UZ;
  emxArray_creal_T *VZ;
  emxArray_real_T *Exx;
  emxArray_real_T *Eyy;
  emxArray_real_T *dir1;
  emxArray_boolean_T *eastdirs;
  emxArray_real_T *b_f;
  emxArray_real_T *b_a1;
  emxArray_real_T *b_b1;
  emxArray_real_T *b_a2;
  emxArray_int32_T *r0;
  emxArray_boolean_T *r1;
  emxArray_int32_T *r2;
  emxArray_int32_T *r3;
  emxArray_int32_T *r4;
  emxArray_int32_T *r5;
  emxArray_creal_T *A;
  emxArray_real_T *r6;
  emxArray_real_T *b_ufiltered;
  emxArray_creal_T *b_Zwindow;
  emxArray_real_T *b_taper;
  emxArray_int32_T *w;
  emxArray_real_T *b_uwindow;
  emxArray_real_T *r7;
  emxArray_creal_T *b_Uwindow;
  emxArray_real_T *b_dir1;
  int i0;
  int loop_ub;
  double alpha;
  int ixstart;
  double b_w;
  int windows;
  int n;
  int i1;
  int b_loop_ub;
  double Uwindow_im;
  double Vwindow_re;
  double Vwindow_im;
  double Zwindow_re;
  double Zwindow_im;
  int mi;
  double bandwidth;
  boolean_T exitg1;
  boolean_T inds[3];
  double b_inds[3];
  double c_dir1[3];

  /*  matlab function to read and process SBG senor data (GPS velocities and heave) */
  /*    to estimate wave height, period, direction, and spectral moments */
  /*    assuming deep-water limit of surface gravity wave dispersion relation */
  /*  */
  /*  Inputs are east velocity [m/s], north velocity [m/s], vertical heave [m, positive down] */
  /*  sampling rate [Hz] */
  /*  */
  /*  Sampling rate must be at least 1 Hz and the same for all variables.   */
  /*  Additionaly, input time series data must have at least 512 points and all be the same size. */
  /*  */
  /*  Outputs are significat wave height [m], dominant period [s], dominant direction  */
  /*  [deg T, using meteorological from which waves are propagating], spectral  */
  /*  energy density [m^2/Hz], frequency [Hz],   */
  /*  the normalized spectral moments a1, b1, a2, b2,  */
  /*  and the spectral check factor (ratio of heave to sway + surge) */
  /*  */
  /*  Outputs will be '9999' for invalid results. */
  /*  */
  /*  Outputs can be supressed, in order, thus full usage is as follows: */
  /*  */
  /*    [ Hs, Tp, Dp, E, f, a1, b1, a2, b2, check ] = SBGwaves(u,v,heave,fs);  */
  /*  */
  /*  */
  /*  J. Thomson,  10/2016 (adapated from GPSandIMUwaves_v6) */
  /*               11/2016, M. Schwendeman:  (constant input/output vector sizes,  */
  /*                    fixed increase in Uwindow size by indexing) */
  /*                10/2017, fixed normalization of cross-spectra (affects a1,b1 moments) */
  /*                        and added RC filter to GPS velocities (heave already filtered) */
  /*                1/2018  add RC filter to heave also (helps a little in small wind-waves)        */
  /*   */
  /*  fixed parameters */
  /*  window length in seconds, should make 2^N samples */
  /*  freq bands to merge, must be odd? */
  /*  frequency cutoff for telemetry Hz */
  /*  flip wave directions (but not moments) */
  /*  RC fitler... cuttoff freq is 1/(2*pi*RC), so nominal value is RC = 3.5 */
  /*  lower frequency limit (usually 0.05 Hz) */
  /*  upper frequency limit (usually 1 Hz) */
  /*  begin processing, if data sufficient */
  /*  record length in data points */
  emxInit_real_T(&ufiltered, 2);
  emxInit_real_T(&vfiltered, 2);
  emxInit_real_T(&heavefiltered, 2);
  emxInit_real_T(&uwindow, 2);
  emxInit_real_T(&vwindow, 2);
  emxInit_real_T(&heavewindow, 2);
  emxInit_real_T(&taper, 2);
  emxInit_real_T(&uwindowtaper, 2);
  emxInit_real_T(&vwindowtaper, 2);
  emxInit_real_T(&factu, 2);
  emxInit_real_T(&factv, 2);
  emxInit_real_T(&factheave, 2);
  emxInit_creal_T(&Uwindow, 2);
  emxInit_creal_T(&Vwindow, 2);
  emxInit_creal_T(&Zwindow, 2);
  emxInit_creal_T(&UVwindow, 2);
  emxInit_creal_T(&UZwindowmerged, 2);
  emxInit_creal_T(&VZwindowmerged, 2);
  emxInit_real_T(&ZZ, 2);
  emxInit_creal_T(&UZ, 2);
  emxInit_creal_T(&VZ, 2);
  emxInit_real_T(&Exx, 2);
  emxInit_real_T(&Eyy, 2);
  emxInit_real_T(&dir1, 2);
  emxInit_boolean_T(&eastdirs, 2);
  emxInit_real_T(&b_f, 2);
  emxInit_real_T(&b_a1, 2);
  emxInit_real_T(&b_b1, 2);
  emxInit_real_T(&b_a2, 2);
  emxInit_int32_T(&r0, 1);
  emxInit_boolean_T(&r1, 2);
  emxInit_int32_T1(&r2, 2);
  emxInit_int32_T1(&r3, 2);
  emxInit_int32_T1(&r4, 2);
  emxInit_int32_T1(&r5, 2);
  emxInit_creal_T(&A, 2);
  emxInit_real_T(&r6, 2);
  emxInit_real_T(&b_ufiltered, 2);
  emxInit_creal_T(&b_Zwindow, 2);
  emxInit_real_T(&b_taper, 2);
  emxInit_int32_T1(&w, 2);
  emxInit_real_T(&b_uwindow, 2);
  emxInit_real_T(&r7, 2);
  emxInit_creal_T(&b_Uwindow, 2);
  emxInit_real_T1(&b_dir1, 1);
  if ((u->size[1] >= 512) && (fs > 1.0)) {
    /*  minimum length and sampling for processing */
    /*  high-pass filter the GPS velocities */
    /*  initialize */
    i0 = ufiltered->size[0] * ufiltered->size[1];
    ufiltered->size[0] = 1;
    ufiltered->size[1] = u->size[1];
    emxEnsureCapacity_real_T(ufiltered, i0);
    loop_ub = u->size[0] * u->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      ufiltered->data[i0] = u->data[i0];
    }

    i0 = vfiltered->size[0] * vfiltered->size[1];
    vfiltered->size[0] = 1;
    vfiltered->size[1] = v->size[1];
    emxEnsureCapacity_real_T(vfiltered, i0);
    loop_ub = v->size[0] * v->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      vfiltered->data[i0] = v->data[i0];
    }

    i0 = heavefiltered->size[0] * heavefiltered->size[1];
    heavefiltered->size[0] = 1;
    heavefiltered->size[1] = heave->size[1];
    emxEnsureCapacity_real_T(heavefiltered, i0);
    loop_ub = heave->size[0] * heave->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      heavefiltered->data[i0] = heave->data[i0];
    }

    alpha = 3.5 / (3.5 + 1.0 / fs);
    for (ixstart = 0; ixstart <= u->size[1] - 2; ixstart++) {
      ufiltered->data[1 + ixstart] = alpha * ufiltered->data[ixstart] + alpha *
        (u->data[1 + ixstart] - u->data[ixstart]);
      vfiltered->data[1 + ixstart] = alpha * vfiltered->data[ixstart] + alpha *
        (v->data[1 + ixstart] - v->data[ixstart]);
      heavefiltered->data[1 + ixstart] = alpha * heavefiltered->data[ixstart] +
        alpha * (heave->data[1 + ixstart] - heave->data[ixstart]);
    }

    /*  break into windows (use 75 percent overlap) */
    b_w = rt_roundd_snf(fs * 256.0);

    /*  window length in data points */
    if (rt_remd_snf(b_w, 2.0) != 0.0) {
      b_w--;
    }

    /*  make w an even number */
    windows = (int)std::floor(4.0 * ((double)u->size[1] / b_w - 1.0) + 1.0);

    /*  number of windows, the 4 comes from a 75% overlap */
    /*  degrees of freedom */
    /*  loop to create a matrix of time series, where COLUMN = WINDOW  */
    i0 = uwindow->size[0] * uwindow->size[1];
    uwindow->size[0] = (int)b_w;
    uwindow->size[1] = windows;
    emxEnsureCapacity_real_T(uwindow, i0);
    i0 = vwindow->size[0] * vwindow->size[1];
    vwindow->size[0] = (int)b_w;
    vwindow->size[1] = windows;
    emxEnsureCapacity_real_T(vwindow, i0);
    i0 = heavewindow->size[0] * heavewindow->size[1];
    heavewindow->size[0] = (int)b_w;
    heavewindow->size[1] = windows;
    emxEnsureCapacity_real_T(heavewindow, i0);
    for (n = 0; n < windows; n++) {
      loop_ub = uwindow->size[0];
      i0 = r0->size[0];
      r0->size[0] = loop_ub;
      emxEnsureCapacity_int32_T(r0, i0);
      for (i0 = 0; i0 < loop_ub; i0++) {
        r0->data[i0] = i0;
      }

      alpha = ((1.0 + (double)n) - 1.0) * (0.25 * b_w);
      i0 = dir1->size[0] * dir1->size[1];
      dir1->size[0] = 1;
      dir1->size[1] = (int)(b_w - 1.0) + 1;
      emxEnsureCapacity_real_T(dir1, i0);
      loop_ub = (int)(b_w - 1.0);
      for (i0 = 0; i0 <= loop_ub; i0++) {
        dir1->data[dir1->size[0] * i0] = ufiltered->data[(int)(alpha + (double)
          (i0 + 1)) - 1];
      }

      ixstart = r0->size[0];
      for (i0 = 0; i0 < ixstart; i0++) {
        uwindow->data[r0->data[i0] + uwindow->size[0] * n] = dir1->data[i0];
      }

      loop_ub = vwindow->size[0];
      i0 = r0->size[0];
      r0->size[0] = loop_ub;
      emxEnsureCapacity_int32_T(r0, i0);
      for (i0 = 0; i0 < loop_ub; i0++) {
        r0->data[i0] = i0;
      }

      alpha = ((1.0 + (double)n) - 1.0) * (0.25 * b_w);
      i0 = dir1->size[0] * dir1->size[1];
      dir1->size[0] = 1;
      dir1->size[1] = (int)(b_w - 1.0) + 1;
      emxEnsureCapacity_real_T(dir1, i0);
      loop_ub = (int)(b_w - 1.0);
      for (i0 = 0; i0 <= loop_ub; i0++) {
        dir1->data[dir1->size[0] * i0] = vfiltered->data[(int)(alpha + (double)
          (i0 + 1)) - 1];
      }

      ixstart = r0->size[0];
      for (i0 = 0; i0 < ixstart; i0++) {
        vwindow->data[r0->data[i0] + vwindow->size[0] * n] = dir1->data[i0];
      }

      loop_ub = heavewindow->size[0];
      i0 = r0->size[0];
      r0->size[0] = loop_ub;
      emxEnsureCapacity_int32_T(r0, i0);
      for (i0 = 0; i0 < loop_ub; i0++) {
        r0->data[i0] = i0;
      }

      alpha = ((1.0 + (double)n) - 1.0) * (0.25 * b_w);
      i0 = dir1->size[0] * dir1->size[1];
      dir1->size[0] = 1;
      dir1->size[1] = (int)(b_w - 1.0) + 1;
      emxEnsureCapacity_real_T(dir1, i0);
      loop_ub = (int)(b_w - 1.0);
      for (i0 = 0; i0 <= loop_ub; i0++) {
        dir1->data[dir1->size[0] * i0] = heavefiltered->data[(int)(alpha +
          (double)(i0 + 1)) - 1];
      }

      ixstart = r0->size[0];
      for (i0 = 0; i0 < ixstart; i0++) {
        heavewindow->data[r0->data[i0] + heavewindow->size[0] * n] = dir1->
          data[i0];
      }
    }

    /*  detrend individual windows  */
    for (n = 0; n < windows; n++) {
      loop_ub = uwindow->size[0];
      i0 = b_dir1->size[0];
      b_dir1->size[0] = loop_ub;
      emxEnsureCapacity_real_T1(b_dir1, i0);
      for (i0 = 0; i0 < loop_ub; i0++) {
        b_dir1->data[i0] = uwindow->data[i0 + uwindow->size[0] * n];
      }

      detrend(b_dir1);
      loop_ub = b_dir1->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        uwindow->data[i0 + uwindow->size[0] * n] = b_dir1->data[i0];
      }

      loop_ub = vwindow->size[0];
      i0 = b_dir1->size[0];
      b_dir1->size[0] = loop_ub;
      emxEnsureCapacity_real_T1(b_dir1, i0);
      for (i0 = 0; i0 < loop_ub; i0++) {
        b_dir1->data[i0] = vwindow->data[i0 + vwindow->size[0] * n];
      }

      detrend(b_dir1);
      loop_ub = b_dir1->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        vwindow->data[i0 + vwindow->size[0] * n] = b_dir1->data[i0];
      }

      loop_ub = heavewindow->size[0];
      i0 = b_dir1->size[0];
      b_dir1->size[0] = loop_ub;
      emxEnsureCapacity_real_T1(b_dir1, i0);
      for (i0 = 0; i0 < loop_ub; i0++) {
        b_dir1->data[i0] = heavewindow->data[i0 + heavewindow->size[0] * n];
      }

      detrend(b_dir1);
      loop_ub = b_dir1->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        heavewindow->data[i0 + heavewindow->size[0] * n] = b_dir1->data[i0];
      }
    }

    /*  taper and rescale (to preserve variance) */
    /*  form taper matrix (columns of taper coef) */
    i0 = dir1->size[0] * dir1->size[1];
    dir1->size[0] = 1;
    dir1->size[1] = (int)(b_w - 1.0) + 1;
    emxEnsureCapacity_real_T(dir1, i0);
    loop_ub = (int)(b_w - 1.0);
    for (i0 = 0; i0 <= loop_ub; i0++) {
      dir1->data[dir1->size[0] * i0] = (1.0 + (double)i0) * 3.1415926535897931 /
        b_w;
    }

    b_sin(dir1);
    i0 = taper->size[0] * taper->size[1];
    taper->size[0] = dir1->size[1];
    taper->size[1] = windows;
    emxEnsureCapacity_real_T(taper, i0);
    loop_ub = dir1->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      for (i1 = 0; i1 < windows; i1++) {
        taper->data[i0 + taper->size[0] * i1] = dir1->data[dir1->size[0] * i0];
      }
    }

    /*  taper each window */
    i0 = uwindowtaper->size[0] * uwindowtaper->size[1];
    uwindowtaper->size[0] = uwindow->size[0];
    uwindowtaper->size[1] = uwindow->size[1];
    emxEnsureCapacity_real_T(uwindowtaper, i0);
    loop_ub = uwindow->size[0] * uwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      uwindowtaper->data[i0] = uwindow->data[i0] * taper->data[i0];
    }

    i0 = vwindowtaper->size[0] * vwindowtaper->size[1];
    vwindowtaper->size[0] = vwindow->size[0];
    vwindowtaper->size[1] = vwindow->size[1];
    emxEnsureCapacity_real_T(vwindowtaper, i0);
    loop_ub = vwindow->size[0] * vwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      vwindowtaper->data[i0] = vwindow->data[i0] * taper->data[i0];
    }

    i0 = taper->size[0] * taper->size[1];
    taper->size[0] = heavewindow->size[0];
    taper->size[1] = heavewindow->size[1];
    emxEnsureCapacity_real_T(taper, i0);
    loop_ub = heavewindow->size[0] * heavewindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      taper->data[i0] *= heavewindow->data[i0];
    }

    /*  now find the correction factor (comparing old/new variance) */
    var(uwindow, factheave);
    var(uwindowtaper, r6);
    rdivide(factheave, r6, dir1);
    c_sqrt(dir1);
    i0 = factu->size[0] * factu->size[1];
    factu->size[0] = 1;
    factu->size[1] = dir1->size[1];
    emxEnsureCapacity_real_T(factu, i0);
    loop_ub = dir1->size[0] * dir1->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      factu->data[i0] = dir1->data[i0];
    }

    var(vwindow, factheave);
    var(vwindowtaper, r6);
    rdivide(factheave, r6, dir1);
    c_sqrt(dir1);
    i0 = factv->size[0] * factv->size[1];
    factv->size[0] = 1;
    factv->size[1] = dir1->size[1];
    emxEnsureCapacity_real_T(factv, i0);
    loop_ub = dir1->size[0] * dir1->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      factv->data[i0] = dir1->data[i0];
    }

    var(heavewindow, factheave);
    var(taper, r6);
    rdivide(factheave, r6, dir1);
    c_sqrt(dir1);
    i0 = factheave->size[0] * factheave->size[1];
    factheave->size[0] = 1;
    factheave->size[1] = dir1->size[1];
    emxEnsureCapacity_real_T(factheave, i0);
    loop_ub = dir1->size[0] * dir1->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      factheave->data[i0] = dir1->data[i0];
    }

    /*  and correct for the change in variance */
    /*  (mult each window by it's variance ratio factor) */
    /*  FFT, use capital letters to not spectral version of variables */
    /*  calculate Fourier coefs */
    i0 = r7->size[0] * r7->size[1];
    r7->size[0] = (int)b_w;
    r7->size[1] = factu->size[1];
    emxEnsureCapacity_real_T(r7, i0);
    loop_ub = (int)b_w;
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = factu->size[1];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        r7->data[i0 + r7->size[0] * i1] = factu->data[factu->size[0] * i1];
      }
    }

    i0 = b_uwindow->size[0] * b_uwindow->size[1];
    b_uwindow->size[0] = r7->size[0];
    b_uwindow->size[1] = r7->size[1];
    emxEnsureCapacity_real_T(b_uwindow, i0);
    loop_ub = r7->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = r7->size[0];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        b_uwindow->data[i1 + b_uwindow->size[0] * i0] = r7->data[i1 + r7->size[0]
          * i0] * uwindowtaper->data[i1 + uwindowtaper->size[0] * i0];
      }
    }

    fft(b_uwindow, Uwindow);
    i0 = r7->size[0] * r7->size[1];
    r7->size[0] = (int)b_w;
    r7->size[1] = factv->size[1];
    emxEnsureCapacity_real_T(r7, i0);
    loop_ub = (int)b_w;
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = factv->size[1];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        r7->data[i0 + r7->size[0] * i1] = factv->data[factv->size[0] * i1];
      }
    }

    i0 = b_uwindow->size[0] * b_uwindow->size[1];
    b_uwindow->size[0] = r7->size[0];
    b_uwindow->size[1] = r7->size[1];
    emxEnsureCapacity_real_T(b_uwindow, i0);
    loop_ub = r7->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = r7->size[0];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        b_uwindow->data[i1 + b_uwindow->size[0] * i0] = r7->data[i1 + r7->size[0]
          * i0] * vwindowtaper->data[i1 + vwindowtaper->size[0] * i0];
      }
    }

    fft(b_uwindow, Vwindow);
    i0 = r7->size[0] * r7->size[1];
    r7->size[0] = (int)b_w;
    r7->size[1] = factheave->size[1];
    emxEnsureCapacity_real_T(r7, i0);
    loop_ub = (int)b_w;
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = factheave->size[1];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        r7->data[i0 + r7->size[0] * i1] = factheave->data[factheave->size[0] *
          i1];
      }
    }

    i0 = b_uwindow->size[0] * b_uwindow->size[1];
    b_uwindow->size[0] = r7->size[0];
    b_uwindow->size[1] = r7->size[1];
    emxEnsureCapacity_real_T(b_uwindow, i0);
    loop_ub = r7->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = r7->size[0];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        b_uwindow->data[i1 + b_uwindow->size[0] * i0] = r7->data[i1 + r7->size[0]
          * i0] * taper->data[i1 + taper->size[0] * i0];
      }
    }

    fft(b_uwindow, Zwindow);

    /*  second half of fft is redundant, so throw it out */
    alpha = b_w / 2.0 + 1.0;
    i0 = w->size[0] * w->size[1];
    w->size[0] = 1;
    w->size[1] = (int)std::floor(b_w - alpha) + 1;
    emxEnsureCapacity_int32_T1(w, i0);
    loop_ub = (int)std::floor(b_w - alpha);
    for (i0 = 0; i0 <= loop_ub; i0++) {
      w->data[w->size[0] * i0] = (int)(alpha + (double)i0);
    }

    nullAssignment(Uwindow, w);
    alpha = b_w / 2.0 + 1.0;
    i0 = w->size[0] * w->size[1];
    w->size[0] = 1;
    w->size[1] = (int)std::floor(b_w - alpha) + 1;
    emxEnsureCapacity_int32_T1(w, i0);
    loop_ub = (int)std::floor(b_w - alpha);
    for (i0 = 0; i0 <= loop_ub; i0++) {
      w->data[w->size[0] * i0] = (int)(alpha + (double)i0);
    }

    nullAssignment(Vwindow, w);
    alpha = b_w / 2.0 + 1.0;
    i0 = w->size[0] * w->size[1];
    w->size[0] = 1;
    w->size[1] = (int)std::floor(b_w - alpha) + 1;
    emxEnsureCapacity_int32_T1(w, i0);
    loop_ub = (int)std::floor(b_w - alpha);
    for (i0 = 0; i0 <= loop_ub; i0++) {
      w->data[w->size[0] * i0] = (int)(alpha + (double)i0);
    }

    nullAssignment(Zwindow, w);

    /*  throw out the mean (first coef) and add a zero (to make it the right length)   */
    /* Uwindow(1,:)=[]; Vwindow(1,:)=[]; Zwindow(1,:)=[];  */
    loop_ub = (int)(b_w / 2.0) - 2;
    n = Uwindow->size[1];
    i0 = b_Uwindow->size[0] * b_Uwindow->size[1];
    b_Uwindow->size[0] = loop_ub + 1;
    b_Uwindow->size[1] = n;
    emxEnsureCapacity_creal_T(b_Uwindow, i0);
    for (i0 = 0; i0 < n; i0++) {
      for (i1 = 0; i1 <= loop_ub; i1++) {
        b_Uwindow->data[i1 + b_Uwindow->size[0] * i0] = Uwindow->data[(i1 +
          Uwindow->size[0] * i0) + 1];
      }
    }

    loop_ub = b_Uwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = b_Uwindow->size[0];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        Uwindow->data[i1 + Uwindow->size[0] * i0] = b_Uwindow->data[i1 +
          b_Uwindow->size[0] * i0];
      }
    }

    loop_ub = (int)(b_w / 2.0) - 2;
    n = Vwindow->size[1];
    i0 = b_Uwindow->size[0] * b_Uwindow->size[1];
    b_Uwindow->size[0] = loop_ub + 1;
    b_Uwindow->size[1] = n;
    emxEnsureCapacity_creal_T(b_Uwindow, i0);
    for (i0 = 0; i0 < n; i0++) {
      for (i1 = 0; i1 <= loop_ub; i1++) {
        b_Uwindow->data[i1 + b_Uwindow->size[0] * i0] = Vwindow->data[(i1 +
          Vwindow->size[0] * i0) + 1];
      }
    }

    loop_ub = b_Uwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = b_Uwindow->size[0];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        Vwindow->data[i1 + Vwindow->size[0] * i0] = b_Uwindow->data[i1 +
          b_Uwindow->size[0] * i0];
      }
    }

    loop_ub = (int)(b_w / 2.0) - 2;
    ixstart = Zwindow->size[1];
    i0 = b_Uwindow->size[0] * b_Uwindow->size[1];
    b_Uwindow->size[0] = loop_ub + 1;
    b_Uwindow->size[1] = ixstart;
    emxEnsureCapacity_creal_T(b_Uwindow, i0);
    for (i0 = 0; i0 < ixstart; i0++) {
      for (i1 = 0; i1 <= loop_ub; i1++) {
        b_Uwindow->data[i1 + b_Uwindow->size[0] * i0] = Zwindow->data[(i1 +
          Zwindow->size[0] * i0) + 1];
      }
    }

    loop_ub = b_Uwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = b_Uwindow->size[0];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        Zwindow->data[i1 + Zwindow->size[0] * i0] = b_Uwindow->data[i1 +
          b_Uwindow->size[0] * i0];
      }
    }

    loop_ub = Uwindow->size[1];
    ixstart = (int)(b_w / 2.0);
    for (i0 = 0; i0 < loop_ub; i0++) {
      Uwindow->data[(ixstart + Uwindow->size[0] * i0) - 1].re = 0.0;
      Uwindow->data[(ixstart + Uwindow->size[0] * i0) - 1].im = 0.0;
    }

    loop_ub = Vwindow->size[1];
    ixstart = (int)(b_w / 2.0);
    for (i0 = 0; i0 < loop_ub; i0++) {
      Vwindow->data[(ixstart + Vwindow->size[0] * i0) - 1].re = 0.0;
      Vwindow->data[(ixstart + Vwindow->size[0] * i0) - 1].im = 0.0;
    }

    loop_ub = Zwindow->size[1];
    ixstart = (int)(b_w / 2.0);
    for (i0 = 0; i0 < loop_ub; i0++) {
      Zwindow->data[(ixstart + Zwindow->size[0] * i0) - 1].re = 0.0;
      Zwindow->data[(ixstart + Zwindow->size[0] * i0) - 1].im = 0.0;
    }

    /*  POWER SPECTRA (auto-spectra) */
    i0 = uwindow->size[0] * uwindow->size[1];
    uwindow->size[0] = Uwindow->size[0];
    uwindow->size[1] = Uwindow->size[1];
    emxEnsureCapacity_real_T(uwindow, i0);
    loop_ub = Uwindow->size[0] * Uwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      alpha = Uwindow->data[i0].re;
      Uwindow_im = -Uwindow->data[i0].im;
      alpha = Uwindow->data[i0].re * alpha - Uwindow->data[i0].im * Uwindow_im;
      uwindow->data[i0] = alpha;
    }

    i0 = vwindow->size[0] * vwindow->size[1];
    vwindow->size[0] = Vwindow->size[0];
    vwindow->size[1] = Vwindow->size[1];
    emxEnsureCapacity_real_T(vwindow, i0);
    loop_ub = Vwindow->size[0] * Vwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      Vwindow_re = Vwindow->data[i0].re;
      Vwindow_im = -Vwindow->data[i0].im;
      Vwindow_re = Vwindow->data[i0].re * Vwindow_re - Vwindow->data[i0].im *
        Vwindow_im;
      vwindow->data[i0] = Vwindow_re;
    }

    i0 = heavewindow->size[0] * heavewindow->size[1];
    heavewindow->size[0] = Zwindow->size[0];
    heavewindow->size[1] = Zwindow->size[1];
    emxEnsureCapacity_real_T(heavewindow, i0);
    loop_ub = Zwindow->size[0] * Zwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      Zwindow_re = Zwindow->data[i0].re;
      Zwindow_im = -Zwindow->data[i0].im;
      Zwindow_re = Zwindow->data[i0].re * Zwindow_re - Zwindow->data[i0].im *
        Zwindow_im;
      heavewindow->data[i0] = Zwindow_re;
    }

    /*  CROSS-SPECTRA  */
    i0 = UVwindow->size[0] * UVwindow->size[1];
    UVwindow->size[0] = Uwindow->size[0];
    UVwindow->size[1] = Uwindow->size[1];
    emxEnsureCapacity_creal_T(UVwindow, i0);
    loop_ub = Uwindow->size[0] * Uwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      Vwindow_re = Vwindow->data[i0].re;
      Vwindow_im = -Vwindow->data[i0].im;
      alpha = Uwindow->data[i0].re;
      Uwindow_im = Uwindow->data[i0].im;
      UVwindow->data[i0].re = alpha * Vwindow_re - Uwindow_im * Vwindow_im;
      UVwindow->data[i0].im = alpha * Vwindow_im + Uwindow_im * Vwindow_re;
    }

    i0 = Uwindow->size[0] * Uwindow->size[1];
    emxEnsureCapacity_creal_T(Uwindow, i0);
    n = Uwindow->size[0];
    ixstart = Uwindow->size[1];
    loop_ub = n * ixstart;
    for (i0 = 0; i0 < loop_ub; i0++) {
      Zwindow_re = Zwindow->data[i0].re;
      Zwindow_im = -Zwindow->data[i0].im;
      alpha = Uwindow->data[i0].re;
      Uwindow_im = Uwindow->data[i0].im;
      Uwindow->data[i0].re = alpha * Zwindow_re - Uwindow_im * Zwindow_im;
      Uwindow->data[i0].im = alpha * Zwindow_im + Uwindow_im * Zwindow_re;
    }

    i0 = Vwindow->size[0] * Vwindow->size[1];
    emxEnsureCapacity_creal_T(Vwindow, i0);
    n = Vwindow->size[0];
    ixstart = Vwindow->size[1];
    loop_ub = n * ixstart;
    for (i0 = 0; i0 < loop_ub; i0++) {
      Zwindow_re = Zwindow->data[i0].re;
      Zwindow_im = -Zwindow->data[i0].im;
      Vwindow_re = Vwindow->data[i0].re;
      Vwindow_im = Vwindow->data[i0].im;
      Vwindow->data[i0].re = Vwindow_re * Zwindow_re - Vwindow_im * Zwindow_im;
      Vwindow->data[i0].im = Vwindow_re * Zwindow_im + Vwindow_im * Zwindow_re;
    }

    /*  merge neighboring freq bands (number of bands to merge is a fixed parameter) */
    /*  initialize */
    alpha = std::floor(b_w / 6.0);
    i0 = taper->size[0] * taper->size[1];
    taper->size[0] = (int)alpha;
    taper->size[1] = windows;
    emxEnsureCapacity_real_T(taper, i0);
    loop_ub = (int)alpha * windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      taper->data[i0] = 0.0;
    }

    alpha = std::floor(b_w / 6.0);
    i0 = uwindowtaper->size[0] * uwindowtaper->size[1];
    uwindowtaper->size[0] = (int)alpha;
    uwindowtaper->size[1] = windows;
    emxEnsureCapacity_real_T(uwindowtaper, i0);
    loop_ub = (int)alpha * windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      uwindowtaper->data[i0] = 0.0;
    }

    alpha = std::floor(b_w / 6.0);
    i0 = vwindowtaper->size[0] * vwindowtaper->size[1];
    vwindowtaper->size[0] = (int)alpha;
    vwindowtaper->size[1] = windows;
    emxEnsureCapacity_real_T(vwindowtaper, i0);
    loop_ub = (int)alpha * windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      vwindowtaper->data[i0] = 0.0;
    }

    alpha = std::floor(b_w / 6.0);
    i0 = Zwindow->size[0] * Zwindow->size[1];
    Zwindow->size[0] = (int)alpha;
    Zwindow->size[1] = windows;
    emxEnsureCapacity_creal_T(Zwindow, i0);
    loop_ub = (int)alpha * windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      Zwindow->data[i0].re = 0.0;
      Zwindow->data[i0].im = 1.0;
    }

    alpha = std::floor(b_w / 6.0);
    i0 = UZwindowmerged->size[0] * UZwindowmerged->size[1];
    UZwindowmerged->size[0] = (int)alpha;
    UZwindowmerged->size[1] = windows;
    emxEnsureCapacity_creal_T(UZwindowmerged, i0);
    loop_ub = (int)alpha * windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      UZwindowmerged->data[i0].re = 0.0;
      UZwindowmerged->data[i0].im = 1.0;
    }

    alpha = std::floor(b_w / 6.0);
    i0 = VZwindowmerged->size[0] * VZwindowmerged->size[1];
    VZwindowmerged->size[0] = (int)alpha;
    VZwindowmerged->size[1] = windows;
    emxEnsureCapacity_creal_T(VZwindowmerged, i0);
    loop_ub = (int)alpha * windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      VZwindowmerged->data[i0].re = 0.0;
      VZwindowmerged->data[i0].im = 1.0;
    }

    i0 = (int)(b_w / 2.0 / 3.0);
    for (mi = 0; mi < i0; mi++) {
      alpha = 3.0 + (double)mi * 3.0;
      if ((alpha - 3.0) + 1.0 > alpha) {
        i1 = 0;
        ixstart = 0;
      } else {
        i1 = (int)((alpha - 3.0) + 1.0) - 1;
        ixstart = (int)alpha;
      }

      loop_ub = uwindow->size[1];
      n = b_uwindow->size[0] * b_uwindow->size[1];
      b_uwindow->size[0] = ixstart - i1;
      b_uwindow->size[1] = loop_ub;
      emxEnsureCapacity_real_T(b_uwindow, n);
      for (n = 0; n < loop_ub; n++) {
        b_loop_ub = ixstart - i1;
        for (windows = 0; windows < b_loop_ub; windows++) {
          b_uwindow->data[windows + b_uwindow->size[0] * n] = uwindow->data[(i1
            + windows) + uwindow->size[0] * n];
        }
      }

      mean(b_uwindow, dir1);
      ixstart = (int)(alpha / 3.0);
      loop_ub = dir1->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        taper->data[(ixstart + taper->size[0] * i1) - 1] = dir1->data[dir1->
          size[0] * i1];
      }

      if ((alpha - 3.0) + 1.0 > alpha) {
        i1 = 0;
        ixstart = 0;
      } else {
        i1 = (int)((alpha - 3.0) + 1.0) - 1;
        ixstart = (int)alpha;
      }

      loop_ub = vwindow->size[1];
      n = b_uwindow->size[0] * b_uwindow->size[1];
      b_uwindow->size[0] = ixstart - i1;
      b_uwindow->size[1] = loop_ub;
      emxEnsureCapacity_real_T(b_uwindow, n);
      for (n = 0; n < loop_ub; n++) {
        b_loop_ub = ixstart - i1;
        for (windows = 0; windows < b_loop_ub; windows++) {
          b_uwindow->data[windows + b_uwindow->size[0] * n] = vwindow->data[(i1
            + windows) + vwindow->size[0] * n];
        }
      }

      mean(b_uwindow, dir1);
      ixstart = (int)(alpha / 3.0);
      loop_ub = dir1->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        uwindowtaper->data[(ixstart + uwindowtaper->size[0] * i1) - 1] =
          dir1->data[dir1->size[0] * i1];
      }

      if ((alpha - 3.0) + 1.0 > alpha) {
        i1 = 0;
        ixstart = 0;
      } else {
        i1 = (int)((alpha - 3.0) + 1.0) - 1;
        ixstart = (int)alpha;
      }

      loop_ub = heavewindow->size[1];
      n = b_uwindow->size[0] * b_uwindow->size[1];
      b_uwindow->size[0] = ixstart - i1;
      b_uwindow->size[1] = loop_ub;
      emxEnsureCapacity_real_T(b_uwindow, n);
      for (n = 0; n < loop_ub; n++) {
        b_loop_ub = ixstart - i1;
        for (windows = 0; windows < b_loop_ub; windows++) {
          b_uwindow->data[windows + b_uwindow->size[0] * n] = heavewindow->data
            [(i1 + windows) + heavewindow->size[0] * n];
        }
      }

      mean(b_uwindow, dir1);
      ixstart = (int)(alpha / 3.0);
      loop_ub = dir1->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        vwindowtaper->data[(ixstart + vwindowtaper->size[0] * i1) - 1] =
          dir1->data[dir1->size[0] * i1];
      }

      if ((alpha - 3.0) + 1.0 > alpha) {
        i1 = 0;
        ixstart = 0;
      } else {
        i1 = (int)((alpha - 3.0) + 1.0) - 1;
        ixstart = (int)alpha;
      }

      loop_ub = UVwindow->size[1];
      n = b_Uwindow->size[0] * b_Uwindow->size[1];
      b_Uwindow->size[0] = ixstart - i1;
      b_Uwindow->size[1] = loop_ub;
      emxEnsureCapacity_creal_T(b_Uwindow, n);
      for (n = 0; n < loop_ub; n++) {
        b_loop_ub = ixstart - i1;
        for (windows = 0; windows < b_loop_ub; windows++) {
          b_Uwindow->data[windows + b_Uwindow->size[0] * n] = UVwindow->data[(i1
            + windows) + UVwindow->size[0] * n];
        }
      }

      b_mean(b_Uwindow, A);
      ixstart = (int)(alpha / 3.0);
      loop_ub = A->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        Zwindow->data[(ixstart + Zwindow->size[0] * i1) - 1] = A->data[A->size[0]
          * i1];
      }

      if ((alpha - 3.0) + 1.0 > alpha) {
        i1 = 0;
        ixstart = 0;
      } else {
        i1 = (int)((alpha - 3.0) + 1.0) - 1;
        ixstart = (int)alpha;
      }

      loop_ub = Uwindow->size[1];
      n = b_Uwindow->size[0] * b_Uwindow->size[1];
      b_Uwindow->size[0] = ixstart - i1;
      b_Uwindow->size[1] = loop_ub;
      emxEnsureCapacity_creal_T(b_Uwindow, n);
      for (n = 0; n < loop_ub; n++) {
        b_loop_ub = ixstart - i1;
        for (windows = 0; windows < b_loop_ub; windows++) {
          b_Uwindow->data[windows + b_Uwindow->size[0] * n] = Uwindow->data[(i1
            + windows) + Uwindow->size[0] * n];
        }
      }

      b_mean(b_Uwindow, A);
      ixstart = (int)(alpha / 3.0);
      loop_ub = A->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        UZwindowmerged->data[(ixstart + UZwindowmerged->size[0] * i1) - 1] =
          A->data[A->size[0] * i1];
      }

      if ((alpha - 3.0) + 1.0 > alpha) {
        i1 = 0;
        ixstart = 0;
      } else {
        i1 = (int)((alpha - 3.0) + 1.0) - 1;
        ixstart = (int)alpha;
      }

      loop_ub = Vwindow->size[1];
      n = b_Uwindow->size[0] * b_Uwindow->size[1];
      b_Uwindow->size[0] = ixstart - i1;
      b_Uwindow->size[1] = loop_ub;
      emxEnsureCapacity_creal_T(b_Uwindow, n);
      for (n = 0; n < loop_ub; n++) {
        b_loop_ub = ixstart - i1;
        for (windows = 0; windows < b_loop_ub; windows++) {
          b_Uwindow->data[windows + b_Uwindow->size[0] * n] = Vwindow->data[(i1
            + windows) + Vwindow->size[0] * n];
        }
      }

      b_mean(b_Uwindow, A);
      ixstart = (int)(alpha / 3.0);
      loop_ub = A->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        VZwindowmerged->data[(ixstart + VZwindowmerged->size[0] * i1) - 1] =
          A->data[A->size[0] * i1];
      }
    }

    /*  freq range and bandwidth */
    alpha = b_w / 2.0 / 3.0;

    /*  number of f bands */
    /*  highest spectral frequency  */
    bandwidth = 0.5 * fs / alpha;

    /*  freq (Hz) bandwitdh */
    /*  find middle of each freq band, ONLY WORKS WHEN MERGING ODD NUMBER OF BANDS! */
    Uwindow_im = bandwidth / 2.0;
    i0 = b_f->size[0] * b_f->size[1];
    b_f->size[0] = 1;
    b_f->size[1] = (int)std::floor(alpha - 1.0) + 1;
    emxEnsureCapacity_real_T(b_f, i0);
    loop_ub = (int)std::floor(alpha - 1.0);
    for (i0 = 0; i0 <= loop_ub; i0++) {
      b_f->data[b_f->size[0] * i0] = (0.00390625 + Uwindow_im) + bandwidth *
        (double)i0;
    }

    /*  ensemble average windows together */
    /*  take the average of all windows at each freq-band */
    /*  and divide by N*samplerate to get power spectral density */
    /*  the two is b/c Matlab's fft output is the symmetric FFT, and we did not use the redundant half (so need to multiply the psd by 2) */
    i0 = b_taper->size[0] * b_taper->size[1];
    b_taper->size[0] = taper->size[1];
    b_taper->size[1] = taper->size[0];
    emxEnsureCapacity_real_T(b_taper, i0);
    loop_ub = taper->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = taper->size[1];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        b_taper->data[i1 + b_taper->size[0] * i0] = taper->data[i0 + taper->
          size[0] * i1];
      }
    }

    mean(b_taper, ufiltered);
    Vwindow_re = b_w / 2.0 * fs;
    i0 = b_taper->size[0] * b_taper->size[1];
    b_taper->size[0] = uwindowtaper->size[1];
    b_taper->size[1] = uwindowtaper->size[0];
    emxEnsureCapacity_real_T(b_taper, i0);
    loop_ub = uwindowtaper->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = uwindowtaper->size[1];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        b_taper->data[i1 + b_taper->size[0] * i0] = uwindowtaper->data[i0 +
          uwindowtaper->size[0] * i1];
      }
    }

    mean(b_taper, vfiltered);
    Vwindow_im = b_w / 2.0 * fs;
    i0 = b_taper->size[0] * b_taper->size[1];
    b_taper->size[0] = vwindowtaper->size[1];
    b_taper->size[1] = vwindowtaper->size[0];
    emxEnsureCapacity_real_T(b_taper, i0);
    loop_ub = vwindowtaper->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = vwindowtaper->size[1];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        b_taper->data[i1 + b_taper->size[0] * i0] = vwindowtaper->data[i0 +
          vwindowtaper->size[0] * i1];
      }
    }

    mean(b_taper, ZZ);
    Zwindow_im = b_w / 2.0 * fs;
    i0 = ZZ->size[0] * ZZ->size[1];
    ZZ->size[0] = 1;
    emxEnsureCapacity_real_T(ZZ, i0);
    ixstart = ZZ->size[0];
    n = ZZ->size[1];
    loop_ub = ixstart * n;
    for (i0 = 0; i0 < loop_ub; i0++) {
      ZZ->data[i0] /= Zwindow_im;
    }

    i0 = b_Zwindow->size[0] * b_Zwindow->size[1];
    b_Zwindow->size[0] = Zwindow->size[1];
    b_Zwindow->size[1] = Zwindow->size[0];
    emxEnsureCapacity_creal_T(b_Zwindow, i0);
    loop_ub = Zwindow->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = Zwindow->size[1];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        b_Zwindow->data[i1 + b_Zwindow->size[0] * i0] = Zwindow->data[i0 +
          Zwindow->size[0] * i1];
      }
    }

    b_mean(b_Zwindow, A);
    Zwindow_im = b_w / 2.0 * fs;
    i0 = b_Zwindow->size[0] * b_Zwindow->size[1];
    b_Zwindow->size[0] = UZwindowmerged->size[1];
    b_Zwindow->size[1] = UZwindowmerged->size[0];
    emxEnsureCapacity_creal_T(b_Zwindow, i0);
    loop_ub = UZwindowmerged->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = UZwindowmerged->size[1];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        b_Zwindow->data[i1 + b_Zwindow->size[0] * i0] = UZwindowmerged->data[i0
          + UZwindowmerged->size[0] * i1];
      }
    }

    b_mean(b_Zwindow, UZ);
    Zwindow_re = b_w / 2.0 * fs;
    i0 = UZ->size[0] * UZ->size[1];
    UZ->size[0] = 1;
    emxEnsureCapacity_creal_T(UZ, i0);
    ixstart = UZ->size[0];
    n = UZ->size[1];
    loop_ub = ixstart * n;
    for (i0 = 0; i0 < loop_ub; i0++) {
      alpha = UZ->data[i0].re;
      Uwindow_im = UZ->data[i0].im;
      if (Uwindow_im == 0.0) {
        UZ->data[i0].re = alpha / Zwindow_re;
        UZ->data[i0].im = 0.0;
      } else if (alpha == 0.0) {
        UZ->data[i0].re = 0.0;
        UZ->data[i0].im = Uwindow_im / Zwindow_re;
      } else {
        UZ->data[i0].re = alpha / Zwindow_re;
        UZ->data[i0].im = Uwindow_im / Zwindow_re;
      }
    }

    i0 = b_Zwindow->size[0] * b_Zwindow->size[1];
    b_Zwindow->size[0] = VZwindowmerged->size[1];
    b_Zwindow->size[1] = VZwindowmerged->size[0];
    emxEnsureCapacity_creal_T(b_Zwindow, i0);
    loop_ub = VZwindowmerged->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = VZwindowmerged->size[1];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        b_Zwindow->data[i1 + b_Zwindow->size[0] * i0] = VZwindowmerged->data[i0
          + VZwindowmerged->size[0] * i1];
      }
    }

    b_mean(b_Zwindow, VZ);
    Zwindow_re = b_w / 2.0 * fs;
    i0 = VZ->size[0] * VZ->size[1];
    VZ->size[0] = 1;
    emxEnsureCapacity_creal_T(VZ, i0);
    ixstart = VZ->size[0];
    n = VZ->size[1];
    loop_ub = ixstart * n;
    for (i0 = 0; i0 < loop_ub; i0++) {
      alpha = VZ->data[i0].re;
      Uwindow_im = VZ->data[i0].im;
      if (Uwindow_im == 0.0) {
        VZ->data[i0].re = alpha / Zwindow_re;
        VZ->data[i0].im = 0.0;
      } else if (alpha == 0.0) {
        VZ->data[i0].re = 0.0;
        VZ->data[i0].im = Uwindow_im / Zwindow_re;
      } else {
        VZ->data[i0].re = alpha / Zwindow_re;
        VZ->data[i0].im = Uwindow_im / Zwindow_re;
      }
    }

    /*  convert to displacement spectra from GPS velocities */
    /*  assumes perfectly circular deepwater orbits */
    /*  could be extended to finite depth by calling wavenumber.m  */
    i0 = b_ufiltered->size[0] * b_ufiltered->size[1];
    b_ufiltered->size[0] = 1;
    b_ufiltered->size[1] = b_f->size[1];
    emxEnsureCapacity_real_T(b_ufiltered, i0);
    loop_ub = b_f->size[0] * b_f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_ufiltered->data[i0] = 6.2831853071795862 * b_f->data[i0];
    }

    power(b_ufiltered, dir1);
    i0 = b_ufiltered->size[0] * b_ufiltered->size[1];
    b_ufiltered->size[0] = 1;
    b_ufiltered->size[1] = ufiltered->size[1];
    emxEnsureCapacity_real_T(b_ufiltered, i0);
    loop_ub = ufiltered->size[0] * ufiltered->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_ufiltered->data[i0] = ufiltered->data[i0] / Vwindow_re;
    }

    rdivide(b_ufiltered, dir1, Exx);

    /* [m^2/Hz] */
    i0 = b_ufiltered->size[0] * b_ufiltered->size[1];
    b_ufiltered->size[0] = 1;
    b_ufiltered->size[1] = b_f->size[1];
    emxEnsureCapacity_real_T(b_ufiltered, i0);
    loop_ub = b_f->size[0] * b_f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_ufiltered->data[i0] = 6.2831853071795862 * b_f->data[i0];
    }

    power(b_ufiltered, dir1);
    i0 = b_ufiltered->size[0] * b_ufiltered->size[1];
    b_ufiltered->size[0] = 1;
    b_ufiltered->size[1] = vfiltered->size[1];
    emxEnsureCapacity_real_T(b_ufiltered, i0);
    loop_ub = vfiltered->size[0] * vfiltered->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_ufiltered->data[i0] = vfiltered->data[i0] / Vwindow_im;
    }

    rdivide(b_ufiltered, dir1, Eyy);

    /* [m^2/Hz] */
    /* [m^2/Hz] */
    /* [m^2/Hz], quadspectrum of vertical heave and horizontal velocities */
    i0 = b_ufiltered->size[0] * b_ufiltered->size[1];
    b_ufiltered->size[0] = 1;
    b_ufiltered->size[1] = b_f->size[1];
    emxEnsureCapacity_real_T(b_ufiltered, i0);
    loop_ub = b_f->size[0] * b_f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_ufiltered->data[i0] = 6.2831853071795862 * b_f->data[i0];
    }

    b_power(b_ufiltered, dir1);
    i0 = b_ufiltered->size[0] * b_ufiltered->size[1];
    b_ufiltered->size[0] = 1;
    b_ufiltered->size[1] = UZ->size[1];
    emxEnsureCapacity_real_T(b_ufiltered, i0);
    loop_ub = UZ->size[0] * UZ->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_ufiltered->data[i0] = UZ->data[i0].re;
    }

    rdivide(b_ufiltered, dir1, ufiltered);

    /* [m^2/Hz], cospectrum of vertical heave and horizontal velocities */
    /* [m^2/Hz], quadspectrum of vertical heave and horizontal velocities */
    i0 = b_ufiltered->size[0] * b_ufiltered->size[1];
    b_ufiltered->size[0] = 1;
    b_ufiltered->size[1] = b_f->size[1];
    emxEnsureCapacity_real_T(b_ufiltered, i0);
    loop_ub = b_f->size[0] * b_f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_ufiltered->data[i0] = 6.2831853071795862 * b_f->data[i0];
    }

    b_power(b_ufiltered, dir1);
    i0 = b_ufiltered->size[0] * b_ufiltered->size[1];
    b_ufiltered->size[0] = 1;
    b_ufiltered->size[1] = VZ->size[1];
    emxEnsureCapacity_real_T(b_ufiltered, i0);
    loop_ub = VZ->size[0] * VZ->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_ufiltered->data[i0] = VZ->data[i0].re;
    }

    rdivide(b_ufiltered, dir1, vfiltered);

    /* [m^2/Hz], cospectrum of vertical heave and horizontal velocities */
    i0 = b_ufiltered->size[0] * b_ufiltered->size[1];
    b_ufiltered->size[0] = 1;
    b_ufiltered->size[1] = b_f->size[1];
    emxEnsureCapacity_real_T(b_ufiltered, i0);
    loop_ub = b_f->size[0] * b_f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_ufiltered->data[i0] = 6.2831853071795862 * b_f->data[i0];
    }

    power(b_ufiltered, dir1);
    i0 = b_ufiltered->size[0] * b_ufiltered->size[1];
    b_ufiltered->size[0] = 1;
    b_ufiltered->size[1] = A->size[1];
    emxEnsureCapacity_real_T(b_ufiltered, i0);
    loop_ub = A->size[0] * A->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      alpha = A->data[i0].re;
      Uwindow_im = A->data[i0].im;
      if (Uwindow_im == 0.0) {
        alpha /= Zwindow_im;
      } else if (alpha == 0.0) {
        alpha = 0.0;
      } else {
        alpha /= Zwindow_im;
      }

      b_ufiltered->data[i0] = alpha;
    }

    rdivide(b_ufiltered, dir1, heavefiltered);

    /* [m^2/Hz] */
    /*  wave spectral moments  */
    /*  wave directions from Kuik et al, JPO, 1988 and Herbers et al, JTech, 2012 */
    /*  NOTE THAT THIS USES COSPECTRA OF Z AND U OR V, WHICH DIFFS FROM QUADSPECTRA OF Z AND X OR Y */
    i0 = dir1->size[0] * dir1->size[1];
    dir1->size[0] = 1;
    dir1->size[1] = Exx->size[1];
    emxEnsureCapacity_real_T(dir1, i0);
    loop_ub = Exx->size[0] * Exx->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      dir1->data[i0] = (Exx->data[i0] + Eyy->data[i0]) * ZZ->data[i0];
    }

    c_sqrt(dir1);
    rdivide(ufiltered, dir1, b_a1);

    /* [], would use Qxz for actual displacements */
    i0 = dir1->size[0] * dir1->size[1];
    dir1->size[0] = 1;
    dir1->size[1] = Exx->size[1];
    emxEnsureCapacity_real_T(dir1, i0);
    loop_ub = Exx->size[0] * Exx->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      dir1->data[i0] = (Exx->data[i0] + Eyy->data[i0]) * ZZ->data[i0];
    }

    c_sqrt(dir1);
    rdivide(vfiltered, dir1, b_b1);

    /* [], would use Qyz for actual displacements */
    i0 = ufiltered->size[0] * ufiltered->size[1];
    ufiltered->size[0] = 1;
    ufiltered->size[1] = Exx->size[1];
    emxEnsureCapacity_real_T(ufiltered, i0);
    loop_ub = Exx->size[0] * Exx->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      ufiltered->data[i0] = Exx->data[i0] - Eyy->data[i0];
    }

    i0 = b_ufiltered->size[0] * b_ufiltered->size[1];
    b_ufiltered->size[0] = 1;
    b_ufiltered->size[1] = Exx->size[1];
    emxEnsureCapacity_real_T(b_ufiltered, i0);
    loop_ub = Exx->size[0] * Exx->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_ufiltered->data[i0] = Exx->data[i0] + Eyy->data[i0];
    }

    rdivide(ufiltered, b_ufiltered, b_a2);
    i0 = b_ufiltered->size[0] * b_ufiltered->size[1];
    b_ufiltered->size[0] = 1;
    b_ufiltered->size[1] = heavefiltered->size[1];
    emxEnsureCapacity_real_T(b_ufiltered, i0);
    loop_ub = heavefiltered->size[0] * heavefiltered->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_ufiltered->data[i0] = 2.0 * heavefiltered->data[i0];
    }

    i0 = ufiltered->size[0] * ufiltered->size[1];
    ufiltered->size[0] = 1;
    ufiltered->size[1] = Exx->size[1];
    emxEnsureCapacity_real_T(ufiltered, i0);
    loop_ub = Exx->size[0] * Exx->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      ufiltered->data[i0] = Exx->data[i0] + Eyy->data[i0];
    }

    rdivide(b_ufiltered, ufiltered, heavefiltered);

    /*  wave directions */
    /*  note that 0 deg is for waves headed towards positive x (EAST, right hand system) */
    b_atan2(b_b1, b_a1, dir1);

    /*  [rad], 4 quadrant */
    /*  [rad], only 2 quadrant */
    /* spread1 = sqrt( 2 * ( 1 - sqrt(a1.^2 + b2.^2) ) ); */
    /* spread2 = sqrt( abs( 0.5 - 0.5 .* ( a2.*cos(2.*dir2) + b2.*cos(2.*dir2) )  )); */
    /*  use orbit shape as check on quality */
    i0 = b_ufiltered->size[0] * b_ufiltered->size[1];
    b_ufiltered->size[0] = 1;
    b_ufiltered->size[1] = Eyy->size[1];
    emxEnsureCapacity_real_T(b_ufiltered, i0);
    loop_ub = Eyy->size[0] * Eyy->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_ufiltered->data[i0] = Eyy->data[i0] + Exx->data[i0];
    }

    rdivide(ZZ, b_ufiltered, ufiltered);
    i0 = vfiltered->size[0] * vfiltered->size[1];
    vfiltered->size[0] = 1;
    vfiltered->size[1] = ZZ->size[1];
    emxEnsureCapacity_real_T(vfiltered, i0);
    loop_ub = ZZ->size[0] * ZZ->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      vfiltered->data[i0] = ZZ->data[i0];
    }

    /*  (use heave spectra as scalar energy spectra... in some cases Exx + Eyy will be better) */
    /*  wave stats */
    i0 = eastdirs->size[0] * eastdirs->size[1];
    eastdirs->size[0] = 1;
    eastdirs->size[1] = b_f->size[1];
    emxEnsureCapacity_boolean_T(eastdirs, i0);
    loop_ub = b_f->size[0] * b_f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      eastdirs->data[i0] = (b_f->data[i0] > 0.05);
    }

    i0 = r1->size[0] * r1->size[1];
    r1->size[0] = 1;
    r1->size[1] = b_f->size[1];
    emxEnsureCapacity_boolean_T(r1, i0);
    loop_ub = b_f->size[0] * b_f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r1->data[i0] = (b_f->data[i0] < 1.0);
    }

    /*  frequency cutoff for wave stats,  */
    windows = eastdirs->size[1];
    for (n = 0; n < windows; n++) {
      if (!(eastdirs->data[n] && r1->data[n])) {
        vfiltered->data[n] = 0.0;
      }
    }

    /*  significant wave height */
    windows = eastdirs->size[1] - 1;
    ixstart = 0;
    for (n = 0; n <= windows; n++) {
      if (eastdirs->data[n] && r1->data[n]) {
        ixstart++;
      }
    }

    i0 = r2->size[0] * r2->size[1];
    r2->size[0] = 1;
    r2->size[1] = ixstart;
    emxEnsureCapacity_int32_T1(r2, i0);
    ixstart = 0;
    for (n = 0; n <= windows; n++) {
      if (eastdirs->data[n] && r1->data[n]) {
        r2->data[ixstart] = n + 1;
        ixstart++;
      }
    }

    i0 = b_ufiltered->size[0] * b_ufiltered->size[1];
    b_ufiltered->size[0] = 1;
    b_ufiltered->size[1] = r2->size[1];
    emxEnsureCapacity_real_T(b_ufiltered, i0);
    loop_ub = r2->size[0] * r2->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_ufiltered->data[i0] = vfiltered->data[r2->data[i0] - 1];
    }

    alpha = sum(b_ufiltered) * bandwidth;
    b_sqrt(&alpha);
    *Hs = 4.0 * alpha;

    /*   energy period */
    /*  peak period */
    /* [~ , fpindex] = max(UU+VV); % can use velocity (picks out more distint peak) */
    ixstart = 1;
    n = vfiltered->size[1];
    alpha = vfiltered->data[0];
    b_loop_ub = 0;
    if (rtIsNaN(vfiltered->data[0])) {
      windows = 2;
      exitg1 = false;
      while ((!exitg1) && (windows <= n)) {
        ixstart = windows;
        if (!rtIsNaN(vfiltered->data[windows - 1])) {
          alpha = vfiltered->data[windows - 1];
          b_loop_ub = windows - 1;
          exitg1 = true;
        } else {
          windows++;
        }
      }
    }

    if (ixstart < vfiltered->size[1]) {
      while (ixstart + 1 <= n) {
        if (vfiltered->data[ixstart] > alpha) {
          alpha = vfiltered->data[ixstart];
          b_loop_ub = ixstart;
        }

        ixstart++;
      }
    }

    *Tp = 1.0 / b_f->data[b_loop_ub];

    /*  spectral directions */
    /*  switch from rad to deg, and CCW to CW (negate) */
    i0 = dir1->size[0] * dir1->size[1];
    dir1->size[0] = 1;
    emxEnsureCapacity_real_T(dir1, i0);
    ixstart = dir1->size[0];
    n = dir1->size[1];
    loop_ub = ixstart * n;
    for (i0 = 0; i0 < loop_ub; i0++) {
      dir1->data[i0] = -57.324840764331206 * dir1->data[i0] + 90.0;
    }

    /*  rotate from eastward = 0 to northward  = 0 */
    windows = dir1->size[1] - 1;
    ixstart = 0;
    for (n = 0; n <= windows; n++) {
      if (dir1->data[n] < 0.0) {
        ixstart++;
      }
    }

    i0 = r3->size[0] * r3->size[1];
    r3->size[0] = 1;
    r3->size[1] = ixstart;
    emxEnsureCapacity_int32_T1(r3, i0);
    ixstart = 0;
    for (n = 0; n <= windows; n++) {
      if (dir1->data[n] < 0.0) {
        r3->data[ixstart] = n + 1;
        ixstart++;
      }
    }

    i0 = b_dir1->size[0];
    b_dir1->size[0] = r3->size[0] * r3->size[1];
    emxEnsureCapacity_real_T1(b_dir1, i0);
    loop_ub = r3->size[0] * r3->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_dir1->data[i0] = dir1->data[r3->data[i0] - 1] + 360.0;
    }

    loop_ub = b_dir1->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      dir1->data[r3->data[i0] - 1] = b_dir1->data[i0];
    }

    /*  take NW quadrant from negative to 270-360 range */
    i0 = eastdirs->size[0] * eastdirs->size[1];
    eastdirs->size[0] = 1;
    eastdirs->size[1] = dir1->size[1];
    emxEnsureCapacity_boolean_T(eastdirs, i0);
    loop_ub = dir1->size[0] * dir1->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      eastdirs->data[i0] = (dir1->data[i0] < 180.0);
    }

    windows = dir1->size[1] - 1;
    ixstart = 0;
    for (n = 0; n <= windows; n++) {
      if (dir1->data[n] > 180.0) {
        ixstart++;
      }
    }

    i0 = r4->size[0] * r4->size[1];
    r4->size[0] = 1;
    r4->size[1] = ixstart;
    emxEnsureCapacity_int32_T1(r4, i0);
    ixstart = 0;
    for (n = 0; n <= windows; n++) {
      if (dir1->data[n] > 180.0) {
        r4->data[ixstart] = n + 1;
        ixstart++;
      }
    }

    i0 = b_dir1->size[0];
    b_dir1->size[0] = r4->size[0] * r4->size[1];
    emxEnsureCapacity_real_T1(b_dir1, i0);
    loop_ub = r4->size[0] * r4->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_dir1->data[i0] = dir1->data[r4->data[i0] - 1] - 180.0;
    }

    loop_ub = b_dir1->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      dir1->data[r4->data[i0] - 1] = b_dir1->data[i0];
    }

    /*  take reciprocal such wave direction is FROM, not TOWARDS */
    windows = eastdirs->size[1] - 1;
    ixstart = 0;
    for (n = 0; n <= windows; n++) {
      if (eastdirs->data[n]) {
        ixstart++;
      }
    }

    i0 = r5->size[0] * r5->size[1];
    r5->size[0] = 1;
    r5->size[1] = ixstart;
    emxEnsureCapacity_int32_T1(r5, i0);
    ixstart = 0;
    for (n = 0; n <= windows; n++) {
      if (eastdirs->data[n]) {
        r5->data[ixstart] = n + 1;
        ixstart++;
      }
    }

    i0 = b_dir1->size[0];
    b_dir1->size[0] = r5->size[0] * r5->size[1];
    emxEnsureCapacity_real_T1(b_dir1, i0);
    loop_ub = r5->size[0] * r5->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_dir1->data[i0] = dir1->data[r5->data[i0] - 1] + 180.0;
    }

    loop_ub = b_dir1->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      dir1->data[r5->data[i0] - 1] = b_dir1->data[i0];
    }

    /*  take reciprocal such wave direction is FROM, not TOWARDS */
    /*  directional spread */
    /*  spread = 180 ./ 3.14 .* spread1; */
    *Dp = dir1->data[b_loop_ub];

    /*  dominant (peak) direction, use peak f */
    /*  screen for bad direction estimate, or no heave data     */
    /*  pick neighboring bands */
    for (i0 = 0; i0 < 3; i0++) {
      alpha = (double)(b_loop_ub + 1) + (-1.0 + (double)i0);
      inds[i0] = (alpha > 0.0);
      b_inds[i0] = alpha;
    }

    if (all(inds)) {
      for (i0 = 0; i0 < 3; i0++) {
        c_dir1[i0] = dir1->data[(int)b_inds[i0] - 1];
      }

      if (b_std(c_dir1) > 45.0) {
        *Dp = 9999.0;
      }
    } else {
      *Dp = 9999.0;
    }

    /*  prune high frequency results */
    /*  E( f > maxf ) = []; */
    /*  dir( f > maxf ) = []; */
    /*  % spread( f > maxf ) = []; */
    /*  a1( f > maxf ) = []; */
    /*  b1( f > maxf ) = []; */
    /*  a2( f > maxf ) = []; */
    /*  b2( f > maxf ) = []; */
    /*  check( f > maxf ) = []; */
    /*  f( f > maxf ) = []; */
    /*  Mike S: Prune to exactly 42 frequency bands - assumes fs = 5 Hz!! */
    for (i0 = 0; i0 < 42; i0++) {
      E[i0] = vfiltered->data[i0];
    }

    /*  spread( f > maxf ) = []; */
    for (i0 = 0; i0 < 42; i0++) {
      a1[i0] = b_a1->data[i0];
    }

    for (i0 = 0; i0 < 42; i0++) {
      b1[i0] = b_b1->data[i0];
    }

    for (i0 = 0; i0 < 42; i0++) {
      a2[i0] = b_a2->data[i0];
    }

    for (i0 = 0; i0 < 42; i0++) {
      b2[i0] = heavefiltered->data[i0];
    }

    for (i0 = 0; i0 < 42; i0++) {
      check[i0] = ufiltered->data[i0];
    }

    for (i0 = 0; i0 < 42; i0++) {
      f[i0] = b_f->data[i0];
    }
  } else {
    /*  if not enough points or sufficent sampling rate or data, give 9999 */
    *Hs = 9999.0;
    *Tp = 9999.0;
    *Dp = 9999.0;

    /*  Mike S: Fix E,f, etc to 42 frequency bands - assumes fs = 5 Hz!! */
    for (i0 = 0; i0 < 42; i0++) {
      E[i0] = 9999.0;
      f[i0] = 9999.0;
      a1[i0] = 9999.0;
      b1[i0] = 9999.0;
      a2[i0] = 9999.0;
      b2[i0] = 9999.0;
      check[i0] = 9999.0;
    }
  }

  emxFree_real_T(&b_dir1);
  emxFree_creal_T(&b_Uwindow);
  emxFree_real_T(&r7);
  emxFree_real_T(&b_uwindow);
  emxFree_int32_T(&w);
  emxFree_real_T(&b_taper);
  emxFree_creal_T(&b_Zwindow);
  emxFree_real_T(&b_ufiltered);
  emxFree_real_T(&r6);
  emxFree_creal_T(&A);
  emxFree_int32_T(&r5);
  emxFree_int32_T(&r4);
  emxFree_int32_T(&r3);
  emxFree_int32_T(&r2);
  emxFree_boolean_T(&r1);
  emxFree_int32_T(&r0);
  emxFree_real_T(&b_a2);
  emxFree_real_T(&b_b1);
  emxFree_real_T(&b_a1);
  emxFree_real_T(&b_f);
  emxFree_boolean_T(&eastdirs);
  emxFree_real_T(&dir1);
  emxFree_real_T(&Eyy);
  emxFree_real_T(&Exx);
  emxFree_creal_T(&VZ);
  emxFree_creal_T(&UZ);
  emxFree_real_T(&ZZ);
  emxFree_creal_T(&VZwindowmerged);
  emxFree_creal_T(&UZwindowmerged);
  emxFree_creal_T(&UVwindow);
  emxFree_creal_T(&Zwindow);
  emxFree_creal_T(&Vwindow);
  emxFree_creal_T(&Uwindow);
  emxFree_real_T(&factheave);
  emxFree_real_T(&factv);
  emxFree_real_T(&factu);
  emxFree_real_T(&vwindowtaper);
  emxFree_real_T(&uwindowtaper);
  emxFree_real_T(&taper);
  emxFree_real_T(&heavewindow);
  emxFree_real_T(&vwindow);
  emxFree_real_T(&uwindow);
  emxFree_real_T(&heavefiltered);
  emxFree_real_T(&vfiltered);
  emxFree_real_T(&ufiltered);

  /*  quality control */
  if (*Tp > 20.0) {
    *Hs = 9999.0;
    *Tp = 9999.0;
    *Dp = 9999.0;
  }
}

/* End of code generation (SBGwaves.cpp) */
