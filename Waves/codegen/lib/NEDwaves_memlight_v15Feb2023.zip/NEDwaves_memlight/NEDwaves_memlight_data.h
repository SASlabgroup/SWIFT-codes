/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: NEDwaves_memlight_data.h
 *
 * MATLAB Coder version            : 5.4
 * C/C++ source code generated on  : 06-Jan-2023 10:46:55
 */

#ifndef NEDWAVES_MEMLIGHT_DATA_H
#define NEDWAVES_MEMLIGHT_DATA_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern const double dv[42];

#endif
/*
 * File trailer for NEDwaves_memlight_data.h
 *
 * [EOF]
 */
