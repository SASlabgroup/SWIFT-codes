/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: NEDwaves_memlight_data.c
 *
 * MATLAB Coder version            : 5.4
 * C/C++ source code generated on  : 16-Oct-2023 17:01:43
 */

/* Include Files */
#include "NEDwaves_memlight_data.h"
#include "rt_nonfinite.h"

/*
 * File trailer for NEDwaves_memlight_data.c
 *
 * [EOF]
 */
