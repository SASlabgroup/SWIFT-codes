/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * detrend.cpp
 *
 * Code generation for function 'detrend'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "GPSandIMUwaves.h"
#include "detrend.h"
#include "GPSandIMUwaves_emxutil.h"
#include "mldivide.h"

/* Function Definitions */
void b_detrend(emxArray_real_T *x)
{
  emxArray_real_T *a;
  int nrows;
  int ar;
  int ia;
  emxArray_real_T *b;
  emxArray_real_T *C;
  unsigned int a_idx_0;
  int m;
  int ic;
  int br;
  emxInit_real_T(&a, 2);
  nrows = x->size[0];
  ar = x->size[0];
  ia = a->size[0] * a->size[1];
  a->size[0] = ar;
  a->size[1] = 2;
  emxEnsureCapacity((emxArray__common *)a, ia, (int)sizeof(double));
  for (ar = 1; ar <= nrows; ar++) {
    a->data[ar - 1] = (double)ar / (double)nrows;
    a->data[(ar + a->size[0]) - 1] = 1.0;
  }

  emxInit_real_T1(&b, 1);
  mldivide(a, x, b);
  emxInit_real_T1(&C, 1);
  if (b->size[0] == 1) {
    ia = C->size[0];
    C->size[0] = a->size[0];
    emxEnsureCapacity((emxArray__common *)C, ia, (int)sizeof(double));
    ar = a->size[0];
    for (ia = 0; ia < ar; ia++) {
      C->data[ia] = 0.0;
      for (nrows = 0; nrows < 2; nrows++) {
        C->data[ia] += a->data[ia + a->size[0] * nrows] * b->data[nrows];
      }
    }
  } else {
    a_idx_0 = (unsigned int)a->size[0];
    ia = C->size[0];
    C->size[0] = (int)a_idx_0;
    emxEnsureCapacity((emxArray__common *)C, ia, (int)sizeof(double));
    m = a->size[0];
    ar = C->size[0];
    ia = C->size[0];
    C->size[0] = ar;
    emxEnsureCapacity((emxArray__common *)C, ia, (int)sizeof(double));
    for (ia = 0; ia < ar; ia++) {
      C->data[ia] = 0.0;
    }

    if (a->size[0] == 0) {
    } else {
      ar = 0;
      while ((m > 0) && (ar <= 0)) {
        for (ic = 1; ic <= m; ic++) {
          C->data[ic - 1] = 0.0;
        }

        ar = m;
      }

      br = 0;
      ar = 0;
      while ((m > 0) && (ar <= 0)) {
        ar = -1;
        for (nrows = br; nrows + 1 <= br + 2; nrows++) {
          if (b->data[nrows] != 0.0) {
            ia = ar;
            for (ic = 0; ic + 1 <= m; ic++) {
              ia++;
              C->data[ic] += b->data[nrows] * a->data[ia];
            }
          }

          ar += m;
        }

        br += 2;
        ar = m;
      }
    }
  }

  emxFree_real_T(&b);
  emxFree_real_T(&a);
  ia = x->size[0];
  emxEnsureCapacity((emxArray__common *)x, ia, (int)sizeof(double));
  ar = x->size[0];
  for (ia = 0; ia < ar; ia++) {
    x->data[ia] -= C->data[ia];
  }

  emxFree_real_T(&C);
}

void detrend(emxArray_real_T *x)
{
  emxArray_real_T *b_x;
  int ia;
  int ar;
  emxArray_real_T *a;
  int nrows;
  unsigned int x_idx_0;
  emxArray_real_T *b;
  emxArray_real_T *C;
  int m;
  int ic;
  int br;
  emxInit_real_T1(&b_x, 1);
  ia = b_x->size[0];
  b_x->size[0] = x->size[1];
  emxEnsureCapacity((emxArray__common *)b_x, ia, (int)sizeof(double));
  ar = x->size[1];
  for (ia = 0; ia < ar; ia++) {
    b_x->data[ia] = x->data[x->size[0] * ia];
  }

  emxInit_real_T(&a, 2);
  nrows = b_x->size[0];
  x_idx_0 = (unsigned int)b_x->size[0];
  ia = a->size[0] * a->size[1];
  a->size[0] = (int)x_idx_0;
  a->size[1] = 2;
  emxEnsureCapacity((emxArray__common *)a, ia, (int)sizeof(double));
  for (ar = 1; ar <= nrows; ar++) {
    a->data[ar - 1] = (double)ar / (double)nrows;
    a->data[(ar + a->size[0]) - 1] = 1.0;
  }

  emxInit_real_T1(&b, 1);
  mldivide(a, b_x, b);
  emxInit_real_T1(&C, 1);
  if (b->size[0] == 1) {
    ia = C->size[0];
    C->size[0] = a->size[0];
    emxEnsureCapacity((emxArray__common *)C, ia, (int)sizeof(double));
    ar = a->size[0];
    for (ia = 0; ia < ar; ia++) {
      C->data[ia] = 0.0;
      for (nrows = 0; nrows < 2; nrows++) {
        C->data[ia] += a->data[ia + a->size[0] * nrows] * b->data[nrows];
      }
    }
  } else {
    x_idx_0 = (unsigned int)a->size[0];
    ia = C->size[0];
    C->size[0] = (int)x_idx_0;
    emxEnsureCapacity((emxArray__common *)C, ia, (int)sizeof(double));
    m = a->size[0];
    ar = C->size[0];
    ia = C->size[0];
    C->size[0] = ar;
    emxEnsureCapacity((emxArray__common *)C, ia, (int)sizeof(double));
    for (ia = 0; ia < ar; ia++) {
      C->data[ia] = 0.0;
    }

    if (a->size[0] == 0) {
    } else {
      ar = 0;
      while ((m > 0) && (ar <= 0)) {
        for (ic = 1; ic <= m; ic++) {
          C->data[ic - 1] = 0.0;
        }

        ar = m;
      }

      br = 0;
      ar = 0;
      while ((m > 0) && (ar <= 0)) {
        ar = -1;
        for (nrows = br; nrows + 1 <= br + 2; nrows++) {
          if (b->data[nrows] != 0.0) {
            ia = ar;
            for (ic = 0; ic + 1 <= m; ic++) {
              ia++;
              C->data[ic] += b->data[nrows] * a->data[ia];
            }
          }

          ar += m;
        }

        br += 2;
        ar = m;
      }
    }
  }

  emxFree_real_T(&b);
  emxFree_real_T(&a);
  ia = x->size[0] * x->size[1];
  x->size[0] = 1;
  x->size[1] = b_x->size[0];
  emxEnsureCapacity((emxArray__common *)x, ia, (int)sizeof(double));
  ar = b_x->size[0];
  for (ia = 0; ia < ar; ia++) {
    x->data[x->size[0] * ia] = b_x->data[ia] - C->data[ia];
  }

  emxFree_real_T(&C);
  emxFree_real_T(&b_x);
}

/* End of code generation (detrend.cpp) */
