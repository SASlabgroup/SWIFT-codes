/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * GPSandIMUwaves_terminate.cpp
 *
 * Code generation for function 'GPSandIMUwaves_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "GPSandIMUwaves.h"
#include "GPSandIMUwaves_terminate.h"

/* Function Definitions */
void GPSandIMUwaves_terminate()
{
  /* (no terminate code required) */
}

/* End of code generation (GPSandIMUwaves_terminate.cpp) */
