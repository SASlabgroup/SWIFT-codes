/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * GPSandIMUwaves.cpp
 *
 * Code generation for function 'GPSandIMUwaves'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "GPSandIMUwaves.h"
#include "GPSandIMUwaves_emxutil.h"
#include "detrend.h"
#include "mean.h"
#include "std.h"
#include "all.h"
#include "rdivide.h"
#include "sum.h"
#include "sqrt.h"
#include "abs.h"
#include "cos.h"
#include "power.h"
#include "atan2.h"
#include "fft.h"
#include "var.h"
#include "sin.h"

/* Function Declarations */
static void b_eml_null_assignment(emxArray_creal_T *x, const emxArray_real_T
  *idx);
static void c_eml_null_assignment(emxArray_creal_T *x);
static void d_eml_null_assignment(emxArray_real_T *x, const emxArray_boolean_T
  *idx);
static void eml_null_assignment(const emxArray_real_T *x, const
  emxArray_boolean_T *idx, emxArray_real_T *b_x);
static double rt_remd_snf(double u0, double u1);
static double rt_roundd_snf(double u);

/* Function Definitions */
static void b_eml_null_assignment(emxArray_creal_T *x, const emxArray_real_T
  *idx)
{
  int nrowx;
  int ncolx;
  int nrows;
  int j;
  int i;
  emxArray_boolean_T *b;
  int k;
  emxArray_creal_T *b_x;
  nrowx = x->size[0];
  ncolx = x->size[1];
  if (idx->size[1] == 1) {
    nrows = x->size[0] - 1;
    for (j = 0; j + 1 <= ncolx; j++) {
      for (i = (int)idx->data[0]; i < nrowx; i++) {
        x->data[(i + x->size[0] * j) - 1] = x->data[i + x->size[0] * j];
      }
    }
  } else {
    emxInit_boolean_T(&b, 2);
    j = b->size[0] * b->size[1];
    b->size[0] = 1;
    b->size[1] = x->size[0];
    emxEnsureCapacity((emxArray__common *)b, j, (int)sizeof(boolean_T));
    k = x->size[0];
    for (j = 0; j < k; j++) {
      b->data[j] = false;
    }

    for (k = 1; k <= idx->size[1]; k++) {
      b->data[(int)idx->data[k - 1] - 1] = true;
    }

    nrows = 0;
    for (k = 1; k <= b->size[1]; k++) {
      nrows += b->data[k - 1];
    }

    nrows = x->size[0] - nrows;
    i = 0;
    for (k = 1; k <= nrowx; k++) {
      if ((k > b->size[1]) || (!b->data[k - 1])) {
        for (j = 0; j + 1 <= ncolx; j++) {
          x->data[i + x->size[0] * j] = x->data[(k + x->size[0] * j) - 1];
        }

        i++;
      }
    }

    emxFree_boolean_T(&b);
  }

  if (1 > nrows) {
    k = 0;
  } else {
    k = nrows;
  }

  emxInit_creal_T(&b_x, 2);
  nrows = x->size[1];
  j = b_x->size[0] * b_x->size[1];
  b_x->size[0] = k;
  b_x->size[1] = nrows;
  emxEnsureCapacity((emxArray__common *)b_x, j, (int)sizeof(creal_T));
  for (j = 0; j < nrows; j++) {
    for (i = 0; i < k; i++) {
      b_x->data[i + b_x->size[0] * j] = x->data[i + x->size[0] * j];
    }
  }

  j = x->size[0] * x->size[1];
  x->size[0] = b_x->size[0];
  x->size[1] = b_x->size[1];
  emxEnsureCapacity((emxArray__common *)x, j, (int)sizeof(creal_T));
  k = b_x->size[1];
  for (j = 0; j < k; j++) {
    nrows = b_x->size[0];
    for (i = 0; i < nrows; i++) {
      x->data[i + x->size[0] * j] = b_x->data[i + b_x->size[0] * j];
    }
  }

  emxFree_creal_T(&b_x);
}

static void c_eml_null_assignment(emxArray_creal_T *x)
{
  emxArray_creal_T *b_x;
  int i;
  int loop_ub;
  int j;
  emxArray_creal_T *c_x;
  int i10;
  emxInit_creal_T(&b_x, 2);
  i = b_x->size[0] * b_x->size[1];
  b_x->size[0] = x->size[0];
  b_x->size[1] = x->size[1];
  emxEnsureCapacity((emxArray__common *)b_x, i, (int)sizeof(creal_T));
  loop_ub = x->size[0] * x->size[1];
  for (i = 0; i < loop_ub; i++) {
    b_x->data[i] = x->data[i];
  }

  for (j = 0; j + 1 <= x->size[1]; j++) {
    for (i = 1; i < x->size[0]; i++) {
      b_x->data[(i + b_x->size[0] * j) - 1] = b_x->data[i + b_x->size[0] * j];
    }
  }

  if (1 > x->size[0] - 1) {
    loop_ub = 0;
  } else {
    loop_ub = x->size[0] - 1;
  }

  emxInit_creal_T(&c_x, 2);
  j = b_x->size[1];
  i = c_x->size[0] * c_x->size[1];
  c_x->size[0] = loop_ub;
  c_x->size[1] = j;
  emxEnsureCapacity((emxArray__common *)c_x, i, (int)sizeof(creal_T));
  for (i = 0; i < j; i++) {
    for (i10 = 0; i10 < loop_ub; i10++) {
      c_x->data[i10 + c_x->size[0] * i] = b_x->data[i10 + b_x->size[0] * i];
    }
  }

  i = b_x->size[0] * b_x->size[1];
  b_x->size[0] = c_x->size[0];
  b_x->size[1] = c_x->size[1];
  emxEnsureCapacity((emxArray__common *)b_x, i, (int)sizeof(creal_T));
  loop_ub = c_x->size[1];
  for (i = 0; i < loop_ub; i++) {
    j = c_x->size[0];
    for (i10 = 0; i10 < j; i10++) {
      b_x->data[i10 + b_x->size[0] * i] = c_x->data[i10 + c_x->size[0] * i];
    }
  }

  emxFree_creal_T(&c_x);
  i = x->size[0] * x->size[1];
  x->size[0] = b_x->size[0];
  x->size[1] = b_x->size[1];
  emxEnsureCapacity((emxArray__common *)x, i, (int)sizeof(creal_T));
  loop_ub = b_x->size[1];
  for (i = 0; i < loop_ub; i++) {
    j = b_x->size[0];
    for (i10 = 0; i10 < j; i10++) {
      x->data[i10 + x->size[0] * i] = b_x->data[i10 + b_x->size[0] * i];
    }
  }

  emxFree_creal_T(&b_x);
}

static void d_eml_null_assignment(emxArray_real_T *x, const emxArray_boolean_T
  *idx)
{
  int nxin;
  int k0;
  int k;
  int nxout;
  nxin = x->size[1];
  k0 = 0;
  for (k = 1; k <= idx->size[1]; k++) {
    k0 += idx->data[k - 1];
  }

  nxout = x->size[1] - k0;
  k0 = -1;
  for (k = 1; k <= nxin; k++) {
    if ((k > idx->size[1]) || (!idx->data[k - 1])) {
      k0++;
      x->data[k0] = x->data[k - 1];
    }
  }

  k0 = x->size[0] * x->size[1];
  if (1 > nxout) {
    x->size[1] = 0;
  } else {
    x->size[1] = nxout;
  }

  emxEnsureCapacity((emxArray__common *)x, k0, (int)sizeof(double));
}

static void eml_null_assignment(const emxArray_real_T *x, const
  emxArray_boolean_T *idx, emxArray_real_T *b_x)
{
  int i7;
  int loop_ub;
  i7 = b_x->size[0] * b_x->size[1];
  b_x->size[0] = 1;
  b_x->size[1] = x->size[1];
  emxEnsureCapacity((emxArray__common *)b_x, i7, (int)sizeof(double));
  loop_ub = x->size[0] * x->size[1];
  for (i7 = 0; i7 < loop_ub; i7++) {
    b_x->data[i7] = x->data[i7];
  }

  d_eml_null_assignment(b_x, idx);
}

static double rt_remd_snf(double u0, double u1)
{
  double y;
  double b_u1;
  double tr;
  if (!((!rtIsNaN(u0)) && (!rtIsInf(u0)) && ((!rtIsNaN(u1)) && (!rtIsInf(u1)))))
  {
    y = rtNaN;
  } else {
    if (u1 < 0.0) {
      b_u1 = ceil(u1);
    } else {
      b_u1 = floor(u1);
    }

    if ((u1 != 0.0) && (u1 != b_u1)) {
      tr = u0 / u1;
      if (fabs(tr - rt_roundd_snf(tr)) <= DBL_EPSILON * fabs(tr)) {
        y = 0.0;
      } else {
        y = fmod(u0, u1);
      }
    } else {
      y = fmod(u0, u1);
    }
  }

  return y;
}

static double rt_roundd_snf(double u)
{
  double y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

void GPSandIMUwaves(emxArray_real_T *u, emxArray_real_T *v, emxArray_real_T *az,
                    const emxArray_real_T *pitch, const emxArray_real_T *roll,
                    double fs, double *Hs, double *Tp, double *Dp,
                    emxArray_real_T *E, emxArray_real_T *f, emxArray_real_T *a1,
                    emxArray_real_T *b1, emxArray_real_T *a2, emxArray_real_T
                    *b2)
{
  unsigned int uv0[2];
  int i0;
  int loop_ub;
  int azdummy;
  double anew;
  emxArray_real_T *ufiltered;
  emxArray_real_T *r0;
  emxArray_real_T *b_az;
  emxArray_real_T *r1;
  boolean_T guard1 = false;
  int nm1d2;
  int k;
  emxArray_boolean_T *badu;
  emxArray_boolean_T *badv;
  emxArray_int32_T *r2;
  int n;
  emxArray_int32_T *r3;
  emxArray_real_T *b_u;
  emxArray_real_T *b_v;
  int pts;
  emxArray_real_T *vfiltered;
  emxArray_real_T *azfiltered;
  emxArray_real_T *uwindow;
  emxArray_real_T *vwindow;
  emxArray_real_T *azwindow;
  emxArray_real_T *taper;
  emxArray_real_T *uwindowtaper;
  emxArray_real_T *vwindowtaper;
  emxArray_real_T *factu;
  emxArray_real_T *factv;
  emxArray_real_T *factaz;
  emxArray_creal_T *Uwindow;
  emxArray_creal_T *Vwindow;
  emxArray_creal_T *AZwindow;
  emxArray_real_T *UUwindow;
  emxArray_real_T *VVwindow;
  emxArray_real_T *AZAZwindow;
  emxArray_creal_T *UVwindow;
  emxArray_creal_T *UAZwindow;
  emxArray_creal_T *VAZwindow;
  emxArray_real_T *UU;
  emxArray_real_T *VV;
  emxArray_creal_T *UV;
  emxArray_creal_T *UAZ;
  emxArray_creal_T *VAZ;
  emxArray_real_T *Eyy;
  emxArray_real_T *Ezz;
  emxArray_real_T *dir1;
  emxArray_int32_T *r4;
  emxArray_creal_T *r5;
  emxArray_real_T *a;
  emxArray_creal_T *A;
  emxArray_real_T *r6;
  emxArray_boolean_T *b_f;
  emxArray_boolean_T *c_f;
  emxArray_boolean_T *d_f;
  emxArray_boolean_T *e_f;
  emxArray_boolean_T *f_f;
  emxArray_real_T *r7;
  emxArray_boolean_T *g_f;
  emxArray_boolean_T *h_f;
  emxArray_boolean_T *i_f;
  emxArray_real_T *b_E;
  emxArray_real_T *b_Eyy;
  emxArray_real_T *r8;
  emxArray_real_T *r9;
  emxArray_real_T *c_E;
  emxArray_real_T *d_E;
  emxArray_real_T *e_E;
  emxArray_real_T *b_UV;
  emxArray_real_T *r10;
  emxArray_real_T *b_VAZ;
  emxArray_real_T *r11;
  emxArray_real_T *b_UAZ;
  emxArray_real_T *r12;
  emxArray_real_T *r13;
  emxArray_real_T *r14;
  emxArray_real_T *r15;
  emxArray_creal_T *b_AZwindow;
  emxArray_creal_T *b_Vwindow;
  emxArray_creal_T *b_Uwindow;
  emxArray_real_T *b_azwindow;
  emxArray_real_T *b_vwindow;
  emxArray_real_T *b_uwindow;
  emxArray_real_T *w;
  emxArray_real_T *b_w;
  emxArray_real_T *c_w;
  emxArray_real_T *r16;
  emxArray_real_T *r17;
  emxArray_real_T *r18;
  emxArray_real_T *b_ufiltered;
  emxArray_creal_T *b_VAZwindow;
  emxArray_creal_T *b_UAZwindow;
  emxArray_creal_T *b_UVwindow;
  emxArray_real_T *b_AZAZwindow;
  emxArray_real_T *b_VVwindow;
  emxArray_real_T *b_UUwindow;
  emxArray_real_T *r19;
  emxArray_real_T *r20;
  emxArray_real_T *r21;
  emxArray_real_T *b_dir1;
  emxArray_real_T *c_dir1;
  emxArray_real_T *d_dir1;
  emxArray_real_T *r22;
  emxArray_real_T *e_dir1;
  emxArray_real_T *j_f;
  emxArray_real_T *b_vfiltered;
  double alpha;
  int ui;
  double d_w;
  int windows;
  int q;
  double apnd;
  double ndbl;
  double cdiff;
  int i1;
  int itmp;
  double y;
  double Uwindow_im;
  int mi;
  double b_mi;
  double b_n;
  double bandwidth;
  boolean_T exitg1;
  boolean_T inds[3];
  double b_inds[3];
  double c_inds;
  double f_dir1[3];

  /*  matlab function to read and process GPS and IMU data */
  /*    to estimate wave height, period, direction, and spectral moments */
  /*    assuming deep-water limit of surface gravity wave dispersion relation */
  /*  */
  /*  Inputs are east velocity [m/s], north velocity [m/s], vertical  */
  /*  accelerations [g], pitch [rad], roll [rad], sampling rate [Hz] */
  /*  */
  /*  Some inputs can be empty variables, in which case the algorithm will use */
  /*  whatever non-empty inputs are available, with preference for GPS */
  /*  velocities */
  /*  */
  /*  Required input is sampling rate, which must be at least 1 Hz and the same */
  /*  for all variables.  Additionaly, non-empty input time series data must  */
  /*  have at least 512 points and all be the same size. */
  /*  */
  /*  Outputs are significat wave height [m], dominant period [s], dominant direction  */
  /*  [deg T, using meteorological from which waves are propagating], spectral  */
  /*  energy density [m^2/Hz], frequency [Hz], and  */
  /*  the normalized spectral moments a1, b1, a2, b2,  */
  /*  */
  /*  Outputs will be '9999' for invalid results. */
  /*  */
  /*  Outputs can be supressed, in order, thus full usage is as follows: */
  /*  */
  /*    [ Hs, Tp, Dp, E, f, a1, b1, a2, b2 ] = GPSandIMUwaves(u,v,az,pitch,roll,fs);  */
  /*  */
  /*  and minimal usage is: */
  /*  */
  /*    [ Hs, Tp ] = GPSandIMUwaves(u,v,[],[],[],fs);  */
  /*  */
  /*  */
  /*  J. Thomson,  12/2013, v1, modified from GPSwaves.m */
  /*                1/2014, v2, include pitch and roll to correct vertical accelerations */
  /*                4/2014, v3, N/A  */
  /*                6/2014, v4, high-pass filtering with RC time constant = 20s */
  /*                            correct IMU orientation (+ z acc has proper phase) */
  /*                            use velocity spectra to select peak period */
  /*                            correct direction estimate (rotation error) */
  /*                            use GPS for all scalar spectra (less noise) */
  /*                            changes spectra parameters to report higher f */
  /*                                while keeping same # (=42) of frequencies */
  /*                12/2014, v5, fix directions by using cospectra of az and u v */
  /*                            (rather than quadspectrum, which is only appropriate for displacements                           directional estimate when not upright */
  /*                12/2015, v6, remove the low-freq cutoff for spectra, but keep it for bulk stats */
  /*  */
  /*                10/2017, v7, change the RC filter parameter to 3.5, after */
  /*                            realizing that the cuttoff period is 2 pi * RC, not RC */
  /*               */
  /*                */
  /* % tunable parameters */
  /*  low frequency noise ratio tolerance */
  /*  NOT APPLIED IN v6 */
  /* LFNR = 4 ;  */
  /*  standard deviations for despiking         */
  /*  time constant [s] for high-pass filter,  */
  /*  cutoff period is 2*pi*RC */
  /*  energy ratios (unused as of version 3) */
  /* maxEratio = 5; % max allowed ratio of Ezz to Exx + Eyy, default is 5 */
  /* minEratio = .1; % min allowed ratio of Ezz to Exx + Eyy, default is 0.1 */
  /* % fixed parameters */
  /*  window length in seconds, should make 2^N samples */
  /*  freq bands to merge, must be odd? */
  /*  frequency cutoff for telemetry Hz */
  /* % deal with variable input data, with priority for GPS velocity */
  /*  if no accelerations, asign a dummy, but then void the a1,a2 result later */
  if (az->size[1] == 0) {
    /*  check for accelerations */
    for (i0 = 0; i0 < 2; i0++) {
      uv0[i0] = (unsigned int)u->size[i0];
    }

    i0 = az->size[0] * az->size[1];
    az->size[0] = 1;
    az->size[1] = (int)uv0[1];
    emxEnsureCapacity((emxArray__common *)az, i0, (int)sizeof(double));
    loop_ub = (int)uv0[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      az->data[i0] = 0.0;
    }

    azdummy = 1;
  } else {
    anew = mean(az) - 1.0;
    if (fabs(anew) > 0.1) {
      /*  check that mean of vertical acceleration is close to 1 g (upside down IMU in SWIFT hull) */
      for (i0 = 0; i0 < 2; i0++) {
        uv0[i0] = (unsigned int)u->size[i0];
      }

      i0 = az->size[0] * az->size[1];
      az->size[0] = 1;
      az->size[1] = (int)uv0[1];
      emxEnsureCapacity((emxArray__common *)az, i0, (int)sizeof(double));
      loop_ub = (int)uv0[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        az->data[i0] = 0.0;
      }

      azdummy = 1;
    } else {
      azdummy = 0;
    }
  }

  /* % rotate accelerations to realworld coordinates using Euler angles of pitch, roll, yaw */
  /*  where IMU pitch is centered at zero and roll is centered at +/- pi */
  /*  and note that IMU ouput on SWIFT is in radians  */
  /*  IMU is mounted upside down, so gravity is +1 g */
  /*  yaw not used (irrelevant for vertical) */
  /*  SWIFT specific, this accounts for phase relation of heave to vert acceleration */
  /*  if angles available, and clearly in radians (by variance), correct acceleration */
  emxInit_real_T(&ufiltered, 2);
  emxInit_real_T(&r0, 2);
  emxInit_real_T(&b_az, 2);
  emxInit_real_T(&r1, 2);
  guard1 = false;
  if ((!(pitch->size[1] == 0)) && (!(roll->size[1] == 0))) {
    b_abs(pitch, r0);
    if (var(r0) < 1.0) {
      b_abs(roll, r0);
      if (var(r0) < 1.0) {
        i0 = r0->size[0] * r0->size[1];
        r0->size[0] = 1;
        r0->size[1] = pitch->size[1];
        emxEnsureCapacity((emxArray__common *)r0, i0, (int)sizeof(double));
        loop_ub = pitch->size[0] * pitch->size[1];
        for (i0 = 0; i0 < loop_ub; i0++) {
          r0->data[i0] = pitch->data[i0];
        }

        b_cos(r0);
        i0 = ufiltered->size[0] * ufiltered->size[1];
        ufiltered->size[0] = 1;
        ufiltered->size[1] = roll->size[1];
        emxEnsureCapacity((emxArray__common *)ufiltered, i0, (int)sizeof(double));
        loop_ub = roll->size[0] * roll->size[1];
        for (i0 = 0; i0 < loop_ub; i0++) {
          ufiltered->data[i0] = roll->data[i0];
        }

        b_cos(ufiltered);
        i0 = b_az->size[0] * b_az->size[1];
        b_az->size[0] = 1;
        b_az->size[1] = az->size[1];
        emxEnsureCapacity((emxArray__common *)b_az, i0, (int)sizeof(double));
        loop_ub = az->size[0] * az->size[1];
        for (i0 = 0; i0 < loop_ub; i0++) {
          b_az->data[i0] = -az->data[i0];
        }

        i0 = r1->size[0] * r1->size[1];
        r1->size[0] = 1;
        r1->size[1] = r0->size[1];
        emxEnsureCapacity((emxArray__common *)r1, i0, (int)sizeof(double));
        loop_ub = r0->size[0] * r0->size[1];
        for (i0 = 0; i0 < loop_ub; i0++) {
          r1->data[i0] = r0->data[i0] * ufiltered->data[i0];
        }

        b_rdivide(b_az, r1, az);

        /*  approximation for small tilts (sin is small) */
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    i0 = az->size[0] * az->size[1];
    az->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)az, i0, (int)sizeof(double));
    nm1d2 = az->size[0];
    k = az->size[1];
    loop_ub = nm1d2 * k;
    for (i0 = 0; i0 < loop_ub; i0++) {
      az->data[i0] = -az->data[i0];
    }
  }

  emxFree_real_T(&r1);
  emxFree_real_T(&b_az);

  /* % Quality control inputs (despike) */
  anew = var(u);
  i0 = r0->size[0] * r0->size[1];
  r0->size[0] = 1;
  r0->size[1] = u->size[1];
  emxEnsureCapacity((emxArray__common *)r0, i0, (int)sizeof(double));
  loop_ub = u->size[0] * u->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    r0->data[i0] = u->data[i0];
  }

  emxInit_boolean_T(&badu, 2);
  detrend(r0);
  b_abs(r0, ufiltered);
  i0 = badu->size[0] * badu->size[1];
  badu->size[0] = 1;
  badu->size[1] = ufiltered->size[1];
  emxEnsureCapacity((emxArray__common *)badu, i0, (int)sizeof(boolean_T));
  anew = 10.0 * sqrt(anew);
  loop_ub = ufiltered->size[0] * ufiltered->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    badu->data[i0] = (ufiltered->data[i0] >= anew);
  }

  /*  logical array of indices for bad points */
  anew = var(v);
  i0 = r0->size[0] * r0->size[1];
  r0->size[0] = 1;
  r0->size[1] = v->size[1];
  emxEnsureCapacity((emxArray__common *)r0, i0, (int)sizeof(double));
  loop_ub = v->size[0] * v->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    r0->data[i0] = v->data[i0];
  }

  emxInit_boolean_T(&badv, 2);
  detrend(r0);
  b_abs(r0, ufiltered);
  i0 = badv->size[0] * badv->size[1];
  badv->size[0] = 1;
  badv->size[1] = ufiltered->size[1];
  emxEnsureCapacity((emxArray__common *)badv, i0, (int)sizeof(boolean_T));
  anew = 10.0 * sqrt(anew);
  loop_ub = ufiltered->size[0] * ufiltered->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    badv->data[i0] = (ufiltered->data[i0] >= anew);
  }

  emxInit_int32_T1(&r2, 2);

  /*  logical array of indices for bad points */
  n = badu->size[1] - 1;
  nm1d2 = 0;
  for (k = 0; k <= n; k++) {
    if (badu->data[k]) {
      nm1d2++;
    }
  }

  i0 = r2->size[0] * r2->size[1];
  r2->size[0] = 1;
  r2->size[1] = nm1d2;
  emxEnsureCapacity((emxArray__common *)r2, i0, (int)sizeof(int));
  nm1d2 = 0;
  for (k = 0; k <= n; k++) {
    if (badu->data[k]) {
      r2->data[nm1d2] = k + 1;
      nm1d2++;
    }
  }

  emxInit_int32_T1(&r3, 2);
  n = badu->size[1] - 1;
  nm1d2 = 0;
  for (k = 0; k <= n; k++) {
    if (!badu->data[k]) {
      nm1d2++;
    }
  }

  i0 = r3->size[0] * r3->size[1];
  r3->size[0] = 1;
  r3->size[1] = nm1d2;
  emxEnsureCapacity((emxArray__common *)r3, i0, (int)sizeof(int));
  nm1d2 = 0;
  for (k = 0; k <= n; k++) {
    if (!badu->data[k]) {
      r3->data[nm1d2] = k + 1;
      nm1d2++;
    }
  }

  emxInit_real_T(&b_u, 2);
  i0 = b_u->size[0] * b_u->size[1];
  b_u->size[0] = 1;
  b_u->size[1] = r3->size[1];
  emxEnsureCapacity((emxArray__common *)b_u, i0, (int)sizeof(double));
  loop_ub = r3->size[0] * r3->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    b_u->data[i0] = u->data[r3->data[i0] - 1];
  }

  anew = mean(b_u);
  loop_ub = r2->size[0] * r2->size[1];
  emxFree_real_T(&b_u);
  for (i0 = 0; i0 < loop_ub; i0++) {
    u->data[r2->data[i0] - 1] = anew;
  }

  n = badv->size[1] - 1;
  nm1d2 = 0;
  for (k = 0; k <= n; k++) {
    if (badv->data[k]) {
      nm1d2++;
    }
  }

  i0 = r2->size[0] * r2->size[1];
  r2->size[0] = 1;
  r2->size[1] = nm1d2;
  emxEnsureCapacity((emxArray__common *)r2, i0, (int)sizeof(int));
  nm1d2 = 0;
  for (k = 0; k <= n; k++) {
    if (badv->data[k]) {
      r2->data[nm1d2] = k + 1;
      nm1d2++;
    }
  }

  n = badv->size[1] - 1;
  nm1d2 = 0;
  for (k = 0; k <= n; k++) {
    if (!badv->data[k]) {
      nm1d2++;
    }
  }

  i0 = r3->size[0] * r3->size[1];
  r3->size[0] = 1;
  r3->size[1] = nm1d2;
  emxEnsureCapacity((emxArray__common *)r3, i0, (int)sizeof(int));
  nm1d2 = 0;
  for (k = 0; k <= n; k++) {
    if (!badv->data[k]) {
      r3->data[nm1d2] = k + 1;
      nm1d2++;
    }
  }

  emxInit_real_T(&b_v, 2);
  i0 = b_v->size[0] * b_v->size[1];
  b_v->size[0] = 1;
  b_v->size[1] = r3->size[1];
  emxEnsureCapacity((emxArray__common *)b_v, i0, (int)sizeof(double));
  loop_ub = r3->size[0] * r3->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    b_v->data[i0] = v->data[r3->data[i0] - 1];
  }

  emxFree_int32_T(&r3);
  anew = mean(b_v);
  loop_ub = r2->size[0] * r2->size[1];
  emxFree_real_T(&b_v);
  for (i0 = 0; i0 < loop_ub; i0++) {
    v->data[r2->data[i0] - 1] = anew;
  }

  /* % begin processing, if data sufficient */
  pts = u->size[1];

  /*  record length in data points */
  emxInit_real_T(&vfiltered, 2);
  emxInit_real_T(&azfiltered, 2);
  emxInit_real_T(&uwindow, 2);
  emxInit_real_T(&vwindow, 2);
  emxInit_real_T(&azwindow, 2);
  emxInit_real_T(&taper, 2);
  emxInit_real_T(&uwindowtaper, 2);
  emxInit_real_T(&vwindowtaper, 2);
  emxInit_real_T(&factu, 2);
  emxInit_real_T(&factv, 2);
  emxInit_real_T(&factaz, 2);
  emxInit_creal_T(&Uwindow, 2);
  emxInit_creal_T(&Vwindow, 2);
  emxInit_creal_T(&AZwindow, 2);
  emxInit_real_T(&UUwindow, 2);
  emxInit_real_T(&VVwindow, 2);
  emxInit_real_T(&AZAZwindow, 2);
  emxInit_creal_T(&UVwindow, 2);
  emxInit_creal_T(&UAZwindow, 2);
  emxInit_creal_T(&VAZwindow, 2);
  emxInit_real_T(&UU, 2);
  emxInit_real_T(&VV, 2);
  emxInit_creal_T(&UV, 2);
  emxInit_creal_T(&UAZ, 2);
  emxInit_creal_T(&VAZ, 2);
  emxInit_real_T(&Eyy, 2);
  emxInit_real_T(&Ezz, 2);
  emxInit_real_T(&dir1, 2);
  emxInit_int32_T(&r4, 1);
  emxInit_creal_T(&r5, 2);
  emxInit_real_T1(&a, 1);
  emxInit_creal_T(&A, 2);
  emxInit_real_T(&r6, 2);
  emxInit_boolean_T(&b_f, 2);
  emxInit_boolean_T(&c_f, 2);
  emxInit_boolean_T(&d_f, 2);
  emxInit_boolean_T(&e_f, 2);
  emxInit_boolean_T(&f_f, 2);
  emxInit_real_T(&r7, 2);
  emxInit_boolean_T(&g_f, 2);
  emxInit_boolean_T(&h_f, 2);
  emxInit_boolean_T(&i_f, 2);
  emxInit_real_T(&b_E, 2);
  emxInit_real_T(&b_Eyy, 2);
  emxInit_real_T(&r8, 2);
  emxInit_real_T(&r9, 2);
  emxInit_real_T(&c_E, 2);
  emxInit_real_T(&d_E, 2);
  emxInit_real_T(&e_E, 2);
  emxInit_real_T(&b_UV, 2);
  emxInit_real_T(&r10, 2);
  emxInit_real_T(&b_VAZ, 2);
  emxInit_real_T(&r11, 2);
  emxInit_real_T(&b_UAZ, 2);
  emxInit_real_T(&r12, 2);
  emxInit_real_T(&r13, 2);
  emxInit_real_T(&r14, 2);
  emxInit_real_T(&r15, 2);
  emxInit_creal_T(&b_AZwindow, 2);
  emxInit_creal_T(&b_Vwindow, 2);
  emxInit_creal_T(&b_Uwindow, 2);
  emxInit_real_T(&b_azwindow, 2);
  emxInit_real_T(&b_vwindow, 2);
  emxInit_real_T(&b_uwindow, 2);
  emxInit_real_T(&w, 2);
  emxInit_real_T(&b_w, 2);
  emxInit_real_T(&c_w, 2);
  emxInit_real_T(&r16, 2);
  emxInit_real_T(&r17, 2);
  emxInit_real_T(&r18, 2);
  emxInit_real_T(&b_ufiltered, 2);
  emxInit_creal_T(&b_VAZwindow, 2);
  emxInit_creal_T(&b_UAZwindow, 2);
  emxInit_creal_T(&b_UVwindow, 2);
  emxInit_real_T(&b_AZAZwindow, 2);
  emxInit_real_T(&b_VVwindow, 2);
  emxInit_real_T(&b_UUwindow, 2);
  emxInit_real_T(&r19, 2);
  emxInit_real_T(&r20, 2);
  emxInit_real_T(&r21, 2);
  emxInit_real_T1(&b_dir1, 1);
  emxInit_real_T1(&c_dir1, 1);
  emxInit_real_T1(&d_dir1, 1);
  emxInit_real_T(&r22, 2);
  emxInit_real_T(&e_dir1, 2);
  emxInit_real_T(&j_f, 2);
  emxInit_real_T(&b_vfiltered, 2);
  if ((u->size[1] >= 512) && (fs > 1.0) && (sum(badu) < 100.0) && (sum(badv) <
       100.0)) {
    /*  minimum length and quality for processing */
    /* % high-pass RC filter, detrend first */
    detrend(u);
    detrend(v);
    detrend(az);

    /*  initialize */
    i0 = ufiltered->size[0] * ufiltered->size[1];
    ufiltered->size[0] = 1;
    ufiltered->size[1] = u->size[1];
    emxEnsureCapacity((emxArray__common *)ufiltered, i0, (int)sizeof(double));
    loop_ub = u->size[0] * u->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      ufiltered->data[i0] = u->data[i0];
    }

    i0 = vfiltered->size[0] * vfiltered->size[1];
    vfiltered->size[0] = 1;
    vfiltered->size[1] = v->size[1];
    emxEnsureCapacity((emxArray__common *)vfiltered, i0, (int)sizeof(double));
    loop_ub = v->size[0] * v->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      vfiltered->data[i0] = v->data[i0];
    }

    i0 = azfiltered->size[0] * azfiltered->size[1];
    azfiltered->size[0] = 1;
    azfiltered->size[1] = az->size[1];
    emxEnsureCapacity((emxArray__common *)azfiltered, i0, (int)sizeof(double));
    loop_ub = az->size[0] * az->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      azfiltered->data[i0] = az->data[i0];
    }

    alpha = 3.5 / (3.5 + rdivide(1.0, fs));
    for (ui = 0; ui < (int)((double)u->size[1] + -1.0); ui++) {
      ufiltered->data[ui + 1] = alpha * ufiltered->data[(int)((2.0 + (double)ui)
        - 1.0) - 1] + alpha * (u->data[ui + 1] - u->data[(int)((2.0 + (double)ui)
        - 1.0) - 1]);
      vfiltered->data[ui + 1] = alpha * vfiltered->data[(int)((2.0 + (double)ui)
        - 1.0) - 1] + alpha * (v->data[ui + 1] - v->data[(int)((2.0 + (double)ui)
        - 1.0) - 1]);
      azfiltered->data[ui + 1] = alpha * azfiltered->data[(int)((2.0 + (double)
        ui) - 1.0) - 1] + alpha * (az->data[ui + 1] - az->data[(int)((2.0 +
        (double)ui) - 1.0) - 1]);
    }

    /* % break into windows (use 75 percent overlap) */
    d_w = rt_roundd_snf(fs * 256.0);

    /*  window length in data points */
    if (rt_remd_snf(d_w, 2.0) != 0.0) {
      d_w--;
    }

    /*  make w an even number */
    windows = (int)floor(4.0 * ((double)pts / d_w - 1.0) + 1.0);

    /*  number of windows, the 4 comes from a 75% overlap */
    /*  degrees of freedom */
    /*  loop to create a matrix of time series, where COLUMN = WINDOW  */
    i0 = uwindow->size[0] * uwindow->size[1];
    uwindow->size[0] = (int)d_w;
    uwindow->size[1] = windows;
    emxEnsureCapacity((emxArray__common *)uwindow, i0, (int)sizeof(double));
    loop_ub = (int)d_w * windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      uwindow->data[i0] = 0.0;
    }

    i0 = vwindow->size[0] * vwindow->size[1];
    vwindow->size[0] = (int)d_w;
    vwindow->size[1] = windows;
    emxEnsureCapacity((emxArray__common *)vwindow, i0, (int)sizeof(double));
    loop_ub = (int)d_w * windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      vwindow->data[i0] = 0.0;
    }

    i0 = azwindow->size[0] * azwindow->size[1];
    azwindow->size[0] = (int)d_w;
    azwindow->size[1] = windows;
    emxEnsureCapacity((emxArray__common *)azwindow, i0, (int)sizeof(double));
    loop_ub = (int)d_w * windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      azwindow->data[i0] = 0.0;
    }

    for (q = 0; q < windows; q++) {
      loop_ub = uwindow->size[0];
      i0 = r4->size[0];
      r4->size[0] = loop_ub;
      emxEnsureCapacity((emxArray__common *)r4, i0, (int)sizeof(int));
      for (i0 = 0; i0 < loop_ub; i0++) {
        r4->data[i0] = i0;
      }

      anew = ((1.0 + (double)q) - 1.0) * (0.25 * d_w);
      i0 = r0->size[0] * r0->size[1];
      r0->size[0] = 1;
      r0->size[1] = (int)floor(d_w - 1.0) + 1;
      emxEnsureCapacity((emxArray__common *)r0, i0, (int)sizeof(double));
      loop_ub = (int)floor(d_w - 1.0);
      for (i0 = 0; i0 <= loop_ub; i0++) {
        r0->data[r0->size[0] * i0] = ufiltered->data[(int)(anew + (double)(i0 +
          1)) - 1];
      }

      nm1d2 = r4->size[0];
      for (i0 = 0; i0 < nm1d2; i0++) {
        uwindow->data[r4->data[i0] + uwindow->size[0] * q] = r0->data[i0];
      }

      loop_ub = vwindow->size[0];
      i0 = r4->size[0];
      r4->size[0] = loop_ub;
      emxEnsureCapacity((emxArray__common *)r4, i0, (int)sizeof(int));
      for (i0 = 0; i0 < loop_ub; i0++) {
        r4->data[i0] = i0;
      }

      anew = ((1.0 + (double)q) - 1.0) * (0.25 * d_w);
      i0 = r0->size[0] * r0->size[1];
      r0->size[0] = 1;
      r0->size[1] = (int)floor(d_w - 1.0) + 1;
      emxEnsureCapacity((emxArray__common *)r0, i0, (int)sizeof(double));
      loop_ub = (int)floor(d_w - 1.0);
      for (i0 = 0; i0 <= loop_ub; i0++) {
        r0->data[r0->size[0] * i0] = vfiltered->data[(int)(anew + (double)(i0 +
          1)) - 1];
      }

      nm1d2 = r4->size[0];
      for (i0 = 0; i0 < nm1d2; i0++) {
        vwindow->data[r4->data[i0] + vwindow->size[0] * q] = r0->data[i0];
      }

      loop_ub = azwindow->size[0];
      i0 = r4->size[0];
      r4->size[0] = loop_ub;
      emxEnsureCapacity((emxArray__common *)r4, i0, (int)sizeof(int));
      for (i0 = 0; i0 < loop_ub; i0++) {
        r4->data[i0] = i0;
      }

      anew = ((1.0 + (double)q) - 1.0) * (0.25 * d_w);
      i0 = r0->size[0] * r0->size[1];
      r0->size[0] = 1;
      r0->size[1] = (int)floor(d_w - 1.0) + 1;
      emxEnsureCapacity((emxArray__common *)r0, i0, (int)sizeof(double));
      loop_ub = (int)floor(d_w - 1.0);
      for (i0 = 0; i0 <= loop_ub; i0++) {
        r0->data[r0->size[0] * i0] = azfiltered->data[(int)(anew + (double)(i0 +
          1)) - 1];
      }

      nm1d2 = r4->size[0];
      for (i0 = 0; i0 < nm1d2; i0++) {
        azwindow->data[r4->data[i0] + azwindow->size[0] * q] = r0->data[i0];
      }
    }

    /* % detrend individual windows (full series already detrended) */
    for (q = 0; q < windows; q++) {
      loop_ub = uwindow->size[0];
      i0 = a->size[0];
      a->size[0] = loop_ub;
      emxEnsureCapacity((emxArray__common *)a, i0, (int)sizeof(double));
      for (i0 = 0; i0 < loop_ub; i0++) {
        a->data[i0] = uwindow->data[i0 + uwindow->size[0] * q];
      }

      b_detrend(a);
      loop_ub = a->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        uwindow->data[i0 + uwindow->size[0] * q] = a->data[i0];
      }

      loop_ub = vwindow->size[0];
      i0 = a->size[0];
      a->size[0] = loop_ub;
      emxEnsureCapacity((emxArray__common *)a, i0, (int)sizeof(double));
      for (i0 = 0; i0 < loop_ub; i0++) {
        a->data[i0] = vwindow->data[i0 + vwindow->size[0] * q];
      }

      b_detrend(a);
      loop_ub = a->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        vwindow->data[i0 + vwindow->size[0] * q] = a->data[i0];
      }

      loop_ub = azwindow->size[0];
      i0 = a->size[0];
      a->size[0] = loop_ub;
      emxEnsureCapacity((emxArray__common *)a, i0, (int)sizeof(double));
      for (i0 = 0; i0 < loop_ub; i0++) {
        a->data[i0] = azwindow->data[i0 + azwindow->size[0] * q];
      }

      b_detrend(a);
      loop_ub = a->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        azwindow->data[i0 + azwindow->size[0] * q] = a->data[i0];
      }
    }

    /* % taper and rescale (to preserve variance) */
    /*  form taper matrix (columns of taper coef) */
    if (rtIsInf(d_w)) {
      n = 0;
      anew = rtNaN;
      apnd = d_w;
    } else {
      anew = 1.0;
      ndbl = floor((d_w - 1.0) + 0.5);
      apnd = 1.0 + ndbl;
      cdiff = (1.0 + ndbl) - d_w;
      if (fabs(cdiff) < 4.4408920985006262E-16 * d_w) {
        ndbl++;
        apnd = d_w;
      } else if (cdiff > 0.0) {
        apnd = 1.0 + (ndbl - 1.0);
      } else {
        ndbl++;
      }

      n = (int)ndbl - 1;
    }

    i0 = ufiltered->size[0] * ufiltered->size[1];
    ufiltered->size[0] = 1;
    ufiltered->size[1] = n + 1;
    emxEnsureCapacity((emxArray__common *)ufiltered, i0, (int)sizeof(double));
    ufiltered->data[0] = anew;
    if (n + 1 > 1) {
      ufiltered->data[n] = apnd;
      nm1d2 = (n + (n < 0)) >> 1;
      for (k = 1; k < nm1d2; k++) {
        ufiltered->data[k] = anew + (double)k;
        ufiltered->data[n - k] = apnd - (double)k;
      }

      if (nm1d2 << 1 == n) {
        ufiltered->data[nm1d2] = (anew + apnd) / 2.0;
      } else {
        ufiltered->data[nm1d2] = anew + (double)nm1d2;
        ufiltered->data[nm1d2 + 1] = apnd - (double)nm1d2;
      }
    }

    i0 = b_ufiltered->size[0] * b_ufiltered->size[1];
    b_ufiltered->size[0] = 1;
    b_ufiltered->size[1] = ufiltered->size[1];
    emxEnsureCapacity((emxArray__common *)b_ufiltered, i0, (int)sizeof(double));
    loop_ub = ufiltered->size[0] * ufiltered->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_ufiltered->data[i0] = ufiltered->data[i0] * 3.1415926535897931;
    }

    c_rdivide(b_ufiltered, d_w, r0);
    b_sin(r0);
    i0 = a->size[0];
    a->size[0] = r0->size[1];
    emxEnsureCapacity((emxArray__common *)a, i0, (int)sizeof(double));
    loop_ub = r0->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      a->data[i0] = r0->data[r0->size[0] * i0];
    }

    i0 = taper->size[0] * taper->size[1];
    taper->size[0] = a->size[0];
    taper->size[1] = windows;
    emxEnsureCapacity((emxArray__common *)taper, i0, (int)sizeof(double));
    loop_ub = a->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      for (i1 = 0; i1 < windows; i1++) {
        taper->data[i0 + taper->size[0] * i1] = a->data[i0];
      }
    }

    /*  taper each window */
    i0 = uwindowtaper->size[0] * uwindowtaper->size[1];
    uwindowtaper->size[0] = uwindow->size[0];
    uwindowtaper->size[1] = uwindow->size[1];
    emxEnsureCapacity((emxArray__common *)uwindowtaper, i0, (int)sizeof(double));
    loop_ub = uwindow->size[0] * uwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      uwindowtaper->data[i0] = uwindow->data[i0] * taper->data[i0];
    }

    i0 = vwindowtaper->size[0] * vwindowtaper->size[1];
    vwindowtaper->size[0] = vwindow->size[0];
    vwindowtaper->size[1] = vwindow->size[1];
    emxEnsureCapacity((emxArray__common *)vwindowtaper, i0, (int)sizeof(double));
    loop_ub = vwindow->size[0] * vwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      vwindowtaper->data[i0] = vwindow->data[i0] * taper->data[i0];
    }

    i0 = taper->size[0] * taper->size[1];
    taper->size[0] = azwindow->size[0];
    taper->size[1] = azwindow->size[1];
    emxEnsureCapacity((emxArray__common *)taper, i0, (int)sizeof(double));
    loop_ub = azwindow->size[0] * azwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      taper->data[i0] *= azwindow->data[i0];
    }

    /*  now find the correction factor (comparing old/new variance) */
    b_var(uwindow, factaz);
    b_var(uwindowtaper, r6);
    b_rdivide(factaz, r6, r0);
    c_sqrt(r0);
    i0 = factu->size[0] * factu->size[1];
    factu->size[0] = 1;
    factu->size[1] = r0->size[1];
    emxEnsureCapacity((emxArray__common *)factu, i0, (int)sizeof(double));
    loop_ub = r0->size[0] * r0->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      factu->data[i0] = r0->data[i0];
    }

    b_var(vwindow, factaz);
    b_var(vwindowtaper, r6);
    b_rdivide(factaz, r6, r0);
    c_sqrt(r0);
    i0 = factv->size[0] * factv->size[1];
    factv->size[0] = 1;
    factv->size[1] = r0->size[1];
    emxEnsureCapacity((emxArray__common *)factv, i0, (int)sizeof(double));
    loop_ub = r0->size[0] * r0->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      factv->data[i0] = r0->data[i0];
    }

    b_var(azwindow, factaz);
    b_var(taper, r6);
    b_rdivide(factaz, r6, r0);
    c_sqrt(r0);
    i0 = factaz->size[0] * factaz->size[1];
    factaz->size[0] = 1;
    factaz->size[1] = r0->size[1];
    emxEnsureCapacity((emxArray__common *)factaz, i0, (int)sizeof(double));
    loop_ub = r0->size[0] * r0->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      factaz->data[i0] = r0->data[i0];
    }

    /*  and correct for the change in variance */
    /*  (mult each window by it's variance ratio factor) */
    /* % FFT */
    /*  calculate Fourier coefs */
    i0 = r19->size[0] * r19->size[1];
    r19->size[0] = (int)d_w;
    r19->size[1] = factu->size[1];
    emxEnsureCapacity((emxArray__common *)r19, i0, (int)sizeof(double));
    loop_ub = (int)d_w;
    for (i0 = 0; i0 < loop_ub; i0++) {
      itmp = factu->size[1];
      for (i1 = 0; i1 < itmp; i1++) {
        r19->data[i0 + r19->size[0] * i1] = factu->data[factu->size[0] * i1];
      }
    }

    i0 = r18->size[0] * r18->size[1];
    r18->size[0] = r19->size[0];
    r18->size[1] = r19->size[1];
    emxEnsureCapacity((emxArray__common *)r18, i0, (int)sizeof(double));
    loop_ub = r19->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      itmp = r19->size[0];
      for (i1 = 0; i1 < itmp; i1++) {
        r18->data[i1 + r18->size[0] * i0] = r19->data[i1 + r19->size[0] * i0] *
          uwindowtaper->data[i1 + uwindowtaper->size[0] * i0];
      }
    }

    fft(r18, Uwindow);
    i0 = r20->size[0] * r20->size[1];
    r20->size[0] = (int)d_w;
    r20->size[1] = factv->size[1];
    emxEnsureCapacity((emxArray__common *)r20, i0, (int)sizeof(double));
    loop_ub = (int)d_w;
    for (i0 = 0; i0 < loop_ub; i0++) {
      itmp = factv->size[1];
      for (i1 = 0; i1 < itmp; i1++) {
        r20->data[i0 + r20->size[0] * i1] = factv->data[factv->size[0] * i1];
      }
    }

    i0 = r17->size[0] * r17->size[1];
    r17->size[0] = r20->size[0];
    r17->size[1] = r20->size[1];
    emxEnsureCapacity((emxArray__common *)r17, i0, (int)sizeof(double));
    loop_ub = r20->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      itmp = r20->size[0];
      for (i1 = 0; i1 < itmp; i1++) {
        r17->data[i1 + r17->size[0] * i0] = r20->data[i1 + r20->size[0] * i0] *
          vwindowtaper->data[i1 + vwindowtaper->size[0] * i0];
      }
    }

    fft(r17, Vwindow);
    i0 = r21->size[0] * r21->size[1];
    r21->size[0] = (int)d_w;
    r21->size[1] = factaz->size[1];
    emxEnsureCapacity((emxArray__common *)r21, i0, (int)sizeof(double));
    loop_ub = (int)d_w;
    for (i0 = 0; i0 < loop_ub; i0++) {
      itmp = factaz->size[1];
      for (i1 = 0; i1 < itmp; i1++) {
        r21->data[i0 + r21->size[0] * i1] = factaz->data[factaz->size[0] * i1];
      }
    }

    i0 = r16->size[0] * r16->size[1];
    r16->size[0] = r21->size[0];
    r16->size[1] = r21->size[1];
    emxEnsureCapacity((emxArray__common *)r16, i0, (int)sizeof(double));
    loop_ub = r21->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      itmp = r21->size[0];
      for (i1 = 0; i1 < itmp; i1++) {
        r16->data[i1 + r16->size[0] * i0] = r21->data[i1 + r21->size[0] * i0] *
          taper->data[i1 + taper->size[0] * i0];
      }
    }

    fft(r16, AZwindow);

    /*  second half of fft is redundant, so throw it out */
    anew = d_w / 2.0 + 1.0;
    i0 = c_w->size[0] * c_w->size[1];
    c_w->size[0] = 1;
    c_w->size[1] = (int)floor(d_w - anew) + 1;
    emxEnsureCapacity((emxArray__common *)c_w, i0, (int)sizeof(double));
    loop_ub = (int)floor(d_w - anew);
    for (i0 = 0; i0 <= loop_ub; i0++) {
      c_w->data[c_w->size[0] * i0] = anew + (double)i0;
    }

    b_eml_null_assignment(Uwindow, c_w);
    anew = d_w / 2.0 + 1.0;
    i0 = b_w->size[0] * b_w->size[1];
    b_w->size[0] = 1;
    b_w->size[1] = (int)floor(d_w - anew) + 1;
    emxEnsureCapacity((emxArray__common *)b_w, i0, (int)sizeof(double));
    loop_ub = (int)floor(d_w - anew);
    for (i0 = 0; i0 <= loop_ub; i0++) {
      b_w->data[b_w->size[0] * i0] = anew + (double)i0;
    }

    b_eml_null_assignment(Vwindow, b_w);
    anew = d_w / 2.0 + 1.0;
    i0 = w->size[0] * w->size[1];
    w->size[0] = 1;
    w->size[1] = (int)floor(d_w - anew) + 1;
    emxEnsureCapacity((emxArray__common *)w, i0, (int)sizeof(double));
    loop_ub = (int)floor(d_w - anew);
    for (i0 = 0; i0 <= loop_ub; i0++) {
      w->data[w->size[0] * i0] = anew + (double)i0;
    }

    b_eml_null_assignment(AZwindow, w);

    /*  throw out the mean (first coef) and add a zero (to make it the right length)   */
    c_eml_null_assignment(Uwindow);
    c_eml_null_assignment(Vwindow);
    c_eml_null_assignment(AZwindow);
    loop_ub = Uwindow->size[1];
    nm1d2 = (int)(d_w / 2.0);
    for (i0 = 0; i0 < loop_ub; i0++) {
      Uwindow->data[(nm1d2 + Uwindow->size[0] * i0) - 1].re = 0.0;
      Uwindow->data[(nm1d2 + Uwindow->size[0] * i0) - 1].im = 0.0;
    }

    loop_ub = Vwindow->size[1];
    nm1d2 = (int)(d_w / 2.0);
    for (i0 = 0; i0 < loop_ub; i0++) {
      Vwindow->data[(nm1d2 + Vwindow->size[0] * i0) - 1].re = 0.0;
      Vwindow->data[(nm1d2 + Vwindow->size[0] * i0) - 1].im = 0.0;
    }

    loop_ub = AZwindow->size[1];
    nm1d2 = (int)(d_w / 2.0);
    for (i0 = 0; i0 < loop_ub; i0++) {
      AZwindow->data[(nm1d2 + AZwindow->size[0] * i0) - 1].re = 0.0;
      AZwindow->data[(nm1d2 + AZwindow->size[0] * i0) - 1].im = 0.0;
    }

    /*  POWER SPECTRA (auto-spectra) */
    i0 = UUwindow->size[0] * UUwindow->size[1];
    UUwindow->size[0] = Uwindow->size[0];
    UUwindow->size[1] = Uwindow->size[1];
    emxEnsureCapacity((emxArray__common *)UUwindow, i0, (int)sizeof(double));
    loop_ub = Uwindow->size[0] * Uwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      y = Uwindow->data[i0].re;
      Uwindow_im = -Uwindow->data[i0].im;
      y = Uwindow->data[i0].re * y - Uwindow->data[i0].im * Uwindow_im;
      UUwindow->data[i0] = y;
    }

    i0 = VVwindow->size[0] * VVwindow->size[1];
    VVwindow->size[0] = Vwindow->size[0];
    VVwindow->size[1] = Vwindow->size[1];
    emxEnsureCapacity((emxArray__common *)VVwindow, i0, (int)sizeof(double));
    loop_ub = Vwindow->size[0] * Vwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      apnd = Vwindow->data[i0].re;
      cdiff = -Vwindow->data[i0].im;
      apnd = Vwindow->data[i0].re * apnd - Vwindow->data[i0].im * cdiff;
      VVwindow->data[i0] = apnd;
    }

    i0 = AZAZwindow->size[0] * AZAZwindow->size[1];
    AZAZwindow->size[0] = AZwindow->size[0];
    AZAZwindow->size[1] = AZwindow->size[1];
    emxEnsureCapacity((emxArray__common *)AZAZwindow, i0, (int)sizeof(double));
    loop_ub = AZwindow->size[0] * AZwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      anew = AZwindow->data[i0].re;
      ndbl = -AZwindow->data[i0].im;
      anew = AZwindow->data[i0].re * anew - AZwindow->data[i0].im * ndbl;
      AZAZwindow->data[i0] = anew;
    }

    /*  CROSS-SPECTRA  */
    i0 = UVwindow->size[0] * UVwindow->size[1];
    UVwindow->size[0] = Uwindow->size[0];
    UVwindow->size[1] = Uwindow->size[1];
    emxEnsureCapacity((emxArray__common *)UVwindow, i0, (int)sizeof(creal_T));
    loop_ub = Uwindow->size[0] * Uwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      apnd = Vwindow->data[i0].re;
      cdiff = -Vwindow->data[i0].im;
      y = Uwindow->data[i0].re;
      Uwindow_im = Uwindow->data[i0].im;
      UVwindow->data[i0].re = y * apnd - Uwindow_im * cdiff;
      UVwindow->data[i0].im = y * cdiff + Uwindow_im * apnd;
    }

    i0 = UAZwindow->size[0] * UAZwindow->size[1];
    UAZwindow->size[0] = Uwindow->size[0];
    UAZwindow->size[1] = Uwindow->size[1];
    emxEnsureCapacity((emxArray__common *)UAZwindow, i0, (int)sizeof(creal_T));
    loop_ub = Uwindow->size[0] * Uwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      anew = AZwindow->data[i0].re;
      ndbl = -AZwindow->data[i0].im;
      y = Uwindow->data[i0].re;
      Uwindow_im = Uwindow->data[i0].im;
      UAZwindow->data[i0].re = y * anew - Uwindow_im * ndbl;
      UAZwindow->data[i0].im = y * ndbl + Uwindow_im * anew;
    }

    i0 = VAZwindow->size[0] * VAZwindow->size[1];
    VAZwindow->size[0] = Vwindow->size[0];
    VAZwindow->size[1] = Vwindow->size[1];
    emxEnsureCapacity((emxArray__common *)VAZwindow, i0, (int)sizeof(creal_T));
    loop_ub = Vwindow->size[0] * Vwindow->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      anew = AZwindow->data[i0].re;
      ndbl = -AZwindow->data[i0].im;
      apnd = Vwindow->data[i0].re;
      cdiff = Vwindow->data[i0].im;
      VAZwindow->data[i0].re = apnd * anew - cdiff * ndbl;
      VAZwindow->data[i0].im = apnd * ndbl + cdiff * anew;
    }

    /* % merge neighboring freq bands (number of bands to merge is a fixed parameter) */
    /*  initialize */
    anew = floor(d_w / 6.0);
    i0 = uwindow->size[0] * uwindow->size[1];
    uwindow->size[0] = (int)anew;
    uwindow->size[1] = windows;
    emxEnsureCapacity((emxArray__common *)uwindow, i0, (int)sizeof(double));
    loop_ub = (int)anew * windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      uwindow->data[i0] = 0.0;
    }

    anew = floor(d_w / 6.0);
    i0 = vwindow->size[0] * vwindow->size[1];
    vwindow->size[0] = (int)anew;
    vwindow->size[1] = windows;
    emxEnsureCapacity((emxArray__common *)vwindow, i0, (int)sizeof(double));
    loop_ub = (int)anew * windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      vwindow->data[i0] = 0.0;
    }

    anew = floor(d_w / 6.0);
    i0 = azwindow->size[0] * azwindow->size[1];
    azwindow->size[0] = (int)anew;
    azwindow->size[1] = windows;
    emxEnsureCapacity((emxArray__common *)azwindow, i0, (int)sizeof(double));
    loop_ub = (int)anew * windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      azwindow->data[i0] = 0.0;
    }

    anew = floor(d_w / 6.0);
    i0 = Uwindow->size[0] * Uwindow->size[1];
    Uwindow->size[0] = (int)anew;
    Uwindow->size[1] = windows;
    emxEnsureCapacity((emxArray__common *)Uwindow, i0, (int)sizeof(creal_T));
    loop_ub = (int)anew * windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      Uwindow->data[i0].re = 0.0;
      Uwindow->data[i0].im = 1.0;
    }

    anew = floor(d_w / 6.0);
    i0 = Vwindow->size[0] * Vwindow->size[1];
    Vwindow->size[0] = (int)anew;
    Vwindow->size[1] = windows;
    emxEnsureCapacity((emxArray__common *)Vwindow, i0, (int)sizeof(creal_T));
    loop_ub = (int)anew * windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      Vwindow->data[i0].re = 0.0;
      Vwindow->data[i0].im = 1.0;
    }

    anew = floor(d_w / 6.0);
    i0 = AZwindow->size[0] * AZwindow->size[1];
    AZwindow->size[0] = (int)anew;
    AZwindow->size[1] = windows;
    emxEnsureCapacity((emxArray__common *)AZwindow, i0, (int)sizeof(creal_T));
    loop_ub = (int)anew * windows;
    for (i0 = 0; i0 < loop_ub; i0++) {
      AZwindow->data[i0].re = 0.0;
      AZwindow->data[i0].im = 1.0;
    }

    i0 = (int)(d_w / 2.0 / 3.0);
    for (mi = 0; mi < i0; mi++) {
      b_mi = 3.0 + (double)mi * 3.0;
      if ((b_mi - 3.0) + 1.0 > b_mi) {
        i1 = 0;
        nm1d2 = 0;
      } else {
        i1 = (int)((b_mi - 3.0) + 1.0) - 1;
        nm1d2 = (int)b_mi;
      }

      loop_ub = UUwindow->size[1];
      k = b_UUwindow->size[0] * b_UUwindow->size[1];
      b_UUwindow->size[0] = nm1d2 - i1;
      b_UUwindow->size[1] = loop_ub;
      emxEnsureCapacity((emxArray__common *)b_UUwindow, k, (int)sizeof(double));
      for (k = 0; k < loop_ub; k++) {
        itmp = nm1d2 - i1;
        for (n = 0; n < itmp; n++) {
          b_UUwindow->data[n + b_UUwindow->size[0] * k] = UUwindow->data[(i1 + n)
            + UUwindow->size[0] * k];
        }
      }

      b_mean(b_UUwindow, r0);
      i1 = factaz->size[0] * factaz->size[1];
      factaz->size[0] = 1;
      factaz->size[1] = r0->size[1];
      emxEnsureCapacity((emxArray__common *)factaz, i1, (int)sizeof(double));
      loop_ub = r0->size[0] * r0->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        factaz->data[i1] = r0->data[i1];
      }

      nm1d2 = (int)(b_mi / 3.0);
      loop_ub = factaz->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        uwindow->data[(nm1d2 + uwindow->size[0] * i1) - 1] = factaz->data
          [factaz->size[0] * i1];
      }

      if ((b_mi - 3.0) + 1.0 > b_mi) {
        i1 = 0;
        nm1d2 = 0;
      } else {
        i1 = (int)((b_mi - 3.0) + 1.0) - 1;
        nm1d2 = (int)b_mi;
      }

      loop_ub = VVwindow->size[1];
      k = b_VVwindow->size[0] * b_VVwindow->size[1];
      b_VVwindow->size[0] = nm1d2 - i1;
      b_VVwindow->size[1] = loop_ub;
      emxEnsureCapacity((emxArray__common *)b_VVwindow, k, (int)sizeof(double));
      for (k = 0; k < loop_ub; k++) {
        itmp = nm1d2 - i1;
        for (n = 0; n < itmp; n++) {
          b_VVwindow->data[n + b_VVwindow->size[0] * k] = VVwindow->data[(i1 + n)
            + VVwindow->size[0] * k];
        }
      }

      b_mean(b_VVwindow, r0);
      i1 = factaz->size[0] * factaz->size[1];
      factaz->size[0] = 1;
      factaz->size[1] = r0->size[1];
      emxEnsureCapacity((emxArray__common *)factaz, i1, (int)sizeof(double));
      loop_ub = r0->size[0] * r0->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        factaz->data[i1] = r0->data[i1];
      }

      nm1d2 = (int)(b_mi / 3.0);
      loop_ub = factaz->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        vwindow->data[(nm1d2 + vwindow->size[0] * i1) - 1] = factaz->data
          [factaz->size[0] * i1];
      }

      if ((b_mi - 3.0) + 1.0 > b_mi) {
        i1 = 0;
        nm1d2 = 0;
      } else {
        i1 = (int)((b_mi - 3.0) + 1.0) - 1;
        nm1d2 = (int)b_mi;
      }

      loop_ub = AZAZwindow->size[1];
      k = b_AZAZwindow->size[0] * b_AZAZwindow->size[1];
      b_AZAZwindow->size[0] = nm1d2 - i1;
      b_AZAZwindow->size[1] = loop_ub;
      emxEnsureCapacity((emxArray__common *)b_AZAZwindow, k, (int)sizeof(double));
      for (k = 0; k < loop_ub; k++) {
        itmp = nm1d2 - i1;
        for (n = 0; n < itmp; n++) {
          b_AZAZwindow->data[n + b_AZAZwindow->size[0] * k] = AZAZwindow->data
            [(i1 + n) + AZAZwindow->size[0] * k];
        }
      }

      b_mean(b_AZAZwindow, r0);
      i1 = factaz->size[0] * factaz->size[1];
      factaz->size[0] = 1;
      factaz->size[1] = r0->size[1];
      emxEnsureCapacity((emxArray__common *)factaz, i1, (int)sizeof(double));
      loop_ub = r0->size[0] * r0->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        factaz->data[i1] = r0->data[i1];
      }

      nm1d2 = (int)(b_mi / 3.0);
      loop_ub = factaz->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        azwindow->data[(nm1d2 + azwindow->size[0] * i1) - 1] = factaz->
          data[factaz->size[0] * i1];
      }

      if ((b_mi - 3.0) + 1.0 > b_mi) {
        i1 = 0;
        nm1d2 = 0;
      } else {
        i1 = (int)((b_mi - 3.0) + 1.0) - 1;
        nm1d2 = (int)b_mi;
      }

      loop_ub = UVwindow->size[1];
      k = b_UVwindow->size[0] * b_UVwindow->size[1];
      b_UVwindow->size[0] = nm1d2 - i1;
      b_UVwindow->size[1] = loop_ub;
      emxEnsureCapacity((emxArray__common *)b_UVwindow, k, (int)sizeof(creal_T));
      for (k = 0; k < loop_ub; k++) {
        itmp = nm1d2 - i1;
        for (n = 0; n < itmp; n++) {
          b_UVwindow->data[n + b_UVwindow->size[0] * k] = UVwindow->data[(i1 + n)
            + UVwindow->size[0] * k];
        }
      }

      c_mean(b_UVwindow, A);
      i1 = r5->size[0] * r5->size[1];
      r5->size[0] = 1;
      r5->size[1] = A->size[1];
      emxEnsureCapacity((emxArray__common *)r5, i1, (int)sizeof(creal_T));
      loop_ub = A->size[0] * A->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        r5->data[i1] = A->data[i1];
      }

      nm1d2 = (int)(b_mi / 3.0);
      loop_ub = r5->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        Uwindow->data[(nm1d2 + Uwindow->size[0] * i1) - 1] = r5->data[r5->size[0]
          * i1];
      }

      if ((b_mi - 3.0) + 1.0 > b_mi) {
        i1 = 0;
        nm1d2 = 0;
      } else {
        i1 = (int)((b_mi - 3.0) + 1.0) - 1;
        nm1d2 = (int)b_mi;
      }

      loop_ub = UAZwindow->size[1];
      k = b_UAZwindow->size[0] * b_UAZwindow->size[1];
      b_UAZwindow->size[0] = nm1d2 - i1;
      b_UAZwindow->size[1] = loop_ub;
      emxEnsureCapacity((emxArray__common *)b_UAZwindow, k, (int)sizeof(creal_T));
      for (k = 0; k < loop_ub; k++) {
        itmp = nm1d2 - i1;
        for (n = 0; n < itmp; n++) {
          b_UAZwindow->data[n + b_UAZwindow->size[0] * k] = UAZwindow->data[(i1
            + n) + UAZwindow->size[0] * k];
        }
      }

      c_mean(b_UAZwindow, A);
      i1 = r5->size[0] * r5->size[1];
      r5->size[0] = 1;
      r5->size[1] = A->size[1];
      emxEnsureCapacity((emxArray__common *)r5, i1, (int)sizeof(creal_T));
      loop_ub = A->size[0] * A->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        r5->data[i1] = A->data[i1];
      }

      nm1d2 = (int)(b_mi / 3.0);
      loop_ub = r5->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        Vwindow->data[(nm1d2 + Vwindow->size[0] * i1) - 1] = r5->data[r5->size[0]
          * i1];
      }

      if ((b_mi - 3.0) + 1.0 > b_mi) {
        i1 = 0;
        nm1d2 = 0;
      } else {
        i1 = (int)((b_mi - 3.0) + 1.0) - 1;
        nm1d2 = (int)b_mi;
      }

      loop_ub = VAZwindow->size[1];
      k = b_VAZwindow->size[0] * b_VAZwindow->size[1];
      b_VAZwindow->size[0] = nm1d2 - i1;
      b_VAZwindow->size[1] = loop_ub;
      emxEnsureCapacity((emxArray__common *)b_VAZwindow, k, (int)sizeof(creal_T));
      for (k = 0; k < loop_ub; k++) {
        itmp = nm1d2 - i1;
        for (n = 0; n < itmp; n++) {
          b_VAZwindow->data[n + b_VAZwindow->size[0] * k] = VAZwindow->data[(i1
            + n) + VAZwindow->size[0] * k];
        }
      }

      c_mean(b_VAZwindow, A);
      i1 = r5->size[0] * r5->size[1];
      r5->size[0] = 1;
      r5->size[1] = A->size[1];
      emxEnsureCapacity((emxArray__common *)r5, i1, (int)sizeof(creal_T));
      loop_ub = A->size[0] * A->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        r5->data[i1] = A->data[i1];
      }

      nm1d2 = (int)(b_mi / 3.0);
      loop_ub = r5->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        AZwindow->data[(nm1d2 + AZwindow->size[0] * i1) - 1] = r5->data[r5->
          size[0] * i1];
      }
    }

    /*  freq range and bandwidth */
    b_n = d_w / 2.0 / 3.0;

    /*  number of f bands */
    /*  highest spectral frequency  */
    bandwidth = 0.5 * fs / b_n;

    /*  freq (Hz) bandwitdh */
    /*  find middle of each freq band, ONLY WORKS WHEN MERGING ODD NUMBER OF BANDS! */
    y = bandwidth / 2.0;
    if (rtIsInf(b_n - 1.0)) {
      n = 0;
      anew = rtNaN;
      apnd = b_n - 1.0;
    } else {
      anew = 0.0;
      ndbl = floor((b_n - 1.0) + 0.5);
      apnd = ndbl;
      cdiff = ndbl - (b_n - 1.0);
      if (fabs(cdiff) < 4.4408920985006262E-16 * (b_n - 1.0)) {
        ndbl++;
        apnd = b_n - 1.0;
      } else if (cdiff > 0.0) {
        apnd = ndbl - 1.0;
      } else {
        ndbl++;
      }

      n = (int)ndbl - 1;
    }

    i0 = f->size[0] * f->size[1];
    f->size[0] = 1;
    f->size[1] = n + 1;
    emxEnsureCapacity((emxArray__common *)f, i0, (int)sizeof(double));
    f->data[0] = anew;
    if (n + 1 > 1) {
      f->data[n] = apnd;
      nm1d2 = (n + (n < 0)) >> 1;
      for (k = 1; k < nm1d2; k++) {
        f->data[k] = anew + (double)k;
        f->data[n - k] = apnd - (double)k;
      }

      if (nm1d2 << 1 == n) {
        f->data[nm1d2] = (anew + apnd) / 2.0;
      } else {
        f->data[nm1d2] = anew + (double)nm1d2;
        f->data[nm1d2 + 1] = apnd - (double)nm1d2;
      }
    }

    i0 = f->size[0] * f->size[1];
    f->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)f, i0, (int)sizeof(double));
    nm1d2 = f->size[0];
    k = f->size[1];
    loop_ub = nm1d2 * k;
    for (i0 = 0; i0 < loop_ub; i0++) {
      f->data[i0] = (0.00390625 + y) + bandwidth * f->data[i0];
    }

    /* % ensemble average windows together */
    /*  take the average of all windows at each freq-band */
    /*  and divide by N*samplerate to get power spectral density */
    /*  the two is b/c Matlab's fft output is the symmetric FFT, and we did not use the redundant half (so need to multiply the psd by 2) */
    i0 = b_uwindow->size[0] * b_uwindow->size[1];
    b_uwindow->size[0] = uwindow->size[1];
    b_uwindow->size[1] = uwindow->size[0];
    emxEnsureCapacity((emxArray__common *)b_uwindow, i0, (int)sizeof(double));
    loop_ub = uwindow->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      itmp = uwindow->size[1];
      for (i1 = 0; i1 < itmp; i1++) {
        b_uwindow->data[i1 + b_uwindow->size[0] * i0] = uwindow->data[i0 +
          uwindow->size[0] * i1];
      }
    }

    b_mean(b_uwindow, ufiltered);
    c_rdivide(ufiltered, d_w / 2.0 * fs, UU);
    i0 = b_vwindow->size[0] * b_vwindow->size[1];
    b_vwindow->size[0] = vwindow->size[1];
    b_vwindow->size[1] = vwindow->size[0];
    emxEnsureCapacity((emxArray__common *)b_vwindow, i0, (int)sizeof(double));
    loop_ub = vwindow->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      itmp = vwindow->size[1];
      for (i1 = 0; i1 < itmp; i1++) {
        b_vwindow->data[i1 + b_vwindow->size[0] * i0] = vwindow->data[i0 +
          vwindow->size[0] * i1];
      }
    }

    b_mean(b_vwindow, ufiltered);
    c_rdivide(ufiltered, d_w / 2.0 * fs, VV);
    i0 = b_azwindow->size[0] * b_azwindow->size[1];
    b_azwindow->size[0] = azwindow->size[1];
    b_azwindow->size[1] = azwindow->size[0];
    emxEnsureCapacity((emxArray__common *)b_azwindow, i0, (int)sizeof(double));
    loop_ub = azwindow->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      itmp = azwindow->size[1];
      for (i1 = 0; i1 < itmp; i1++) {
        b_azwindow->data[i1 + b_azwindow->size[0] * i0] = azwindow->data[i0 +
          azwindow->size[0] * i1];
      }
    }

    b_mean(b_azwindow, ufiltered);
    i0 = b_Uwindow->size[0] * b_Uwindow->size[1];
    b_Uwindow->size[0] = Uwindow->size[1];
    b_Uwindow->size[1] = Uwindow->size[0];
    emxEnsureCapacity((emxArray__common *)b_Uwindow, i0, (int)sizeof(creal_T));
    loop_ub = Uwindow->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      itmp = Uwindow->size[1];
      for (i1 = 0; i1 < itmp; i1++) {
        b_Uwindow->data[i1 + b_Uwindow->size[0] * i0] = Uwindow->data[i0 +
          Uwindow->size[0] * i1];
      }
    }

    c_mean(b_Uwindow, A);
    d_rdivide(A, d_w / 2.0 * fs, UV);
    i0 = b_Vwindow->size[0] * b_Vwindow->size[1];
    b_Vwindow->size[0] = Vwindow->size[1];
    b_Vwindow->size[1] = Vwindow->size[0];
    emxEnsureCapacity((emxArray__common *)b_Vwindow, i0, (int)sizeof(creal_T));
    loop_ub = Vwindow->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      itmp = Vwindow->size[1];
      for (i1 = 0; i1 < itmp; i1++) {
        b_Vwindow->data[i1 + b_Vwindow->size[0] * i0] = Vwindow->data[i0 +
          Vwindow->size[0] * i1];
      }
    }

    c_mean(b_Vwindow, A);
    d_rdivide(A, d_w / 2.0 * fs, UAZ);
    i0 = b_AZwindow->size[0] * b_AZwindow->size[1];
    b_AZwindow->size[0] = AZwindow->size[1];
    b_AZwindow->size[1] = AZwindow->size[0];
    emxEnsureCapacity((emxArray__common *)b_AZwindow, i0, (int)sizeof(creal_T));
    loop_ub = AZwindow->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      itmp = AZwindow->size[1];
      for (i1 = 0; i1 < itmp; i1++) {
        b_AZwindow->data[i1 + b_AZwindow->size[0] * i0] = AZwindow->data[i0 +
          AZwindow->size[0] * i1];
      }
    }

    c_mean(b_AZwindow, A);
    d_rdivide(A, d_w / 2.0 * fs, VAZ);

    /* % convert to displacement spectra (from velocity and acceleration) */
    /*  assumes perfectly circular deepwater orbits */
    /*  could be extended to finite depth by calling wavenumber.m  */
    i0 = r15->size[0] * r15->size[1];
    r15->size[0] = 1;
    r15->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)r15, i0, (int)sizeof(double));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r15->data[i0] = 6.2831853071795862 * f->data[i0];
    }

    power(r15, r0);
    b_rdivide(UU, r0, E);

    /* [m^2/Hz] */
    i0 = r14->size[0] * r14->size[1];
    r14->size[0] = 1;
    r14->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)r14, i0, (int)sizeof(double));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r14->data[i0] = 6.2831853071795862 * f->data[i0];
    }

    power(r14, r0);
    b_rdivide(VV, r0, Eyy);

    /* [m^2/Hz] */
    c_rdivide(ufiltered, d_w / 2.0 * fs, r0);
    i0 = r13->size[0] * r13->size[1];
    r13->size[0] = 1;
    r13->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)r13, i0, (int)sizeof(double));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r13->data[i0] = 6.2831853071795862 * f->data[i0];
    }

    b_power(r13, ufiltered);
    b_rdivide(r0, ufiltered, Ezz);
    i0 = Ezz->size[0] * Ezz->size[1];
    Ezz->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)Ezz, i0, (int)sizeof(double));
    nm1d2 = Ezz->size[0];
    k = Ezz->size[1];
    loop_ub = nm1d2 * k;
    for (i0 = 0; i0 < loop_ub; i0++) {
      Ezz->data[i0] *= 96.04000000000002;
    }

    /* [m^2/Hz] */
    /* [m^2/Hz], quadspectrum of vertical acc and horizontal velocities */
    i0 = r12->size[0] * r12->size[1];
    r12->size[0] = 1;
    r12->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)r12, i0, (int)sizeof(double));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r12->data[i0] = 6.2831853071795862 * f->data[i0];
    }

    c_power(r12, r0);
    i0 = b_UAZ->size[0] * b_UAZ->size[1];
    b_UAZ->size[0] = 1;
    b_UAZ->size[1] = UAZ->size[1];
    emxEnsureCapacity((emxArray__common *)b_UAZ, i0, (int)sizeof(double));
    loop_ub = UAZ->size[0] * UAZ->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_UAZ->data[i0] = UAZ->data[i0].re;
    }

    b_rdivide(b_UAZ, r0, ufiltered);
    i0 = ufiltered->size[0] * ufiltered->size[1];
    ufiltered->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)ufiltered, i0, (int)sizeof(double));
    nm1d2 = ufiltered->size[0];
    k = ufiltered->size[1];
    loop_ub = nm1d2 * k;
    for (i0 = 0; i0 < loop_ub; i0++) {
      ufiltered->data[i0] *= 9.8;
    }

    /* [m^2/Hz], cospectrum of vertical acc and horizontal velocities */
    /* [m^2/Hz], quadspectrum of vertical acc and horizontal velocities */
    i0 = r11->size[0] * r11->size[1];
    r11->size[0] = 1;
    r11->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)r11, i0, (int)sizeof(double));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r11->data[i0] = 6.2831853071795862 * f->data[i0];
    }

    c_power(r11, r0);
    i0 = b_VAZ->size[0] * b_VAZ->size[1];
    b_VAZ->size[0] = 1;
    b_VAZ->size[1] = VAZ->size[1];
    emxEnsureCapacity((emxArray__common *)b_VAZ, i0, (int)sizeof(double));
    loop_ub = VAZ->size[0] * VAZ->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_VAZ->data[i0] = VAZ->data[i0].re;
    }

    b_rdivide(b_VAZ, r0, vfiltered);
    i0 = vfiltered->size[0] * vfiltered->size[1];
    vfiltered->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)vfiltered, i0, (int)sizeof(double));
    nm1d2 = vfiltered->size[0];
    k = vfiltered->size[1];
    loop_ub = nm1d2 * k;
    for (i0 = 0; i0 < loop_ub; i0++) {
      vfiltered->data[i0] *= 9.8;
    }

    /* [m^2/Hz], cospectrum of vertical acc and horizontal velocities */
    i0 = r10->size[0] * r10->size[1];
    r10->size[0] = 1;
    r10->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)r10, i0, (int)sizeof(double));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r10->data[i0] = 6.2831853071795862 * f->data[i0];
    }

    power(r10, r0);
    i0 = b_UV->size[0] * b_UV->size[1];
    b_UV->size[0] = 1;
    b_UV->size[1] = UV->size[1];
    emxEnsureCapacity((emxArray__common *)b_UV, i0, (int)sizeof(double));
    loop_ub = UV->size[0] * UV->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_UV->data[i0] = UV->data[i0].re;
    }

    b_rdivide(b_UV, r0, azfiltered);

    /* [m^2/Hz] */
    /* % wave spectral moments  */
    /*  wave directions from Kuik et al, JPO, 1988 and Herbers et al, JTech, 2012 */
    /*  NOTE THAT THIS USES COSPECTRA OF AZ AND U OR V, WHICH DIFFS FROM QUADSPECTRA OF Z AND X OR Y */
    i0 = r0->size[0] * r0->size[1];
    r0->size[0] = 1;
    r0->size[1] = E->size[1];
    emxEnsureCapacity((emxArray__common *)r0, i0, (int)sizeof(double));
    loop_ub = E->size[0] * E->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r0->data[i0] = (E->data[i0] + Eyy->data[i0]) * Ezz->data[i0];
    }

    c_sqrt(r0);
    b_rdivide(ufiltered, r0, a1);

    /* [], would use Qxz for actual displacements */
    i0 = r0->size[0] * r0->size[1];
    r0->size[0] = 1;
    r0->size[1] = E->size[1];
    emxEnsureCapacity((emxArray__common *)r0, i0, (int)sizeof(double));
    loop_ub = E->size[0] * E->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r0->data[i0] = (E->data[i0] + Eyy->data[i0]) * Ezz->data[i0];
    }

    c_sqrt(r0);
    b_rdivide(vfiltered, r0, b1);

    /* [], would use Qyz for actual displacements */
    i0 = d_E->size[0] * d_E->size[1];
    d_E->size[0] = 1;
    d_E->size[1] = E->size[1];
    emxEnsureCapacity((emxArray__common *)d_E, i0, (int)sizeof(double));
    loop_ub = E->size[0] * E->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_E->data[i0] = E->data[i0] - Eyy->data[i0];
    }

    i0 = e_E->size[0] * e_E->size[1];
    e_E->size[0] = 1;
    e_E->size[1] = E->size[1];
    emxEnsureCapacity((emxArray__common *)e_E, i0, (int)sizeof(double));
    loop_ub = E->size[0] * E->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      e_E->data[i0] = E->data[i0] + Eyy->data[i0];
    }

    b_rdivide(d_E, e_E, a2);
    i0 = r9->size[0] * r9->size[1];
    r9->size[0] = 1;
    r9->size[1] = azfiltered->size[1];
    emxEnsureCapacity((emxArray__common *)r9, i0, (int)sizeof(double));
    loop_ub = azfiltered->size[0] * azfiltered->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r9->data[i0] = 2.0 * azfiltered->data[i0];
    }

    i0 = c_E->size[0] * c_E->size[1];
    c_E->size[0] = 1;
    c_E->size[1] = E->size[1];
    emxEnsureCapacity((emxArray__common *)c_E, i0, (int)sizeof(double));
    loop_ub = E->size[0] * E->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      c_E->data[i0] = E->data[i0] + Eyy->data[i0];
    }

    b_rdivide(r9, c_E, b2);

    /* % wave directions */
    /*  note that 0 deg is for waves headed towards positive x (EAST, right hand system) */
    b_atan2(b1, a1, dir1);

    /*  [rad], 4 quadrant */
    b_atan2(b2, a2, ufiltered);
    c_rdivide(ufiltered, 2.0, vfiltered);

    /*  [rad], only 2 quadrant */
    power(a1, azfiltered);
    power(b2, r0);
    i0 = azfiltered->size[0] * azfiltered->size[1];
    azfiltered->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)azfiltered, i0, (int)sizeof(double));
    nm1d2 = azfiltered->size[0];
    k = azfiltered->size[1];
    loop_ub = nm1d2 * k;
    for (i0 = 0; i0 < loop_ub; i0++) {
      azfiltered->data[i0] += r0->data[i0];
    }

    c_sqrt(azfiltered);
    i0 = azfiltered->size[0] * azfiltered->size[1];
    azfiltered->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)azfiltered, i0, (int)sizeof(double));
    nm1d2 = azfiltered->size[0];
    k = azfiltered->size[1];
    loop_ub = nm1d2 * k;
    for (i0 = 0; i0 < loop_ub; i0++) {
      azfiltered->data[i0] = 1.0 - azfiltered->data[i0];
    }

    i0 = azfiltered->size[0] * azfiltered->size[1];
    azfiltered->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)azfiltered, i0, (int)sizeof(double));
    nm1d2 = azfiltered->size[0];
    k = azfiltered->size[1];
    loop_ub = nm1d2 * k;
    for (i0 = 0; i0 < loop_ub; i0++) {
      azfiltered->data[i0] *= 2.0;
    }

    c_sqrt(azfiltered);
    i0 = r0->size[0] * r0->size[1];
    r0->size[0] = 1;
    r0->size[1] = vfiltered->size[1];
    emxEnsureCapacity((emxArray__common *)r0, i0, (int)sizeof(double));
    loop_ub = vfiltered->size[0] * vfiltered->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r0->data[i0] = 2.0 * vfiltered->data[i0];
    }

    b_cos(r0);
    i0 = vfiltered->size[0] * vfiltered->size[1];
    vfiltered->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)vfiltered, i0, (int)sizeof(double));
    nm1d2 = vfiltered->size[0];
    k = vfiltered->size[1];
    loop_ub = nm1d2 * k;
    for (i0 = 0; i0 < loop_ub; i0++) {
      vfiltered->data[i0] *= 2.0;
    }

    b_cos(vfiltered);
    i0 = r8->size[0] * r8->size[1];
    r8->size[0] = 1;
    r8->size[1] = a2->size[1];
    emxEnsureCapacity((emxArray__common *)r8, i0, (int)sizeof(double));
    loop_ub = a2->size[0] * a2->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r8->data[i0] = 0.5 - 0.5 * (a2->data[i0] * r0->data[i0] + b2->data[i0] *
        vfiltered->data[i0]);
    }

    b_abs(r8, r0);
    b_sqrt(r0, r22);

    /* % screen for presence/absence of acceleration data */
    if (azdummy == 1) {
      i0 = Ezz->size[0] * Ezz->size[1];
      Ezz->size[0] = 1;
      emxEnsureCapacity((emxArray__common *)Ezz, i0, (int)sizeof(double));
      loop_ub = Ezz->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        Ezz->data[Ezz->size[0] * i0] = 0.0;
      }

      i0 = a1->size[0] * a1->size[1];
      a1->size[0] = 1;
      emxEnsureCapacity((emxArray__common *)a1, i0, (int)sizeof(double));
      loop_ub = a1->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        a1->data[a1->size[0] * i0] = 9999.0;
      }

      i0 = b1->size[0] * b1->size[1];
      b1->size[0] = 1;
      emxEnsureCapacity((emxArray__common *)b1, i0, (int)sizeof(double));
      loop_ub = b1->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        b1->data[b1->size[0] * i0] = 9999.0;
      }

      i0 = dir1->size[0] * dir1->size[1];
      dir1->size[0] = 1;
      emxEnsureCapacity((emxArray__common *)dir1, i0, (int)sizeof(double));
      loop_ub = dir1->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        dir1->data[dir1->size[0] * i0] = 9999.0;
      }

      i0 = azfiltered->size[0] * azfiltered->size[1];
      azfiltered->size[0] = 1;
      emxEnsureCapacity((emxArray__common *)azfiltered, i0, (int)sizeof(double));
      loop_ub = azfiltered->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        azfiltered->data[azfiltered->size[0] * i0] = 9999.0;
      }
    }

    /* % use orbit shape as check on quality */
    i0 = b_Eyy->size[0] * b_Eyy->size[1];
    b_Eyy->size[0] = 1;
    b_Eyy->size[1] = Eyy->size[1];
    emxEnsureCapacity((emxArray__common *)b_Eyy, i0, (int)sizeof(double));
    loop_ub = Eyy->size[0] * Eyy->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_Eyy->data[i0] = Eyy->data[i0] + E->data[i0];
    }

    b_rdivide(Ezz, b_Eyy, vfiltered);

    /* % apply LFNR tolerance  */
    /* Exx(LFNR*(UU) < Exx ) = 0;  % quality control based on LFNR of swell */
    /* Eyy(LFNR*(VV) < Eyy ) = 0;  % quality control based on LFNR of swell */
    /* Ezz(LFNR*(AZAZ.* (9.8^2)) < Ezz ) = 0;  % quality control based on LFNR of swell */
    /* % Scalar energy spectra (a0) */
    i0 = E->size[0] * E->size[1];
    E->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)E, i0, (int)sizeof(double));
    nm1d2 = E->size[0];
    k = E->size[1];
    loop_ub = nm1d2 * k;
    for (i0 = 0; i0 < loop_ub; i0++) {
      E->data[i0] += Eyy->data[i0];
    }

    /* E = zeros(1,length(f)); */
    /* if azdummy ==1, */
    /*     E = Exx + Eyy; */
    /* else */
    /* fchange = 0.1;  */
    /* E(f>fchange) = Exx(f>fchange) +Eyy(f>fchange) ; % use GPS for scalar energy of wind waves */
    /* E(f<=fchange) = Ezz(f<=fchange); % use heave acceleratiosn for scalar energy of swell */
    /* end */
    /*  testing bits */
    /* E = nanmean([Ezz' (Exx+Eyy)'],2)'; */
    /* E = Eyy+Exx; % pure GPS version (for testing) */
    /* E( check > maxEratio | check < minEratio ) = 0;  */
    /* figure, loglog(f,check) */
    /* clf, loglog(f,UU+VV,'g',f,Exx+Eyy,'b',f,AZAZ.*9.8^2,'m',f,Ezz,'r'),legend('UU+VV','XX+YY','AZAZ','ZZ') % for testing */
    /* loglog(f,abs(Cxz),f,abs(Cyz)) */
    /* drawnow */
    /* % wave stats */
    i0 = badu->size[0] * badu->size[1];
    badu->size[0] = 1;
    badu->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)badu, i0, (int)sizeof(boolean_T));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      badu->data[i0] = (f->data[i0] > 0.04);
    }

    i0 = badv->size[0] * badv->size[1];
    badv->size[0] = 1;
    badv->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)badv, i0, (int)sizeof(boolean_T));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      badv->data[i0] = (f->data[i0] < 1.0);
    }

    /*  frequency cutoff for wave stats, 0.4 is specific to SWIFT hull */
    n = badu->size[1];
    for (k = 0; k < n; k++) {
      if (!(badu->data[k] && badv->data[k])) {
        E->data[k] = 0.0;
      }
    }

    /*  significant wave height */
    n = badu->size[1] - 1;
    nm1d2 = 0;
    for (k = 0; k <= n; k++) {
      if (badu->data[k] && badv->data[k]) {
        nm1d2++;
      }
    }

    i0 = r2->size[0] * r2->size[1];
    r2->size[0] = 1;
    r2->size[1] = nm1d2;
    emxEnsureCapacity((emxArray__common *)r2, i0, (int)sizeof(int));
    nm1d2 = 0;
    for (k = 0; k <= n; k++) {
      if (badu->data[k] && badv->data[k]) {
        r2->data[nm1d2] = k + 1;
        nm1d2++;
      }
    }

    i0 = b_E->size[0] * b_E->size[1];
    b_E->size[0] = 1;
    b_E->size[1] = r2->size[1];
    emxEnsureCapacity((emxArray__common *)b_E, i0, (int)sizeof(double));
    loop_ub = r2->size[0] * r2->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_E->data[i0] = E->data[r2->data[i0] - 1];
    }

    anew = b_sum(b_E) * bandwidth;
    *Hs = 4.0 * sqrt(anew);

    /*   energy period */
    /*  peak period */
    i0 = UU->size[0] * UU->size[1];
    UU->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)UU, i0, (int)sizeof(double));
    nm1d2 = UU->size[0];
    k = UU->size[1];
    loop_ub = nm1d2 * k;
    for (i0 = 0; i0 < loop_ub; i0++) {
      UU->data[i0] += VV->data[i0];
    }

    nm1d2 = 1;
    n = UU->size[1];
    anew = UU->data[0];
    itmp = 0;
    if (rtIsNaN(UU->data[0])) {
      k = 2;
      exitg1 = false;
      while ((!exitg1) && (k <= n)) {
        nm1d2 = k;
        if (!rtIsNaN(UU->data[k - 1])) {
          anew = UU->data[k - 1];
          itmp = k - 1;
          exitg1 = true;
        } else {
          k++;
        }
      }
    }

    if (nm1d2 < UU->size[1]) {
      while (nm1d2 + 1 <= n) {
        if (UU->data[nm1d2] > anew) {
          anew = UU->data[nm1d2];
          itmp = nm1d2;
        }

        nm1d2++;
      }
    }

    /*  can use velocity (picks out more distint peak) */
    /* [~ , fpindex] = max(E); */
    *Tp = rdivide(1.0, f->data[itmp]);

    /* % spectral directions */
    /*  switch from rad to deg, and CCW to CW (negate) */
    i0 = dir1->size[0] * dir1->size[1];
    dir1->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)dir1, i0, (int)sizeof(double));
    nm1d2 = dir1->size[0];
    k = dir1->size[1];
    loop_ub = nm1d2 * k;
    for (i0 = 0; i0 < loop_ub; i0++) {
      dir1->data[i0] = -57.324840764331206 * dir1->data[i0] + 90.0;
    }

    /*  rotate from eastward = 0 to northward  = 0 */
    n = dir1->size[1] - 1;
    nm1d2 = 0;
    for (k = 0; k <= n; k++) {
      if (dir1->data[k] < 0.0) {
        nm1d2++;
      }
    }

    i0 = r2->size[0] * r2->size[1];
    r2->size[0] = 1;
    r2->size[1] = nm1d2;
    emxEnsureCapacity((emxArray__common *)r2, i0, (int)sizeof(int));
    nm1d2 = 0;
    for (k = 0; k <= n; k++) {
      if (dir1->data[k] < 0.0) {
        r2->data[nm1d2] = k + 1;
        nm1d2++;
      }
    }

    i0 = b_dir1->size[0];
    b_dir1->size[0] = r2->size[0] * r2->size[1];
    emxEnsureCapacity((emxArray__common *)b_dir1, i0, (int)sizeof(double));
    loop_ub = r2->size[0] * r2->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_dir1->data[i0] = dir1->data[r2->data[i0] - 1] + 360.0;
    }

    loop_ub = b_dir1->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      dir1->data[r2->data[i0] - 1] = b_dir1->data[i0];
    }

    /*  take NW quadrant from negative to 270-360 range */
    i0 = badu->size[0] * badu->size[1];
    badu->size[0] = 1;
    badu->size[1] = dir1->size[1];
    emxEnsureCapacity((emxArray__common *)badu, i0, (int)sizeof(boolean_T));
    loop_ub = dir1->size[0] * dir1->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      badu->data[i0] = (dir1->data[i0] < 180.0);
    }

    n = dir1->size[1] - 1;
    nm1d2 = 0;
    for (k = 0; k <= n; k++) {
      if (dir1->data[k] > 180.0) {
        nm1d2++;
      }
    }

    i0 = r2->size[0] * r2->size[1];
    r2->size[0] = 1;
    r2->size[1] = nm1d2;
    emxEnsureCapacity((emxArray__common *)r2, i0, (int)sizeof(int));
    nm1d2 = 0;
    for (k = 0; k <= n; k++) {
      if (dir1->data[k] > 180.0) {
        r2->data[nm1d2] = k + 1;
        nm1d2++;
      }
    }

    i0 = c_dir1->size[0];
    c_dir1->size[0] = r2->size[0] * r2->size[1];
    emxEnsureCapacity((emxArray__common *)c_dir1, i0, (int)sizeof(double));
    loop_ub = r2->size[0] * r2->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      c_dir1->data[i0] = dir1->data[r2->data[i0] - 1] - 180.0;
    }

    loop_ub = c_dir1->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      dir1->data[r2->data[i0] - 1] = c_dir1->data[i0];
    }

    /*  take reciprocal such wave direction is FROM, not TOWARDS */
    n = badu->size[1] - 1;
    nm1d2 = 0;
    for (k = 0; k <= n; k++) {
      if (badu->data[k]) {
        nm1d2++;
      }
    }

    i0 = r2->size[0] * r2->size[1];
    r2->size[0] = 1;
    r2->size[1] = nm1d2;
    emxEnsureCapacity((emxArray__common *)r2, i0, (int)sizeof(int));
    nm1d2 = 0;
    for (k = 0; k <= n; k++) {
      if (badu->data[k]) {
        r2->data[nm1d2] = k + 1;
        nm1d2++;
      }
    }

    i0 = d_dir1->size[0];
    d_dir1->size[0] = r2->size[0] * r2->size[1];
    emxEnsureCapacity((emxArray__common *)d_dir1, i0, (int)sizeof(double));
    loop_ub = r2->size[0] * r2->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_dir1->data[i0] = dir1->data[r2->data[i0] - 1] + 180.0;
    }

    loop_ub = d_dir1->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      dir1->data[r2->data[i0] - 1] = d_dir1->data[i0];
    }

    /*  take reciprocal such wave direction is FROM, not TOWARDS */
    /*  directional spread */
    /* % dominant direction */
    /*  or peak direction (very noisy) */
    /* Dp = dir(fpindex); % dominant (peak) direction, use peak f */
    /*  or average */
    *Dp = dir1->data[itmp];

    /*  dominant (peak) direction, use peak f */
    if (azdummy == 1) {
      *Dp = 9999.0;
    }

    /* % screen for bad direction estimate, or no heave data     */
    /*  pick neighboring bands */
    for (i0 = 0; i0 < 3; i0++) {
      c_inds = (double)(itmp + 1) + (-1.0 + (double)i0);
      inds[i0] = (c_inds > 0.0);
      b_inds[i0] = c_inds;
    }

    if (all(inds)) {
      for (i0 = 0; i0 < 3; i0++) {
        f_dir1[i0] = dir1->data[(int)b_inds[i0] - 1];
      }

      if ((b_std(f_dir1) > 45.0) || (azdummy == 1)) {
        *Dp = 9999.0;
      }
    } else {
      *Dp = 9999.0;
    }

    /* % prune high frequency results */
    i0 = i_f->size[0] * i_f->size[1];
    i_f->size[0] = 1;
    i_f->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)i_f, i0, (int)sizeof(boolean_T));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      i_f->data[i0] = (f->data[i0] > 0.5);
    }

    d_eml_null_assignment(E, i_f);
    i0 = h_f->size[0] * h_f->size[1];
    h_f->size[0] = 1;
    h_f->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)h_f, i0, (int)sizeof(boolean_T));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      h_f->data[i0] = (f->data[i0] > 0.5);
    }

    eml_null_assignment(dir1, h_f, e_dir1);
    i0 = r7->size[0] * r7->size[1];
    r7->size[0] = 1;
    r7->size[1] = azfiltered->size[1];
    emxEnsureCapacity((emxArray__common *)r7, i0, (int)sizeof(double));
    loop_ub = azfiltered->size[0] * azfiltered->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r7->data[i0] = 57.324840764331206 * azfiltered->data[i0];
    }

    i0 = g_f->size[0] * g_f->size[1];
    g_f->size[0] = 1;
    g_f->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)g_f, i0, (int)sizeof(boolean_T));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      g_f->data[i0] = (f->data[i0] > 0.5);
    }

    eml_null_assignment(r7, g_f, j_f);
    i0 = f_f->size[0] * f_f->size[1];
    f_f->size[0] = 1;
    f_f->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)f_f, i0, (int)sizeof(boolean_T));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      f_f->data[i0] = (f->data[i0] > 0.5);
    }

    d_eml_null_assignment(a1, f_f);
    i0 = e_f->size[0] * e_f->size[1];
    e_f->size[0] = 1;
    e_f->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)e_f, i0, (int)sizeof(boolean_T));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      e_f->data[i0] = (f->data[i0] > 0.5);
    }

    d_eml_null_assignment(b1, e_f);
    i0 = d_f->size[0] * d_f->size[1];
    d_f->size[0] = 1;
    d_f->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)d_f, i0, (int)sizeof(boolean_T));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d_f->data[i0] = (f->data[i0] > 0.5);
    }

    d_eml_null_assignment(a2, d_f);
    i0 = c_f->size[0] * c_f->size[1];
    c_f->size[0] = 1;
    c_f->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)c_f, i0, (int)sizeof(boolean_T));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      c_f->data[i0] = (f->data[i0] > 0.5);
    }

    d_eml_null_assignment(b2, c_f);
    i0 = b_f->size[0] * b_f->size[1];
    b_f->size[0] = 1;
    b_f->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)b_f, i0, (int)sizeof(boolean_T));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_f->data[i0] = (f->data[i0] > 0.5);
    }

    eml_null_assignment(vfiltered, b_f, b_vfiltered);
    i0 = badu->size[0] * badu->size[1];
    badu->size[0] = 1;
    badu->size[1] = f->size[1];
    emxEnsureCapacity((emxArray__common *)badu, i0, (int)sizeof(boolean_T));
    loop_ub = f->size[0] * f->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      badu->data[i0] = (f->data[i0] > 0.5);
    }

    d_eml_null_assignment(f, badu);
  } else {
    /*  if not enough points or sufficent sampling rate or data, give 9999 */
    *Hs = 9999.0;
    *Tp = 9999.0;
    *Dp = 9999.0;
    i0 = E->size[0] * E->size[1];
    E->size[0] = 1;
    E->size[1] = 1;
    emxEnsureCapacity((emxArray__common *)E, i0, (int)sizeof(double));
    E->data[0] = 9999.0;
    i0 = f->size[0] * f->size[1];
    f->size[0] = 1;
    f->size[1] = 1;
    emxEnsureCapacity((emxArray__common *)f, i0, (int)sizeof(double));
    f->data[0] = 9999.0;
    i0 = a1->size[0] * a1->size[1];
    a1->size[0] = 1;
    a1->size[1] = 1;
    emxEnsureCapacity((emxArray__common *)a1, i0, (int)sizeof(double));
    a1->data[0] = 9999.0;
    i0 = b1->size[0] * b1->size[1];
    b1->size[0] = 1;
    b1->size[1] = 1;
    emxEnsureCapacity((emxArray__common *)b1, i0, (int)sizeof(double));
    b1->data[0] = 9999.0;
    i0 = a2->size[0] * a2->size[1];
    a2->size[0] = 1;
    a2->size[1] = 1;
    emxEnsureCapacity((emxArray__common *)a2, i0, (int)sizeof(double));
    a2->data[0] = 9999.0;
    i0 = b2->size[0] * b2->size[1];
    b2->size[0] = 1;
    b2->size[1] = 1;
    emxEnsureCapacity((emxArray__common *)b2, i0, (int)sizeof(double));
    b2->data[0] = 9999.0;
  }

  emxFree_real_T(&b_vfiltered);
  emxFree_real_T(&j_f);
  emxFree_real_T(&e_dir1);
  emxFree_real_T(&r22);
  emxFree_real_T(&d_dir1);
  emxFree_real_T(&c_dir1);
  emxFree_real_T(&b_dir1);
  emxFree_real_T(&r21);
  emxFree_real_T(&r20);
  emxFree_real_T(&r19);
  emxFree_real_T(&b_UUwindow);
  emxFree_real_T(&b_VVwindow);
  emxFree_real_T(&b_AZAZwindow);
  emxFree_creal_T(&b_UVwindow);
  emxFree_creal_T(&b_UAZwindow);
  emxFree_creal_T(&b_VAZwindow);
  emxFree_real_T(&b_ufiltered);
  emxFree_real_T(&r18);
  emxFree_real_T(&r17);
  emxFree_real_T(&r16);
  emxFree_real_T(&c_w);
  emxFree_real_T(&b_w);
  emxFree_real_T(&w);
  emxFree_real_T(&b_uwindow);
  emxFree_real_T(&b_vwindow);
  emxFree_real_T(&b_azwindow);
  emxFree_creal_T(&b_Uwindow);
  emxFree_creal_T(&b_Vwindow);
  emxFree_creal_T(&b_AZwindow);
  emxFree_real_T(&r15);
  emxFree_real_T(&r14);
  emxFree_real_T(&r13);
  emxFree_real_T(&r12);
  emxFree_real_T(&b_UAZ);
  emxFree_real_T(&r11);
  emxFree_real_T(&b_VAZ);
  emxFree_real_T(&r10);
  emxFree_real_T(&b_UV);
  emxFree_real_T(&e_E);
  emxFree_real_T(&d_E);
  emxFree_real_T(&c_E);
  emxFree_real_T(&r9);
  emxFree_real_T(&r8);
  emxFree_real_T(&b_Eyy);
  emxFree_real_T(&b_E);
  emxFree_boolean_T(&i_f);
  emxFree_boolean_T(&h_f);
  emxFree_boolean_T(&g_f);
  emxFree_real_T(&r7);
  emxFree_boolean_T(&f_f);
  emxFree_boolean_T(&e_f);
  emxFree_boolean_T(&d_f);
  emxFree_boolean_T(&c_f);
  emxFree_boolean_T(&b_f);
  emxFree_real_T(&r6);
  emxFree_real_T(&r0);
  emxFree_creal_T(&A);
  emxFree_real_T(&a);
  emxFree_int32_T(&r2);
  emxFree_creal_T(&r5);
  emxFree_int32_T(&r4);
  emxFree_real_T(&dir1);
  emxFree_real_T(&Ezz);
  emxFree_real_T(&Eyy);
  emxFree_creal_T(&VAZ);
  emxFree_creal_T(&UAZ);
  emxFree_creal_T(&UV);
  emxFree_real_T(&VV);
  emxFree_real_T(&UU);
  emxFree_creal_T(&VAZwindow);
  emxFree_creal_T(&UAZwindow);
  emxFree_creal_T(&UVwindow);
  emxFree_real_T(&AZAZwindow);
  emxFree_real_T(&VVwindow);
  emxFree_real_T(&UUwindow);
  emxFree_creal_T(&AZwindow);
  emxFree_creal_T(&Vwindow);
  emxFree_creal_T(&Uwindow);
  emxFree_real_T(&factaz);
  emxFree_real_T(&factv);
  emxFree_real_T(&factu);
  emxFree_real_T(&vwindowtaper);
  emxFree_real_T(&uwindowtaper);
  emxFree_real_T(&taper);
  emxFree_real_T(&azwindow);
  emxFree_real_T(&vwindow);
  emxFree_real_T(&uwindow);
  emxFree_real_T(&azfiltered);
  emxFree_real_T(&vfiltered);
  emxFree_real_T(&ufiltered);
  emxFree_boolean_T(&badv);
  emxFree_boolean_T(&badu);

  /*  quality control */
  if (*Tp > 20.0) {
    *Hs = 9999.0;
    *Tp = 9999.0;
    *Dp = 9999.0;
  }
}

/* End of code generation (GPSandIMUwaves.cpp) */
