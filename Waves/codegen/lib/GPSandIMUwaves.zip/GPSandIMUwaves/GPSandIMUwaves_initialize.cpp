/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * GPSandIMUwaves_initialize.cpp
 *
 * Code generation for function 'GPSandIMUwaves_initialize'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "GPSandIMUwaves.h"
#include "GPSandIMUwaves_initialize.h"

/* Function Definitions */
void GPSandIMUwaves_initialize()
{
  rt_InitInfAndNaN(8U);
}

/* End of code generation (GPSandIMUwaves_initialize.cpp) */
