/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * GPSandIMUwaves.h
 *
 * Code generation for function 'GPSandIMUwaves'
 *
 */

#ifndef __GPSANDIMUWAVES_H__
#define __GPSANDIMUWAVES_H__

/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_defines.h"
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "GPSandIMUwaves_types.h"

/* Function Declarations */
extern void GPSandIMUwaves(emxArray_real_T *u, emxArray_real_T *v,
  emxArray_real_T *az, const emxArray_real_T *pitch, const emxArray_real_T *roll,
  double fs, double *Hs, double *Tp, double *Dp, emxArray_real_T *E,
  emxArray_real_T *f, emxArray_real_T *a1, emxArray_real_T *b1, emxArray_real_T *
  a2, emxArray_real_T *b2);

#endif

/* End of code generation (GPSandIMUwaves.h) */
