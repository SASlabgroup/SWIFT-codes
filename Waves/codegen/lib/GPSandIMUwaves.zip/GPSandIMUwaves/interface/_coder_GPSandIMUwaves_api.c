/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_GPSandIMUwaves_api.c
 *
 * Code generation for function '_coder_GPSandIMUwaves_api'
 *
 */

/* Include files */
#include "tmwtypes.h"
#include "_coder_GPSandIMUwaves_api.h"
#include "_coder_GPSandIMUwaves_mex.h"

/* Variable Definitions */
emlrtCTX emlrtRootTLSGlobal = NULL;
emlrtContext emlrtContextGlobal = { true, false, 131419U, NULL, "GPSandIMUwaves",
  NULL, false, { 2045744189U, 2170104910U, 2743257031U, 4284093946U }, NULL };

/* Function Declarations */
static void b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, emxArray_real_T *y);
static const mxArray *b_emlrt_marshallOut(const emxArray_real_T *u);
static real_T c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *fs, const
  char_T *identifier);
static real_T d_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId);
static void e_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, emxArray_real_T *ret);
static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  char_T *identifier, emxArray_real_T *y);
static const mxArray *emlrt_marshallOut(const real_T u);
static void emxFree_real_T(emxArray_real_T **pEmxArray);
static void emxInit_real_T(const emlrtStack *sp, emxArray_real_T **pEmxArray,
  int32_T numDimensions, boolean_T doPush);
static real_T f_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId);

/* Function Definitions */
static void b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, emxArray_real_T *y)
{
  e_emlrt_marshallIn(sp, emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static const mxArray *b_emlrt_marshallOut(const emxArray_real_T *u)
{
  const mxArray *y;
  static const int32_T iv0[2] = { 0, 0 };

  const mxArray *m1;
  y = NULL;
  m1 = emlrtCreateNumericArray(2, iv0, mxDOUBLE_CLASS, mxREAL);
  mxSetData((mxArray *)m1, (void *)u->data);
  emlrtSetDimensions((mxArray *)m1, u->size, 2);
  emlrtAssign(&y, m1);
  return y;
}

static real_T c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *fs, const
  char_T *identifier)
{
  real_T y;
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = d_emlrt_marshallIn(sp, emlrtAlias(fs), &thisId);
  emlrtDestroyArray(&fs);
  return y;
}

static real_T d_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId)
{
  real_T y;
  y = f_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static void e_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, emxArray_real_T *ret)
{
  int32_T iv1[2];
  boolean_T bv0[2] = { false, true };

  static const int32_T dims[2] = { 1, -1 };

  emlrtCheckVsBuiltInR2012b(sp, msgId, src, "double", false, 2U, dims, &bv0[0],
    iv1);
  ret->size[0] = iv1[0];
  ret->size[1] = iv1[1];
  ret->allocatedSize = ret->size[0] * ret->size[1];
  ret->data = (real_T *)mxGetData(src);
  ret->canFreeData = false;
  emlrtDestroyArray(&src);
}

static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  char_T *identifier, emxArray_real_T *y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  b_emlrt_marshallIn(sp, emlrtAlias(u), &thisId, y);
  emlrtDestroyArray(&u);
}

static const mxArray *emlrt_marshallOut(const real_T u)
{
  const mxArray *y;
  const mxArray *m0;
  y = NULL;
  m0 = emlrtCreateDoubleScalar(u);
  emlrtAssign(&y, m0);
  return y;
}

static void emxFree_real_T(emxArray_real_T **pEmxArray)
{
  if (*pEmxArray != (emxArray_real_T *)NULL) {
    if (((*pEmxArray)->data != (real_T *)NULL) && (*pEmxArray)->canFreeData) {
      emlrtFreeMex((void *)(*pEmxArray)->data);
    }

    emlrtFreeMex((void *)(*pEmxArray)->size);
    emlrtFreeMex((void *)*pEmxArray);
    *pEmxArray = (emxArray_real_T *)NULL;
  }
}

static void emxInit_real_T(const emlrtStack *sp, emxArray_real_T **pEmxArray,
  int32_T numDimensions, boolean_T doPush)
{
  emxArray_real_T *emxArray;
  int32_T i;
  *pEmxArray = (emxArray_real_T *)emlrtMallocMex(sizeof(emxArray_real_T));
  if (doPush) {
    emlrtPushHeapReferenceStackR2012b(sp, (void *)pEmxArray, (void (*)(void *))
      emxFree_real_T);
  }

  emxArray = *pEmxArray;
  emxArray->data = (real_T *)NULL;
  emxArray->numDimensions = numDimensions;
  emxArray->size = (int32_T *)emlrtMallocMex((uint32_T)(sizeof(int32_T)
    * numDimensions));
  emxArray->allocatedSize = 0;
  emxArray->canFreeData = true;
  for (i = 0; i < numDimensions; i++) {
    emxArray->size[i] = 0;
  }
}

static real_T f_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId)
{
  real_T ret;
  static const int32_T dims = 0;
  emlrtCheckBuiltInR2012b(sp, msgId, src, "double", false, 0U, &dims);
  ret = *(real_T *)mxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

void GPSandIMUwaves_api(const mxArray *prhs[6], const mxArray *plhs[9])
{
  emxArray_real_T *u;
  emxArray_real_T *v;
  emxArray_real_T *az;
  emxArray_real_T *pitch;
  emxArray_real_T *roll;
  emxArray_real_T *E;
  emxArray_real_T *f;
  emxArray_real_T *a1;
  emxArray_real_T *b1;
  emxArray_real_T *a2;
  emxArray_real_T *b2;
  real_T fs;
  real_T Dp;
  real_T Tp;
  real_T Hs;
  emlrtStack st = { NULL, NULL, NULL };

  st.tls = emlrtRootTLSGlobal;
  emlrtHeapReferenceStackEnterFcnR2012b(&st);
  emxInit_real_T(&st, &u, 2, true);
  emxInit_real_T(&st, &v, 2, true);
  emxInit_real_T(&st, &az, 2, true);
  emxInit_real_T(&st, &pitch, 2, true);
  emxInit_real_T(&st, &roll, 2, true);
  emxInit_real_T(&st, &E, 2, true);
  emxInit_real_T(&st, &f, 2, true);
  emxInit_real_T(&st, &a1, 2, true);
  emxInit_real_T(&st, &b1, 2, true);
  emxInit_real_T(&st, &a2, 2, true);
  emxInit_real_T(&st, &b2, 2, true);
  prhs[0] = emlrtProtectR2012b(prhs[0], 0, false, -1);
  prhs[1] = emlrtProtectR2012b(prhs[1], 1, false, -1);
  prhs[2] = emlrtProtectR2012b(prhs[2], 2, false, -1);
  prhs[3] = emlrtProtectR2012b(prhs[3], 3, false, -1);
  prhs[4] = emlrtProtectR2012b(prhs[4], 4, false, -1);

  /* Marshall function inputs */
  emlrt_marshallIn(&st, emlrtAlias(prhs[0]), "u", u);
  emlrt_marshallIn(&st, emlrtAlias(prhs[1]), "v", v);
  emlrt_marshallIn(&st, emlrtAlias(prhs[2]), "az", az);
  emlrt_marshallIn(&st, emlrtAlias(prhs[3]), "pitch", pitch);
  emlrt_marshallIn(&st, emlrtAlias(prhs[4]), "roll", roll);
  fs = c_emlrt_marshallIn(&st, emlrtAliasP(prhs[5]), "fs");

  /* Invoke the target function */
  GPSandIMUwaves(u, v, az, pitch, roll, fs, &Hs, &Tp, &Dp, E, f, a1, b1, a2, b2);

  /* Marshall function outputs */
  plhs[0] = emlrt_marshallOut(Hs);
  plhs[1] = emlrt_marshallOut(Tp);
  plhs[2] = emlrt_marshallOut(Dp);
  plhs[3] = b_emlrt_marshallOut(E);
  plhs[4] = b_emlrt_marshallOut(f);
  plhs[5] = b_emlrt_marshallOut(a1);
  plhs[6] = b_emlrt_marshallOut(b1);
  plhs[7] = b_emlrt_marshallOut(a2);
  plhs[8] = b_emlrt_marshallOut(b2);
  b2->canFreeData = false;
  emxFree_real_T(&b2);
  a2->canFreeData = false;
  emxFree_real_T(&a2);
  b1->canFreeData = false;
  emxFree_real_T(&b1);
  a1->canFreeData = false;
  emxFree_real_T(&a1);
  f->canFreeData = false;
  emxFree_real_T(&f);
  E->canFreeData = false;
  emxFree_real_T(&E);
  roll->canFreeData = false;
  emxFree_real_T(&roll);
  pitch->canFreeData = false;
  emxFree_real_T(&pitch);
  az->canFreeData = false;
  emxFree_real_T(&az);
  v->canFreeData = false;
  emxFree_real_T(&v);
  u->canFreeData = false;
  emxFree_real_T(&u);
  emlrtHeapReferenceStackLeaveFcnR2012b(&st);
}

void GPSandIMUwaves_atexit(void)
{
  emlrtStack st = { NULL, NULL, NULL };

  mexFunctionCreateRootTLS();
  st.tls = emlrtRootTLSGlobal;
  emlrtEnterRtStackR2012b(&st);
  emlrtLeaveRtStackR2012b(&st);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
  GPSandIMUwaves_xil_terminate();
}

void GPSandIMUwaves_initialize(void)
{
  emlrtStack st = { NULL, NULL, NULL };

  mexFunctionCreateRootTLS();
  st.tls = emlrtRootTLSGlobal;
  emlrtClearAllocCountR2012b(&st, false, 0U, 0);
  emlrtEnterRtStackR2012b(&st);
  emlrtFirstTimeR2012b(emlrtRootTLSGlobal);
}

void GPSandIMUwaves_terminate(void)
{
  emlrtStack st = { NULL, NULL, NULL };

  st.tls = emlrtRootTLSGlobal;
  emlrtLeaveRtStackR2012b(&st);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

/* End of code generation (_coder_GPSandIMUwaves_api.c) */
