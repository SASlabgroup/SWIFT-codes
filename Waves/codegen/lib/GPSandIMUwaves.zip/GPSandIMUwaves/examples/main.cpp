/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * main.cpp
 *
 * Code generation for function 'main'
 *
 */

/*************************************************************************/
/* This automatically generated example C main file shows how to call    */
/* entry-point functions that MATLAB Coder generated. You must customize */
/* this file for your application. Do not modify this file directly.     */
/* Instead, make a copy of this file, modify it, and integrate it into   */
/* your development environment.                                         */
/*                                                                       */
/* This file initializes entry-point function arguments to a default     */
/* size and value before calling the entry-point functions. It does      */
/* not store or use any values returned from the entry-point functions.  */
/* If necessary, it does pre-allocate memory for returned values.        */
/* You can use this file as a starting point for a main function that    */
/* you can deploy in your application.                                   */
/*                                                                       */
/* After you copy the file, and before you deploy it, you must make the  */
/* following changes:                                                    */
/* * For variable-size function arguments, change the example sizes to   */
/* the sizes that your application requires.                             */
/* * Change the example values of function arguments to the values that  */
/* your application requires.                                            */
/* * If the entry-point functions return values, store these values or   */
/* otherwise use them as required by your application.                   */
/*                                                                       */
/*************************************************************************/
/* Include files */
#include "rt_nonfinite.h"
#include "GPSandIMUwaves.h"
#include "main.h"
#include "GPSandIMUwaves_terminate.h"
#include "GPSandIMUwaves_emxAPI.h"
#include "GPSandIMUwaves_initialize.h"

/* Function Declarations */
static emxArray_real_T *argInit_1xUnbounded_real_T();
static double argInit_real_T();
static void main_GPSandIMUwaves();

/* Function Definitions */
static emxArray_real_T *argInit_1xUnbounded_real_T()
{
  emxArray_real_T *result;
  static int iv0[2] = { 1, 2 };

  int idx1;

  /* Set the size of the array.
     Change this size to the value that the application requires. */
  result = emxCreateND_real_T(2, *(int (*)[2])&iv0[0]);

  /* Loop over the array to initialize each element. */
  for (idx1 = 0; idx1 < result->size[1U]; idx1++) {
    /* Set the value of the array element.
       Change this value to the value that the application requires. */
    result->data[result->size[0] * idx1] = argInit_real_T();
  }

  return result;
}

static double argInit_real_T()
{
  return 0.0;
}

static void main_GPSandIMUwaves()
{
  emxArray_real_T *E;
  emxArray_real_T *f;
  emxArray_real_T *a1;
  emxArray_real_T *b1;
  emxArray_real_T *a2;
  emxArray_real_T *b2;
  emxArray_real_T *u;
  emxArray_real_T *v;
  emxArray_real_T *az;
  emxArray_real_T *pitch;
  emxArray_real_T *roll;
  double Dp;
  double Tp;
  double Hs;
  emxInitArray_real_T(&E, 2);
  emxInitArray_real_T(&f, 2);
  emxInitArray_real_T(&a1, 2);
  emxInitArray_real_T(&b1, 2);
  emxInitArray_real_T(&a2, 2);
  emxInitArray_real_T(&b2, 2);

  /* Initialize function 'GPSandIMUwaves' input arguments. */
  /* Initialize function input argument 'u'. */
  u = argInit_1xUnbounded_real_T();

  /* Initialize function input argument 'v'. */
  v = argInit_1xUnbounded_real_T();

  /* Initialize function input argument 'az'. */
  az = argInit_1xUnbounded_real_T();

  /* Initialize function input argument 'pitch'. */
  pitch = argInit_1xUnbounded_real_T();

  /* Initialize function input argument 'roll'. */
  roll = argInit_1xUnbounded_real_T();

  /* Call the entry-point 'GPSandIMUwaves'. */
  GPSandIMUwaves(u, v, az, pitch, roll, argInit_real_T(), &Hs, &Tp, &Dp, E, f,
                 a1, b1, a2, b2);
  emxDestroyArray_real_T(b2);
  emxDestroyArray_real_T(a2);
  emxDestroyArray_real_T(b1);
  emxDestroyArray_real_T(a1);
  emxDestroyArray_real_T(f);
  emxDestroyArray_real_T(E);
  emxDestroyArray_real_T(roll);
  emxDestroyArray_real_T(pitch);
  emxDestroyArray_real_T(az);
  emxDestroyArray_real_T(v);
  emxDestroyArray_real_T(u);
}

int main(int, const char * const [])
{
  /* Initialize the application.
     You do not need to do this more than one time. */
  GPSandIMUwaves_initialize();

  /* Invoke the entry-point functions.
     You can call entry-point functions multiple times. */
  main_GPSandIMUwaves();

  /* Terminate the application.
     You do not need to do this more than one time. */
  GPSandIMUwaves_terminate();
  return 0;
}

/* End of code generation (main.cpp) */
