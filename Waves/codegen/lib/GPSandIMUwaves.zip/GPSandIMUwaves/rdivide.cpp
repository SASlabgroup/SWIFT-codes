/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * rdivide.cpp
 *
 * Code generation for function 'rdivide'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "GPSandIMUwaves.h"
#include "rdivide.h"
#include "GPSandIMUwaves_emxutil.h"

/* Function Definitions */
void b_rdivide(const emxArray_real_T *x, const emxArray_real_T *y,
               emxArray_real_T *z)
{
  int i2;
  int loop_ub;
  i2 = z->size[0] * z->size[1];
  z->size[0] = 1;
  z->size[1] = x->size[1];
  emxEnsureCapacity((emxArray__common *)z, i2, (int)sizeof(double));
  loop_ub = x->size[0] * x->size[1];
  for (i2 = 0; i2 < loop_ub; i2++) {
    z->data[i2] = x->data[i2] / y->data[i2];
  }
}

void c_rdivide(const emxArray_real_T *x, double y, emxArray_real_T *z)
{
  int i3;
  int loop_ub;
  i3 = z->size[0] * z->size[1];
  z->size[0] = 1;
  z->size[1] = x->size[1];
  emxEnsureCapacity((emxArray__common *)z, i3, (int)sizeof(double));
  loop_ub = x->size[0] * x->size[1];
  for (i3 = 0; i3 < loop_ub; i3++) {
    z->data[i3] = x->data[i3] / y;
  }
}

void d_rdivide(const emxArray_creal_T *x, double y, emxArray_creal_T *z)
{
  int i5;
  int loop_ub;
  double x_re;
  double x_im;
  i5 = z->size[0] * z->size[1];
  z->size[0] = 1;
  z->size[1] = x->size[1];
  emxEnsureCapacity((emxArray__common *)z, i5, (int)sizeof(creal_T));
  loop_ub = x->size[0] * x->size[1];
  for (i5 = 0; i5 < loop_ub; i5++) {
    x_re = x->data[i5].re;
    x_im = x->data[i5].im;
    if (x_im == 0.0) {
      z->data[i5].re = x_re / y;
      z->data[i5].im = 0.0;
    } else if (x_re == 0.0) {
      z->data[i5].re = 0.0;
      z->data[i5].im = x_im / y;
    } else {
      z->data[i5].re = x_re / y;
      z->data[i5].im = x_im / y;
    }
  }
}

double rdivide(double x, double y)
{
  return x / y;
}

/* End of code generation (rdivide.cpp) */
