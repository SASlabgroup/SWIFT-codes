/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * mean.cpp
 *
 * Code generation for function 'mean'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "GPSandIMUwaves.h"
#include "mean.h"
#include "GPSandIMUwaves_emxutil.h"
#include "rdivide.h"

/* Function Definitions */
void b_mean(const emxArray_real_T *x, emxArray_real_T *y)
{
  emxArray_real_T *b_y;
  int ixstart;
  int k;
  int ix;
  int iy;
  int i;
  double s;
  emxInit_real_T(&b_y, 2);
  ixstart = b_y->size[0] * b_y->size[1];
  b_y->size[0] = 1;
  b_y->size[1] = x->size[1];
  emxEnsureCapacity((emxArray__common *)b_y, ixstart, (int)sizeof(double));
  if ((x->size[0] == 0) || (x->size[1] == 0)) {
    ixstart = b_y->size[0] * b_y->size[1];
    b_y->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)b_y, ixstart, (int)sizeof(double));
    k = b_y->size[1];
    for (ixstart = 0; ixstart < k; ixstart++) {
      b_y->data[b_y->size[0] * ixstart] = 0.0;
    }
  } else {
    ix = -1;
    iy = -1;
    for (i = 1; i <= x->size[1]; i++) {
      ixstart = ix + 1;
      ix++;
      s = x->data[ixstart];
      for (k = 2; k <= x->size[0]; k++) {
        ix++;
        s += x->data[ix];
      }

      iy++;
      b_y->data[iy] = s;
    }
  }

  c_rdivide(b_y, (double)x->size[0], y);
  emxFree_real_T(&b_y);
}

void c_mean(const emxArray_creal_T *x, emxArray_creal_T *y)
{
  emxArray_creal_T *b_y;
  int ixstart;
  int k;
  int ix;
  int iy;
  int i;
  double s_re;
  double s_im;
  emxInit_creal_T(&b_y, 2);
  ixstart = b_y->size[0] * b_y->size[1];
  b_y->size[0] = 1;
  b_y->size[1] = x->size[1];
  emxEnsureCapacity((emxArray__common *)b_y, ixstart, (int)sizeof(creal_T));
  if ((x->size[0] == 0) || (x->size[1] == 0)) {
    ixstart = b_y->size[0] * b_y->size[1];
    b_y->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)b_y, ixstart, (int)sizeof(creal_T));
    k = b_y->size[1];
    for (ixstart = 0; ixstart < k; ixstart++) {
      b_y->data[b_y->size[0] * ixstart].re = 0.0;
      b_y->data[b_y->size[0] * ixstart].im = 0.0;
    }
  } else {
    ix = -1;
    iy = -1;
    for (i = 1; i <= x->size[1]; i++) {
      ixstart = ix + 1;
      ix++;
      s_re = x->data[ixstart].re;
      s_im = x->data[ixstart].im;
      for (k = 2; k <= x->size[0]; k++) {
        ix++;
        s_re += x->data[ix].re;
        s_im += x->data[ix].im;
      }

      iy++;
      b_y->data[iy].re = s_re;
      b_y->data[iy].im = s_im;
    }
  }

  d_rdivide(b_y, (double)x->size[0], y);
  emxFree_creal_T(&b_y);
}

double mean(const emxArray_real_T *x)
{
  double y;
  int k;
  if (x->size[1] == 0) {
    y = 0.0;
  } else {
    y = x->data[0];
    for (k = 2; k <= x->size[1]; k++) {
      y += x->data[k - 1];
    }
  }

  y /= (double)x->size[1];
  return y;
}

/* End of code generation (mean.cpp) */
