/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * var.cpp
 *
 * Code generation for function 'var'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "GPSandIMUwaves.h"
#include "var.h"
#include "GPSandIMUwaves_emxutil.h"

/* Function Definitions */
void b_var(const emxArray_real_T *x, emxArray_real_T *y)
{
  int n;
  int ix;
  int i;
  double xbar;
  int k;
  double r;
  double b_y;
  n = x->size[0];
  ix = y->size[0] * y->size[1];
  y->size[0] = 1;
  y->size[1] = x->size[1];
  emxEnsureCapacity((emxArray__common *)y, ix, (int)sizeof(double));
  if (x->size[1] == 0) {
    ix = y->size[0] * y->size[1];
    y->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)y, ix, (int)sizeof(double));
    i = y->size[1];
    for (ix = 0; ix < i; ix++) {
      y->data[y->size[0] * ix] = 0.0;
    }
  } else {
    for (i = 0; i + 1 <= x->size[1]; i++) {
      ix = 0;
      xbar = x->data[x->size[0] * i];
      for (k = 2; k <= n; k++) {
        ix++;
        xbar += x->data[ix + x->size[0] * i];
      }

      xbar /= (double)n;
      ix = 0;
      r = x->data[x->size[0] * i] - xbar;
      b_y = r * r;
      for (k = 2; k <= n; k++) {
        ix++;
        r = x->data[ix + x->size[0] * i] - xbar;
        b_y += r * r;
      }

      b_y /= (double)(n - 1);
      y->data[i] = b_y;
    }
  }
}

double var(const emxArray_real_T *x)
{
  double y;
  int n;
  int d;
  int ix;
  double xbar;
  int k;
  double r;
  n = x->size[1];
  if (x->size[1] > 1) {
    d = x->size[1] - 1;
  } else {
    d = x->size[1];
  }

  if (x->size[1] == 0) {
    y = 0.0;
  } else {
    ix = 0;
    xbar = x->data[0];
    for (k = 2; k <= n; k++) {
      ix++;
      xbar += x->data[ix];
    }

    xbar /= (double)x->size[1];
    ix = 0;
    r = x->data[0] - xbar;
    y = r * r;
    for (k = 2; k <= n; k++) {
      ix++;
      r = x->data[ix] - xbar;
      y += r * r;
    }

    y /= (double)d;
  }

  return y;
}

/* End of code generation (var.cpp) */
